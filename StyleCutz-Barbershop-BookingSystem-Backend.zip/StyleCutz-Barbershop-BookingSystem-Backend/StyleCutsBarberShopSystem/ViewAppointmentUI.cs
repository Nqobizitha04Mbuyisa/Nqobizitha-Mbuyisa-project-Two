﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StyleCutsBarberShopSystem
{
    public partial class ViewAppointmentUI : Form
    {
        int size = 0;
        private int SelectedTabIndex;
        //private AppointmentDataSetTableAdapters.AppointmentTableAdapter appointmentTableAdapter;
        public ViewAppointmentUI()
        {
            InitializeComponent();

        }
        public ViewAppointmentUI(int selectedIndex)
        {
            InitializeComponent();
            SelectedTabIndex = selectedIndex;
            this.Load += ViewAppointmentUI_Load;
        }


        private void ViewAppointmentUI_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dsG72.DataTable1' table. You can move, or remove it, as needed.
            //this.dataTable1TableAdapter.Fill(this.dsG72.DataTable1);
            // TODO: This line of code loads data into the 'dsG73.DataTable1' table. You can move, or remove it, as needed.
            this.dataTable1TableAdapter.Fill(this.dsG73.DataTable1);
            // TODO: This line of code loads data into the 'dsG71.Employee_tbl' table. You can move, or remove it, as needed.
            this.employee_tblTableAdapter.FillByBarbers(this.dsG71.Employee_tbl);
            // TODO: This line of code loads data into the 'dsG71.DataTable1' table. You can move, or remove it, as needed.
            //this.dataTable1TableAdapter.Fill(this.dsG71.DataTable1);
            // TODO: This line of code loads data into the 'dsG7.Service_Appointment' table. You can move, or remove it, as needed.
            if (SelectedTabIndex >= 0 && SelectedTabIndex < tabControl1.TabPages.Count)
            {
                tabControl1.SelectedIndex = SelectedTabIndex;
            }
            this.taService_Appointment.Fill(this.dsG7.Service_Appointment);
            try
            {
                // Disable constraints temporarily for smoother data loading
                dsViewAppointments.EnforceConstraints = false;

                // Fill the data adapter with appointment details filtered by date
                
                this.taInnerJoin.FillByDate(this.dsViewAppointments.InnerJoin);
                this.taInnerJoin.FillByCancelled2(this.dsG72.InnerJoin);

                //taAvailableTimes.FillByLetho(dsAppointment1.AvailableTime, textBox3.Text, Convert.ToInt32(textBox6.Text));
                //taService_Appointment.Fill(dsViewAppointments.Service_Appointment);



               // Re-enable constraints if necessary
               // dsViewAppointments.EnforceConstraints = true;

               // Subscribe to DataBindingComplete event
               //gvAppointments.DataBindingComplete += gvAppointments_DataBindingComplete;

               // Hide textBox2 (assuming it's a control in your form)
               textBox2.Visible = false;
                //textBox7.Visible = false;
                
                // Initialize checkbox states
                //InitializeCheckboxStates();
                //Debug.WriteLine("Checkbox states initialized");

                // Optionally, save initial checkbox states
                // SaveCheckedItems();
                taService1.Fill(dsG71.Service);
                //textBox6.Text = gvAppointments.CurrentRow.Cells[2].Value.ToString();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading appointments: {ex.Message}");
            }
            //dateTimePicker1.Value = DateTime.Today;
            
        }

        
        

        private void gvAppointmentsSearchTB_TextChanged(object sender, EventArgs e)
        {
            taInnerJoin.FillByCustomerName(dsViewAppointments.InnerJoin, gvAppointmentsSearchTB.Text, dateTimePicker2.Value.ToString("yyyy-MM-dd"));
        }

        private void vAppointmentFirstBtn_Click(object sender, EventArgs e)
        {
            innerJoinBS.MoveFirst();
        }

        private void vAppointmentNextBtn_Click(object sender, EventArgs e)
        {
            innerJoinBS.MoveNext();
        }

        private void vAppointmentPreviousBtn_Click(object sender, EventArgs e)
        {
            innerJoinBS.MovePrevious();
        }

        private void vAppointmentLastBtn_Click(object sender, EventArgs e)
        {
            innerJoinBS.MoveLast();
        }

        private void vAppointmentUpadateBtn_Click(object sender, EventArgs e)
        {
            innerJoinBS.EndEdit();
        }
        private void cancelAppointmentBtn_Click(object sender, EventArgs e)
        {

            if (gvAppointments.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an appointment to cancel.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            textBox2.Visible = true;
            string id = textBox2.Text;
            textBox2.Visible = false;

            DialogResult res = MessageBox.Show("Are you sure you want to cancel the Appointment?", "Appointment cancelation confirmation", MessageBoxButtons.YesNo);
            if (res == DialogResult.Yes)
            {
                taAppointment_tbl.UpdateAppointment("cancelled", 23, Convert.ToInt32(id));
                dsG71.DataTable1.Clear();
                this.taInnerJoin.FillByDate(this.dsViewAppointments.InnerJoin);
                MessageBox.Show("Appointment successfully cancelled");

            }
            else
            {
                MessageBox.Show("Appointment not cancelled");
            }
            


        }

        private void gvAppointments_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            taInnerDetails.FillByAppointmentID(dsG71.DataTable1, Convert.ToInt32(gvAppointments.CurrentRow.Cells[0].Value));

            string inputDate = textBox3.Text;
            string formattedDate = GlobalVariables.textBox3; 

            
            if (DateTime.TryParse(inputDate, out DateTime parsedDate))
            {
                formattedDate = parsedDate.ToString("yyyy-MM-dd");
                GlobalVariables.textBox3 = formattedDate;
            }

            if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
            {
                tabControl1.SelectedIndex += 1;
            }

        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            /*textBox4.Text = comboBox1.Text;
            taAvailableTimes.FillByLetho(dsAppointment1.AvailableTime, textBox3.Text, Convert.ToInt32(textBox6.Text));*/
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
             if(textBox6.Text != "")
             {
                taAvailableTimes.FillByLetho(dsAppointment1.AvailableTime, textBox3.Text, Convert.ToInt32(textBox6.Text));

             }
       
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            if (dateTimePicker1.Value < DateTime.Today)
            {
                MessageBox.Show("Cannot book prior to today");
            }
            else
            {
                textBox3.Text = dateTimePicker1.Text;
                taAvailableTimes.FillByLetho(dsAppointment1.AvailableTime, dateTimePicker1.Text, Convert.ToInt32(textBox6.Text));
                
            }
            
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string amount = textBox8.Text;


            //Decimal tAmount = Convert.ToDecimal(amount);
            Decimal total = 0;
            for (int i = 0; i < dataGridView3.Rows.Count - 1; i++)
            {
                total += Convert.ToDecimal(dataGridView3.Rows[i].Cells[2].Value);
            }
            decimal amt = Convert.ToDecimal(amount.Substring(1));
            decimal rowamt = Convert.ToDecimal(dataGridView2.CurrentRow.Cells[2].Value);

            if (total != amt)
            {
                rowamt -= rowamt * 0.15m;
            }
            amt += rowamt;

            textBox8.Text = amt.ToString("C2");

            //textBox7.Visible = true;
            string id = textBox7.Text;
            //textBox7.Visible = false;


            DataRow dr;
            dr =dsG71.DataTable1.NewRow();
            dr[0] = Convert.ToInt32(id);
            
            dr[3]= Convert.ToInt32(dataGridView2.CurrentRow.Cells[0].Value);
            for (int i = 1; i < dr.ItemArray.Length-1; i++)
            {
                dr[i] = dataGridView2.CurrentRow.Cells[i].Value;
            }
            dsG71.DataTable1.Rows.Add(dr);



            

        }

        private void UDRemoveSelected_Click(object sender, EventArgs e)
        {
            
            string amount = textBox8.Text;
            Decimal total = 0;

            for(int i = 0; i < dataGridView3.Rows.Count - 1; i++)
            {
                total += Convert.ToDecimal(dataGridView3.Rows[i].Cells[2].Value);
            }
            decimal amt = Convert.ToDecimal(amount.Substring(1));
            decimal rowamt = Convert.ToDecimal(dataGridView3.CurrentRow.Cells[2].Value);
            if (total != amt){
                rowamt -= rowamt * 0.15m;
            }
            amt -= rowamt;
            dataGridView3.Rows.Remove(dataGridView3.CurrentRow);
            textBox8.Text = amt.ToString("C2");
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            DialogResult confirmation;
            confirmation = MessageBox.Show("Are you sure you want to update?", "Confirm", MessageBoxButtons.YesNo);
            if (confirmation == DialogResult.Yes)
            {
                string f = textBox3.Text.Substring(0, 10);
                string b = f.Substring(0, 4);
                string c = f.Substring(5, 2);
                string d = f.Substring(8, 2);

                string date = b + "-" + c + "-" + d;
                //MessageBox.Show(date);

                int a = 0;

                if (textBox5.Text == "19:30-20:00")
                {
                    a = 22;
                }
                else if (textBox5.Text == "09:00-09:30")
                {
                    a = 1;
                }
                else if (textBox5.Text == "09:30-10:00")
                {
                    a = 2;
                }
                else if (textBox5.Text == "10:00-10:30")
                {
                    a = 3;
                }
                else if (textBox5.Text == "10:30-11:00")
                {
                    a = 4;
                }
                else if (textBox5.Text == "11:00-11:30")
                {
                    a = 5;
                }
                else if (textBox5.Text == "11:30-12:00")
                {
                    a = 6;
                }
                else if (textBox5.Text == "12:00-12:30")
                {
                    a = 7;
                }
                else if (textBox5.Text == "12:30-13:00")
                {
                    a = 8;
                }
                else if (textBox5.Text == "13:00-13:30")
                {
                    a = 9;
                }
                else if (textBox5.Text == "13:30-14:00")
                {
                    a = 10;
                }
                else if (textBox5.Text == "14:00-14:30")
                {
                    a = 11;
                }
                else if (textBox5.Text == "14:30-15:00")
                {
                    a = 12;
                }
                else if (textBox5.Text == "15:00-15:30")
                {
                    a = 13;
                }
                else if (textBox5.Text == "15:30-16:00")
                {
                    a = 14;
                }
                else if (textBox5.Text == "16:00-16:30")
                {
                    a = 15;
                }
                else if (textBox5.Text == "16:30-17:00")
                {
                    a = 16;
                }
                else if (textBox5.Text == "17:00-17:30")
                {
                    a = 17;
                }
                else if (textBox5.Text == "17:30-18:00")
                {
                    a = 18;
                }
                else if (textBox5.Text == "18:00-18:30")
                {
                    a = 19;
                }
                else if (textBox5.Text == "18:30-19:00")
                {
                    a = 20;
                }
                else if (textBox5.Text == "19:00-19:30")
                {
                    a = 21;
                }
                textBox7.Visible = true;
                int k = Convert.ToInt32(textBox7.Text);

                Decimal mny = Convert.ToDecimal(textBox8.Text.Substring(1));
                taAppointment_tbl.UpdateAppointment2(Convert.ToInt32(textBox6.Text), a, f, mny, k);

                /**********************************************************************************************************/


                List<int> service_id = new List<int>();
                for (int i = 0; i < dataGridView3.Rows.Count - 1; i++)
                {
                    service_id.Add(Convert.ToInt32(dataGridView3.Rows[i].Cells[3].Value));
                }

                for (int i = 0; i <= service_id.Count - 1; i++)
                {
                    taService_Appointment.DeleteService(k);
                }
                for (int i = 0; i <= service_id.Count - 1; i++)
                {
                    taService_Appointment.Insert1(k, service_id[i]);
                }

                for (int i = 0; i < size - 1; i++)
                {
                    taService_Appointment.DeleteService(k);
                }

                service_id.Clear();
                String dateT = DateTime.Today.ToString("yyyy-MM-dd");


                /**********************************************************************************************************/
                this.taInnerJoin.FillByDate(this.dsViewAppointments.InnerJoin);
                dsG71.DataTable1.Clear();
                MessageBox.Show("Update successful");
                //Edited
            }
            else
            {
                MessageBox.Show("Update cancelled");
                this.taInnerJoin.FillByDate(this.dsViewAppointments.InnerJoin);
            }


        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox5.Text = comboBox2.Text;
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            taService1.FillByServiceName(dsG71.Service, textBox9.Text);
        }

        private void UDRemoveAll_Click(object sender, EventArgs e)
        {
            size = dataGridView3.Rows.Count;
            dsG71.DataTable1.Clear();
            textBox8.Text = "R0";
            /*textBox7.Visible = true;

            int k = Convert.ToInt32(textBox7.Text);

            List<int> service_id = new List<int>();
            for (int i = 0; i < dataGridView3.Rows.Count - 1; i++)
            {
                service_id.Add(Convert.ToInt32(dataGridView3.Rows[i].Cells[3].Value));
            }

            for (int i = 0; i <= service_id.Count - 1; i++)
            {
                taService_Appointment.DeleteService(k);
            }
            for (int i = 0; i <= service_id.Count - 1; i++)
            {
                taService_Appointment.Insert1(k, service_id[i]);
            }

            service_id.Clear();*/
        }

        private void dataGridView4_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox4.Text = dataGridView4.CurrentRow.Cells[1].Value.ToString();
            textBox6.Text = dataGridView4.CurrentRow.Cells[0].Value.ToString();
            taAvailableTimes.FillByLetho(dsAppointment1.AvailableTime, textBox3.Text, Convert.ToInt32(textBox6.Text));
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            //taAvailableTimes.FillByLetho(dsAppointment1.AvailableTime, textBox3.Text, Convert.ToInt32(textBox6.Text));
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void gvAppointments_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            //taAvailableTimes.FillByLetho(dsAppointment1.AvailableTime, textBox3.Text, Convert.ToInt32(textBox6.Text));
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            taInnerJoin.FillByDateTimePicker(dsViewAppointments.InnerJoin, dateTimePicker2.Value.ToString("yyyy-MM-dd"));
        }

        private void tabControl1_TabIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void dateTimePicker3_ValueChanged(object sender, EventArgs e)
        {
            this.taInnerJoin.FillByCancelled(dsG72.InnerJoin, dateTimePicker3.Value.ToString("yyyy-MM-dd"));

        }

        private void dataGridView6_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            taInnerDetails.FillByAppointmentID(dsG72.DataTable1, Convert.ToInt32(dataGridView6.CurrentRow.Cells[0].Value));

            string inputDate = textBox3.Text;
            string formattedDate = GlobalVariables.textBox3;


            if (DateTime.TryParse(inputDate, out DateTime parsedDate))
            {
                formattedDate = parsedDate.ToString("yyyy-MM-dd");
                GlobalVariables.textBox3 = formattedDate;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
            {
                tabControl1.SelectedIndex += 1;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex > 0)
            {
                tabControl1.SelectedIndex -= 1;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex > 0)
            {
                tabControl1.SelectedIndex -= 1;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
            {
                tabControl1.SelectedIndex += 1;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex > 0)
            {
                tabControl1.SelectedIndex -= 1;
            }
        }
    }
}
