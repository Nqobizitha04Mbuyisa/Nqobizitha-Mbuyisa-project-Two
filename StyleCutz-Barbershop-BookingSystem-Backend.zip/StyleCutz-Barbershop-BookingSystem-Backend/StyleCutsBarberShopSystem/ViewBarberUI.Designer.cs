﻿
namespace StyleCutsBarberShopSystem
{
    partial class ViewBarberUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.gvBarbersSearchTB = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.gvBarbers = new System.Windows.Forms.DataGridView();
            this.employeeidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeenameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeecellNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeemailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empoyeegenderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employee_position = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewBarberBS = new System.Windows.Forms.BindingSource(this.components);
            this.dsViewBarber = new StyleCutsBarberShopSystem.dsG7();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Options = new System.Windows.Forms.GroupBox();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.vBarberUpdateBtn = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.vBarberFirstBtn = new System.Windows.Forms.Button();
            this.vBarberNextBtn = new System.Windows.Forms.Button();
            this.vBarberPreviousTB = new System.Windows.Forms.Button();
            this.vBarberLastTB = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.vBarberCellTB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.vBarberGenderTB = new System.Windows.Forms.TextBox();
            this.vBarberEmailTB = new System.Windows.Forms.TextBox();
            this.vBarberNameTB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.taViewBarber1 = new StyleCutsBarberShopSystem.dsG7TableAdapters.Employee_tblTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvBarbers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewBarberBS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsViewBarber)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.Options.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 450);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.gvBarbersSearchTB);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.gvBarbers);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 424);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "View Employees Details";
            // 
            // gvBarbersSearchTB
            // 
            this.gvBarbersSearchTB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gvBarbersSearchTB.ForeColor = System.Drawing.Color.Black;
            this.gvBarbersSearchTB.Location = new System.Drawing.Point(325, 46);
            this.gvBarbersSearchTB.Name = "gvBarbersSearchTB";
            this.gvBarbersSearchTB.Size = new System.Drawing.Size(178, 20);
            this.gvBarbersSearchTB.TabIndex = 39;
            this.gvBarbersSearchTB.TextChanged += new System.EventHandler(this.gvBarbersSearchTB_TextChanged);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(186, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 20);
            this.label4.TabIndex = 38;
            this.label4.Text = "Employee Name:";
            // 
            // gvBarbers
            // 
            this.gvBarbers.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gvBarbers.AutoGenerateColumns = false;
            this.gvBarbers.BackgroundColor = System.Drawing.Color.White;
            this.gvBarbers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvBarbers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.employeeidDataGridViewTextBoxColumn,
            this.employeenameDataGridViewTextBoxColumn,
            this.employeecellNoDataGridViewTextBoxColumn,
            this.employeeemailDataGridViewTextBoxColumn,
            this.empoyeegenderDataGridViewTextBoxColumn,
            this.employee_position});
            this.gvBarbers.DataSource = this.viewBarberBS;
            this.gvBarbers.Location = new System.Drawing.Point(8, 88);
            this.gvBarbers.Name = "gvBarbers";
            this.gvBarbers.ReadOnly = true;
            this.gvBarbers.RowHeadersWidth = 51;
            this.gvBarbers.Size = new System.Drawing.Size(776, 328);
            this.gvBarbers.TabIndex = 0;
            this.gvBarbers.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvBarbers_CellClick);
            // 
            // employeeidDataGridViewTextBoxColumn
            // 
            this.employeeidDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.employeeidDataGridViewTextBoxColumn.DataPropertyName = "employee_id";
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.employeeidDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.employeeidDataGridViewTextBoxColumn.HeaderText = "employee_id";
            this.employeeidDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeeidDataGridViewTextBoxColumn.Name = "employeeidDataGridViewTextBoxColumn";
            this.employeeidDataGridViewTextBoxColumn.ReadOnly = true;
            this.employeeidDataGridViewTextBoxColumn.Width = 91;
            // 
            // employeenameDataGridViewTextBoxColumn
            // 
            this.employeenameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.employeenameDataGridViewTextBoxColumn.DataPropertyName = "employee_name";
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.employeenameDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.employeenameDataGridViewTextBoxColumn.HeaderText = "employee_name";
            this.employeenameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeenameDataGridViewTextBoxColumn.Name = "employeenameDataGridViewTextBoxColumn";
            this.employeenameDataGridViewTextBoxColumn.ReadOnly = true;
            this.employeenameDataGridViewTextBoxColumn.Width = 109;
            // 
            // employeecellNoDataGridViewTextBoxColumn
            // 
            this.employeecellNoDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.employeecellNoDataGridViewTextBoxColumn.DataPropertyName = "employee_cellNo";
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.employeecellNoDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle3;
            this.employeecellNoDataGridViewTextBoxColumn.HeaderText = "employee_cellNo";
            this.employeecellNoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeecellNoDataGridViewTextBoxColumn.Name = "employeecellNoDataGridViewTextBoxColumn";
            this.employeecellNoDataGridViewTextBoxColumn.ReadOnly = true;
            this.employeecellNoDataGridViewTextBoxColumn.Width = 113;
            // 
            // employeeemailDataGridViewTextBoxColumn
            // 
            this.employeeemailDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.employeeemailDataGridViewTextBoxColumn.DataPropertyName = "employee_email";
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.employeeemailDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle4;
            this.employeeemailDataGridViewTextBoxColumn.HeaderText = "employee_email";
            this.employeeemailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeeemailDataGridViewTextBoxColumn.Name = "employeeemailDataGridViewTextBoxColumn";
            this.employeeemailDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // empoyeegenderDataGridViewTextBoxColumn
            // 
            this.empoyeegenderDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.empoyeegenderDataGridViewTextBoxColumn.DataPropertyName = "empoyee_gender";
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.empoyeegenderDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle5;
            this.empoyeegenderDataGridViewTextBoxColumn.HeaderText = "empoyee_gender";
            this.empoyeegenderDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.empoyeegenderDataGridViewTextBoxColumn.Name = "empoyeegenderDataGridViewTextBoxColumn";
            this.empoyeegenderDataGridViewTextBoxColumn.ReadOnly = true;
            this.empoyeegenderDataGridViewTextBoxColumn.Width = 114;
            // 
            // employee_position
            // 
            this.employee_position.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.employee_position.DataPropertyName = "employee_position";
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            this.employee_position.DefaultCellStyle = dataGridViewCellStyle6;
            this.employee_position.HeaderText = "employee_position";
            this.employee_position.Name = "employee_position";
            this.employee_position.ReadOnly = true;
            this.employee_position.Width = 119;
            // 
            // viewBarberBS
            // 
            this.viewBarberBS.DataMember = "Employee_tbl";
            this.viewBarberBS.DataSource = this.dsViewBarber;
            // 
            // dsViewBarber
            // 
            this.dsViewBarber.DataSetName = "dsG7";
            this.dsViewBarber.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.Options);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 424);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Modify Employees Details";
            // 
            // Options
            // 
            this.Options.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Options.Controls.Add(this.deleteBtn);
            this.Options.Controls.Add(this.vBarberUpdateBtn);
            this.Options.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Options.ForeColor = System.Drawing.Color.Black;
            this.Options.Location = new System.Drawing.Point(179, 328);
            this.Options.Name = "Options";
            this.Options.Size = new System.Drawing.Size(423, 78);
            this.Options.TabIndex = 40;
            this.Options.TabStop = false;
            this.Options.Text = "Options";
            // 
            // deleteBtn
            // 
            this.deleteBtn.BackColor = System.Drawing.Color.Navy;
            this.deleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.deleteBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteBtn.ForeColor = System.Drawing.Color.White;
            this.deleteBtn.Location = new System.Drawing.Point(18, 22);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(190, 37);
            this.deleteBtn.TabIndex = 16;
            this.deleteBtn.Text = "Delete";
            this.deleteBtn.UseVisualStyleBackColor = false;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // vBarberUpdateBtn
            // 
            this.vBarberUpdateBtn.BackColor = System.Drawing.Color.Navy;
            this.vBarberUpdateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vBarberUpdateBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vBarberUpdateBtn.ForeColor = System.Drawing.Color.White;
            this.vBarberUpdateBtn.Location = new System.Drawing.Point(221, 22);
            this.vBarberUpdateBtn.Name = "vBarberUpdateBtn";
            this.vBarberUpdateBtn.Size = new System.Drawing.Size(190, 37);
            this.vBarberUpdateBtn.TabIndex = 15;
            this.vBarberUpdateBtn.Text = "Update";
            this.vBarberUpdateBtn.UseVisualStyleBackColor = false;
            this.vBarberUpdateBtn.Click += new System.EventHandler(this.vBarberUpdateBtn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(this.vBarberFirstBtn);
            this.groupBox2.Controls.Add(this.vBarberNextBtn);
            this.groupBox2.Controls.Add(this.vBarberPreviousTB);
            this.groupBox2.Controls.Add(this.vBarberLastTB);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Black;
            this.groupBox2.Location = new System.Drawing.Point(179, 228);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(423, 94);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Navigation";
            // 
            // vBarberFirstBtn
            // 
            this.vBarberFirstBtn.BackColor = System.Drawing.Color.Navy;
            this.vBarberFirstBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vBarberFirstBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vBarberFirstBtn.ForeColor = System.Drawing.Color.White;
            this.vBarberFirstBtn.Location = new System.Drawing.Point(18, 36);
            this.vBarberFirstBtn.Name = "vBarberFirstBtn";
            this.vBarberFirstBtn.Size = new System.Drawing.Size(87, 37);
            this.vBarberFirstBtn.TabIndex = 13;
            this.vBarberFirstBtn.Text = "First";
            this.vBarberFirstBtn.UseVisualStyleBackColor = false;
            this.vBarberFirstBtn.Click += new System.EventHandler(this.vBarberFirstBtn_Click);
            // 
            // vBarberNextBtn
            // 
            this.vBarberNextBtn.BackColor = System.Drawing.Color.Navy;
            this.vBarberNextBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vBarberNextBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vBarberNextBtn.ForeColor = System.Drawing.Color.White;
            this.vBarberNextBtn.Location = new System.Drawing.Point(221, 36);
            this.vBarberNextBtn.Name = "vBarberNextBtn";
            this.vBarberNextBtn.Size = new System.Drawing.Size(87, 37);
            this.vBarberNextBtn.TabIndex = 12;
            this.vBarberNextBtn.Text = "Next";
            this.vBarberNextBtn.UseVisualStyleBackColor = false;
            this.vBarberNextBtn.Click += new System.EventHandler(this.vBarberNextBtn_Click);
            // 
            // vBarberPreviousTB
            // 
            this.vBarberPreviousTB.BackColor = System.Drawing.Color.Navy;
            this.vBarberPreviousTB.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vBarberPreviousTB.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vBarberPreviousTB.ForeColor = System.Drawing.Color.White;
            this.vBarberPreviousTB.Location = new System.Drawing.Point(118, 36);
            this.vBarberPreviousTB.Name = "vBarberPreviousTB";
            this.vBarberPreviousTB.Size = new System.Drawing.Size(87, 37);
            this.vBarberPreviousTB.TabIndex = 11;
            this.vBarberPreviousTB.Text = "Previous";
            this.vBarberPreviousTB.UseVisualStyleBackColor = false;
            this.vBarberPreviousTB.Click += new System.EventHandler(this.vBarberPreviousTB_Click);
            // 
            // vBarberLastTB
            // 
            this.vBarberLastTB.BackColor = System.Drawing.Color.Navy;
            this.vBarberLastTB.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vBarberLastTB.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vBarberLastTB.ForeColor = System.Drawing.Color.White;
            this.vBarberLastTB.Location = new System.Drawing.Point(323, 36);
            this.vBarberLastTB.Name = "vBarberLastTB";
            this.vBarberLastTB.Size = new System.Drawing.Size(87, 37);
            this.vBarberLastTB.TabIndex = 10;
            this.vBarberLastTB.Text = "Last";
            this.vBarberLastTB.UseVisualStyleBackColor = false;
            this.vBarberLastTB.Click += new System.EventHandler(this.vBarberLastTB_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.vBarberCellTB);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.vBarberGenderTB);
            this.groupBox1.Controls.Add(this.vBarberEmailTB);
            this.groupBox1.Controls.Add(this.vBarberNameTB);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(179, 31);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(423, 191);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Employee Details";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(41, 145);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 20);
            this.label1.TabIndex = 37;
            this.label1.Text = "Position:";
            // 
            // textBox1
            // 
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewBarberBS, "employee_position", true));
            this.textBox1.Location = new System.Drawing.Point(164, 145);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(178, 26);
            this.textBox1.TabIndex = 36;
            // 
            // textBox3
            // 
            this.textBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox3.Location = new System.Drawing.Point(348, 145);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(10, 26);
            this.textBox3.TabIndex = 35;
            // 
            // vBarberCellTB
            // 
            this.vBarberCellTB.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewBarberBS, "employee_cellNo", true));
            this.vBarberCellTB.Location = new System.Drawing.Point(164, 49);
            this.vBarberCellTB.Name = "vBarberCellTB";
            this.vBarberCellTB.Size = new System.Drawing.Size(178, 26);
            this.vBarberCellTB.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(41, 49);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "Cellphone:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(41, 107);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "Gender:";
            // 
            // vBarberGenderTB
            // 
            this.vBarberGenderTB.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewBarberBS, "empoyee_gender", true));
            this.vBarberGenderTB.Location = new System.Drawing.Point(164, 107);
            this.vBarberGenderTB.Name = "vBarberGenderTB";
            this.vBarberGenderTB.Size = new System.Drawing.Size(178, 26);
            this.vBarberGenderTB.TabIndex = 8;
            // 
            // vBarberEmailTB
            // 
            this.vBarberEmailTB.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewBarberBS, "employee_email", true));
            this.vBarberEmailTB.Location = new System.Drawing.Point(164, 78);
            this.vBarberEmailTB.Name = "vBarberEmailTB";
            this.vBarberEmailTB.Size = new System.Drawing.Size(178, 26);
            this.vBarberEmailTB.TabIndex = 7;
            // 
            // vBarberNameTB
            // 
            this.vBarberNameTB.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.viewBarberBS, "employee_name", true));
            this.vBarberNameTB.Location = new System.Drawing.Point(164, 20);
            this.vBarberNameTB.Name = "vBarberNameTB";
            this.vBarberNameTB.Size = new System.Drawing.Size(178, 26);
            this.vBarberNameTB.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(41, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Email Address:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(41, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Full Name:";
            // 
            // taViewBarber1
            // 
            this.taViewBarber1.ClearBeforeFill = true;
            // 
            // ViewBarberUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ViewBarberUI";
            this.Text = "ViewBarberUI";
            this.Load += new System.EventHandler(this.ViewBarberUI_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvBarbers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewBarberBS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsViewBarber)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.Options.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox Options;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button vBarberFirstBtn;
        private System.Windows.Forms.Button vBarberNextBtn;
        private System.Windows.Forms.Button vBarberPreviousTB;
        private System.Windows.Forms.Button vBarberLastTB;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox vBarberGenderTB;
        private System.Windows.Forms.TextBox vBarberEmailTB;
        private System.Windows.Forms.TextBox vBarberNameTB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox gvBarbersSearchTB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView gvBarbers;
        private dsG7TableAdapters.Employee_tblTableAdapter taViewBarber1;
        private dsG7 dsViewBarber;
        private System.Windows.Forms.BindingSource viewBarberBS;
        private System.Windows.Forms.TextBox vBarberCellTB;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.Button vBarberUpdateBtn;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeenameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeecellNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeemailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empoyeegenderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employee_position;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.Button deleteBtn;
    }
}