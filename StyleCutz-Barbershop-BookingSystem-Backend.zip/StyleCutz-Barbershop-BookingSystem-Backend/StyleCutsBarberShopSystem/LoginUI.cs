﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace StyleCutsBarberShopSystem
{
    public partial class LoginUI : Form
    {
        public event EventHandler ButtonClicked;
        public LoginUI()
        {
            InitializeComponent();

            // Ensure the event is subscribed

            this.LoginBtn.Click += new System.EventHandler(this.LoginBtn_Click);
            iconButton4.Click += iconButton4_Click;
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            employee_tblTableAdapter1.FillByNameEmail(dsG71.Employee_tbl, textBox1.Text, textBox2.Text);
            try
            {
                // Fill the dataset with user information based on the provided username and email

                if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox2.Text))
                {
                    // MessageBox.Show("Please enter both username and email.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (dsG71.Employee_tbl.Rows.Count > 0)
                {
                    string email = textBox2.Text;
                    GlobalVariables.username = textBox1.Text;


                    if (email == "Nm@gmail.com")
                    {
                        MessageBox.Show("Welcome to the system, Manager", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    else if (email == "Mi")
                    {
                        MessageBox.Show("Welcome to the system, Admin", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Welcome to the system, Barber", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                    ButtonClicked?.Invoke(this, EventArgs.Empty);
                    this.textBox1.Clear();
                    this.textBox2.Clear();
                    this.Hide();

                }

                else
                {
                    MessageBox.Show("Invalid login credentials. Please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.textBox1.Clear();
                    this.textBox2.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while logging in: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private bool isPasswordVisible = false; // Initially, password is hidden

        private void iconButton4_Click(object sender, EventArgs e)
        {
            // Toggle the state
            isPasswordVisible = !isPasswordVisible;

            // Set UseSystemPasswordChar based on the toggle state
            textBox2.UseSystemPasswordChar = !isPasswordVisible;

            // Force focus back to textBox2 to ensure visual update
            textBox2.Focus();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Move the focus to the next control
                textBox2.Focus();
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Move the focus to the next control
                LoginBtn.Focus();
            }
        }

        private void LoginBtn_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Perform the button click
                LoginBtn.PerformClick();
            }
        }
    }
}