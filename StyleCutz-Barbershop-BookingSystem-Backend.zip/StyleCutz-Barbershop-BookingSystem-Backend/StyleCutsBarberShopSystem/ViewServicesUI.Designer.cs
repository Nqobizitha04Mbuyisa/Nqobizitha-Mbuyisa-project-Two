﻿
namespace StyleCutsBarberShopSystem
{
    partial class ViewServicesUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.gvServicesSearchTB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.gvServices = new System.Windows.Forms.DataGridView();
            this.serviceidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicenameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicepriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serviceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsG71 = new StyleCutsBarberShopSystem.dsG7();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Options = new System.Windows.Forms.GroupBox();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.vServiceUpdateBtn = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.vServiceFisrtBtn = new System.Windows.Forms.Button();
            this.vServiceNextBtn = new System.Windows.Forms.Button();
            this.vServicePreviousBtn = new System.Windows.Forms.Button();
            this.vServiceLastBtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.vServicePriceTB = new System.Windows.Forms.TextBox();
            this.vServiceNameTB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.taService1 = new StyleCutsBarberShopSystem.dsG7TableAdapters.ServiceTableAdapter();
            this.taService2 = new StyleCutsBarberShopSystem.dsG7TableAdapters.ServiceTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvServices)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG71)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.Options.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 450);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.gvServicesSearchTB);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.gvServices);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 424);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "View Service Details";
            // 
            // gvServicesSearchTB
            // 
            this.gvServicesSearchTB.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.gvServicesSearchTB.ForeColor = System.Drawing.Color.Black;
            this.gvServicesSearchTB.Location = new System.Drawing.Point(325, 28);
            this.gvServicesSearchTB.Name = "gvServicesSearchTB";
            this.gvServicesSearchTB.Size = new System.Drawing.Size(178, 20);
            this.gvServicesSearchTB.TabIndex = 51;
            this.gvServicesSearchTB.TextChanged += new System.EventHandler(this.gvServicesSearchTB_TextChanged);
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(194, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 20);
            this.label6.TabIndex = 50;
            this.label6.Text = "Service Name:";
            // 
            // gvServices
            // 
            this.gvServices.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gvServices.AutoGenerateColumns = false;
            this.gvServices.BackgroundColor = System.Drawing.Color.White;
            this.gvServices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvServices.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serviceidDataGridViewTextBoxColumn,
            this.servicenameDataGridViewTextBoxColumn,
            this.servicepriceDataGridViewTextBoxColumn});
            this.gvServices.DataSource = this.serviceBindingSource;
            this.gvServices.Location = new System.Drawing.Point(8, 70);
            this.gvServices.Name = "gvServices";
            this.gvServices.ReadOnly = true;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gvServices.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.gvServices.Size = new System.Drawing.Size(776, 328);
            this.gvServices.TabIndex = 49;
            this.gvServices.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvServices_CellClick);
            this.gvServices.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gvServices_RowHeaderMouseClick);
            // 
            // serviceidDataGridViewTextBoxColumn
            // 
            this.serviceidDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.serviceidDataGridViewTextBoxColumn.DataPropertyName = "service_id";
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.serviceidDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.serviceidDataGridViewTextBoxColumn.HeaderText = "Id";
            this.serviceidDataGridViewTextBoxColumn.Name = "serviceidDataGridViewTextBoxColumn";
            this.serviceidDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // servicenameDataGridViewTextBoxColumn
            // 
            this.servicenameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.servicenameDataGridViewTextBoxColumn.DataPropertyName = "service_name";
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.servicenameDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.servicenameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.servicenameDataGridViewTextBoxColumn.Name = "servicenameDataGridViewTextBoxColumn";
            this.servicenameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // servicepriceDataGridViewTextBoxColumn
            // 
            this.servicepriceDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.servicepriceDataGridViewTextBoxColumn.DataPropertyName = "service_price";
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.Format = "C2";
            dataGridViewCellStyle3.NullValue = null;
            this.servicepriceDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle3;
            this.servicepriceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.servicepriceDataGridViewTextBoxColumn.Name = "servicepriceDataGridViewTextBoxColumn";
            this.servicepriceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // serviceBindingSource
            // 
            this.serviceBindingSource.DataMember = "Service";
            this.serviceBindingSource.DataSource = this.dsG71;
            // 
            // dsG71
            // 
            this.dsG71.DataSetName = "dsG7";
            this.dsG71.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.Options);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 424);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Modify Service Details";
            // 
            // Options
            // 
            this.Options.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Options.Controls.Add(this.deleteBtn);
            this.Options.Controls.Add(this.vServiceUpdateBtn);
            this.Options.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Options.ForeColor = System.Drawing.Color.Black;
            this.Options.Location = new System.Drawing.Point(202, 293);
            this.Options.Name = "Options";
            this.Options.Size = new System.Drawing.Size(423, 79);
            this.Options.TabIndex = 47;
            this.Options.TabStop = false;
            this.Options.Text = "Options";
            // 
            // deleteBtn
            // 
            this.deleteBtn.BackColor = System.Drawing.Color.Navy;
            this.deleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.deleteBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteBtn.ForeColor = System.Drawing.Color.White;
            this.deleteBtn.Location = new System.Drawing.Point(16, 25);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(187, 37);
            this.deleteBtn.TabIndex = 16;
            this.deleteBtn.Text = "Delete";
            this.deleteBtn.UseVisualStyleBackColor = false;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // vServiceUpdateBtn
            // 
            this.vServiceUpdateBtn.BackColor = System.Drawing.Color.Navy;
            this.vServiceUpdateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vServiceUpdateBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vServiceUpdateBtn.ForeColor = System.Drawing.Color.White;
            this.vServiceUpdateBtn.Location = new System.Drawing.Point(220, 25);
            this.vServiceUpdateBtn.Name = "vServiceUpdateBtn";
            this.vServiceUpdateBtn.Size = new System.Drawing.Size(187, 37);
            this.vServiceUpdateBtn.TabIndex = 15;
            this.vServiceUpdateBtn.Text = "Update";
            this.vServiceUpdateBtn.UseVisualStyleBackColor = false;
            this.vServiceUpdateBtn.Click += new System.EventHandler(this.vServiceUpdateBtn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(this.vServiceFisrtBtn);
            this.groupBox2.Controls.Add(this.vServiceNextBtn);
            this.groupBox2.Controls.Add(this.vServicePreviousBtn);
            this.groupBox2.Controls.Add(this.vServiceLastBtn);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Black;
            this.groupBox2.Location = new System.Drawing.Point(202, 182);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(423, 95);
            this.groupBox2.TabIndex = 46;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Navigation";
            // 
            // vServiceFisrtBtn
            // 
            this.vServiceFisrtBtn.BackColor = System.Drawing.Color.Navy;
            this.vServiceFisrtBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vServiceFisrtBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vServiceFisrtBtn.ForeColor = System.Drawing.Color.White;
            this.vServiceFisrtBtn.Location = new System.Drawing.Point(16, 36);
            this.vServiceFisrtBtn.Name = "vServiceFisrtBtn";
            this.vServiceFisrtBtn.Size = new System.Drawing.Size(87, 37);
            this.vServiceFisrtBtn.TabIndex = 13;
            this.vServiceFisrtBtn.Text = "First";
            this.vServiceFisrtBtn.UseVisualStyleBackColor = false;
            this.vServiceFisrtBtn.Click += new System.EventHandler(this.vServiceFisrtBtn_Click);
            // 
            // vServiceNextBtn
            // 
            this.vServiceNextBtn.BackColor = System.Drawing.Color.Navy;
            this.vServiceNextBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vServiceNextBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vServiceNextBtn.ForeColor = System.Drawing.Color.White;
            this.vServiceNextBtn.Location = new System.Drawing.Point(220, 36);
            this.vServiceNextBtn.Name = "vServiceNextBtn";
            this.vServiceNextBtn.Size = new System.Drawing.Size(87, 37);
            this.vServiceNextBtn.TabIndex = 12;
            this.vServiceNextBtn.Text = "Next";
            this.vServiceNextBtn.UseVisualStyleBackColor = false;
            this.vServiceNextBtn.Click += new System.EventHandler(this.vServiceNextBtn_Click);
            // 
            // vServicePreviousBtn
            // 
            this.vServicePreviousBtn.BackColor = System.Drawing.Color.Navy;
            this.vServicePreviousBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vServicePreviousBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vServicePreviousBtn.ForeColor = System.Drawing.Color.White;
            this.vServicePreviousBtn.Location = new System.Drawing.Point(118, 36);
            this.vServicePreviousBtn.Name = "vServicePreviousBtn";
            this.vServicePreviousBtn.Size = new System.Drawing.Size(87, 37);
            this.vServicePreviousBtn.TabIndex = 11;
            this.vServicePreviousBtn.Text = "Previous";
            this.vServicePreviousBtn.UseVisualStyleBackColor = false;
            this.vServicePreviousBtn.Click += new System.EventHandler(this.vServicePreviousBtn_Click);
            // 
            // vServiceLastBtn
            // 
            this.vServiceLastBtn.BackColor = System.Drawing.Color.Navy;
            this.vServiceLastBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vServiceLastBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vServiceLastBtn.ForeColor = System.Drawing.Color.White;
            this.vServiceLastBtn.Location = new System.Drawing.Point(320, 36);
            this.vServiceLastBtn.Name = "vServiceLastBtn";
            this.vServiceLastBtn.Size = new System.Drawing.Size(87, 37);
            this.vServiceLastBtn.TabIndex = 10;
            this.vServiceLastBtn.Text = "Last";
            this.vServiceLastBtn.UseVisualStyleBackColor = false;
            this.vServiceLastBtn.Click += new System.EventHandler(this.vServiceLastBtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.vServicePriceTB);
            this.groupBox1.Controls.Add(this.vServiceNameTB);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(202, 66);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(423, 93);
            this.groupBox1.TabIndex = 45;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Service Details";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(68, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "Price:";
            // 
            // vServicePriceTB
            // 
            this.vServicePriceTB.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.serviceBindingSource, "service_price", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "C2"));
            this.vServicePriceTB.Location = new System.Drawing.Point(164, 50);
            this.vServicePriceTB.Name = "vServicePriceTB";
            this.vServicePriceTB.Size = new System.Drawing.Size(178, 26);
            this.vServicePriceTB.TabIndex = 7;
            // 
            // vServiceNameTB
            // 
            this.vServiceNameTB.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.serviceBindingSource, "service_name", true));
            this.vServiceNameTB.Location = new System.Drawing.Point(164, 20);
            this.vServiceNameTB.Name = "vServiceNameTB";
            this.vServiceNameTB.Size = new System.Drawing.Size(178, 26);
            this.vServiceNameTB.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(68, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Name:";
            // 
            // taService1
            // 
            this.taService1.ClearBeforeFill = true;
            // 
            // taService2
            // 
            this.taService2.ClearBeforeFill = true;
            // 
            // ViewServicesUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ViewServicesUI";
            this.Load += new System.EventHandler(this.ViewServicesUI_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvServices)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG71)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.Options.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox Options;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button vServiceFisrtBtn;
        private System.Windows.Forms.Button vServiceNextBtn;
        private System.Windows.Forms.Button vServicePreviousBtn;
        private System.Windows.Forms.Button vServiceLastBtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox vServicePriceTB;
        private System.Windows.Forms.TextBox vServiceNameTB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox gvServicesSearchTB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView gvServices;
        private dsG7 dsG71;
        private dsG7TableAdapters.ServiceTableAdapter taService1;
        private System.Windows.Forms.BindingSource serviceBindingSource;
        private dsG7TableAdapters.ServiceTableAdapter taService2;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicenameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicepriceDataGridViewTextBoxColumn;
        public System.Windows.Forms.Button vServiceUpdateBtn;
        public System.Windows.Forms.Button deleteBtn;
    }
}