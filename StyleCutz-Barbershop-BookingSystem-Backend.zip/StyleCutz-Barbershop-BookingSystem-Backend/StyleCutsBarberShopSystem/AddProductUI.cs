﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StyleCutsBarberShopSystem
{
    public partial class AddProductUI : Form
    {
        public AddProductUI()
        {
            InitializeComponent();
        }

        private void AddProductUI_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dsG7.Supplier_tbl' table. You can move, or remove it, as needed.
            this.supplier_tblTableAdapter.Fill(this.dsG7.Supplier_tbl);
            // TODO: This line of code loads data into the 'dsG7.Inventory_tbl' table. You can move, or remove it, as needed.
            this.taInventory.Fill(this.dsG7.Inventory_tbl);
        }

        private void productConfirmTB_Click_1(object sender, EventArgs e)
        {
            try
            {
                taInventory.InsertQuery(Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value), Convert.ToInt32(productQuantityTB.Text),
                    Convert.ToDecimal(productPriceTB.Text), productNameTB.Text, null);
            }
            catch
            {
                MessageBox.Show("Enter valid details", "Invalid details", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            productNameTB.Clear();
            productQuantityTB.Clear();
            productPriceTB.Clear();

            MessageBox.Show("Product added successfully");
        }

        private void productClearTB_Click_1(object sender, EventArgs e)
        {
            productNameTB.Clear();
            productQuantityTB.Clear();
            productPriceTB.Clear();
        }

        private void productNameTB_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Move the focus to the next control
                productQuantityTB.Focus();
            }
        }

        private void productQuantityTB_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Move the focus to the next control
                productPriceTB.Focus();
            }
        }
    }
}
