﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StyleCutsBarberShopSystem
{
    public partial class ViewServicesUI : Form
    {
        public ViewServicesUI()
        {
            InitializeComponent();
            //this.Resize += ViewServicesUI_Resize;
        }

        private void gvServicesSearchBtn_Click(object sender, EventArgs e)
        {
            taService2.FillByServiceName(dsG71.Service, gvServicesSearchTB.Text.ToString());
           
        }

        private void gvServicesSearchTB_TextChanged(object sender, EventArgs e)
        {
            taService2.FillByServiceName(dsG71.Service, gvServicesSearchTB.Text.ToString());
        }

        private void gvServices_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            vServiceNameTB.Text = gvServices.CurrentRow.Cells[1].Value.ToString();
            vServicePriceTB.Text = gvServices.CurrentRow.Cells[2].Value.ToString();
        }

        private void ViewServicesUI_Load(object sender, EventArgs e)
        {
            taService2.FillByAvailable(dsG71.Service);
        }

        private void vServiceFisrtBtn_Click(object sender, EventArgs e)
        {
            serviceBindingSource.MoveFirst();
        }

        private void vServiceLastBtn_Click(object sender, EventArgs e)
        {
            serviceBindingSource.MoveLast();
        }

        private void vServicePreviousBtn_Click(object sender, EventArgs e)
        {
            serviceBindingSource.MovePrevious();
        }

        private void vServiceNextBtn_Click(object sender, EventArgs e)
        {
            serviceBindingSource.MoveNext();
        }

        private void vServiceUpdateBtn_Click(object sender, EventArgs e)
        {   
            DialogResult confirmation;
            confirmation = MessageBox.Show("Are you sure you want to update?", "Confirm", MessageBoxButtons.YesNo);
            if (confirmation == DialogResult.Yes)
            {
               serviceBindingSource.EndEdit();
               taService2.Update(dsG71);
               MessageBox.Show("Update successful");     
            }
            else
            {
                MessageBox.Show("Update cancelled");
                taService2.FillByAvailable(dsG71.Service);
            }

        }

        private void vServiceSubmitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            DialogResult confirmation;
            confirmation = MessageBox.Show("Are you sure you want to delete this service?", "Confirm", MessageBoxButtons.YesNo);
            if (confirmation == DialogResult.Yes)
            {
               taService2.UpdateStatus("unavailable", Convert.ToInt32(gvServices.CurrentRow.Cells[0].Value));
               taService2.FillByAvailable(dsG71.Service);
               MessageBox.Show("Delation successful");
            }
            else
            {
                MessageBox.Show("Delation cancelled");
            }

        }

        private void gvServices_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
            {
                tabControl1.SelectedIndex += 1;
            }
        }
    }
}
