﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace StyleCutsBarberShopSystem
{
    class DBConnect
    {
        private SqlConnection conn;
        private SqlCommand command;
        private SqlDataAdapter da;
        private DataTable dt;
        SqlCommandBuilder cmdBuilder;

        public DBConnect()
        {
            string connstring = "Data Source=146.230.177.46;Initial Catalog=G7Pmb2024;Persist Security Info=True;User ID=G7Pmb2024;Password=gcsxga";
            conn = new SqlConnection(connstring);
            command = new SqlCommand("SELECT * FROM Service_Inventory", conn);
        }
        public DataTable QueryDT()
        {
            conn.Open();
            da = new SqlDataAdapter(command);
            dt = new DataTable();
            da.Fill(dt);
            conn.Close();
            return dt;
        }
        public DataTable GetProductTbl()
        {
            // string sqlStatement= ""
            command = new SqlCommand("Select * from Inventory_tbl", conn);
            da = new SqlDataAdapter(command);
            dt = new DataTable();
            conn.Open();
            da.Fill(dt);
            conn.Close();
            return dt;
        }
    }
}
