﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StyleCutsBarberShopSystem
{
    public partial class TemplateUI : Form
    {
        private LoginUI login;
        private HomeScreenUI home;

        public TemplateUI()
        {
            InitializeComponent();

            login = new LoginUI();
            home = new HomeScreenUI();



            login.ButtonClicked += LoginUI_ButtonClicked;
            home.ButtonClicked += HomeScreenUI_ButtonClicked;

            LoadFormIntoPanel(login);
        }

        private void LoginUI_ButtonClicked(object sender, EventArgs e)
        {
            LoadFormIntoPanel(home);
        }

       private void HomeScreenUI_ButtonClicked(object sender, EventArgs e)
        {
            LoadFormIntoPanel(login);
        }

        public void LoadFormIntoPanel(Form form)
        {
            TemplatePanel.Controls.Clear();
            form.TopLevel = false;
            TemplatePanel.Controls.Add(form);
            form.Dock = DockStyle.Fill;
            form.Show();
        }
    }
}