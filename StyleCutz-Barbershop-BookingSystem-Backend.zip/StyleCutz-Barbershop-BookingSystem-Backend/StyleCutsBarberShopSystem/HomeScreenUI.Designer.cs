﻿
namespace StyleCutsBarberShopSystem
{
    partial class HomeScreenUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sidebar = new System.Windows.Forms.Panel();
            this.reportsBtn = new FontAwesome.Sharp.IconButton();
            this.inventoryBtn = new FontAwesome.Sharp.IconButton();
            this.suppliersBtn = new FontAwesome.Sharp.IconButton();
            this.logoutBtn = new FontAwesome.Sharp.IconButton();
            this.CustomersBtn = new FontAwesome.Sharp.IconButton();
            this.BarbersBtn = new FontAwesome.Sharp.IconButton();
            this.AppointmentsBtn = new FontAwesome.Sharp.IconButton();
            this.servicesBtn = new FontAwesome.Sharp.IconButton();
            this.homeBtn = new FontAwesome.Sharp.IconButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.MenuBtn = new FontAwesome.Sharp.IconButton();
            this.ParentPanel = new System.Windows.Forms.Panel();
            this.taAppointments = new StyleCutsBarberShopSystem.dsG7TableAdapters.Appointment_tblTableAdapter();
            this.taService = new StyleCutsBarberShopSystem.dsG7TableAdapters.ServiceTableAdapter();
            this.sidebar.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // sidebar
            // 
            this.sidebar.BackColor = System.Drawing.Color.Navy;
            this.sidebar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sidebar.Controls.Add(this.reportsBtn);
            this.sidebar.Controls.Add(this.inventoryBtn);
            this.sidebar.Controls.Add(this.suppliersBtn);
            this.sidebar.Controls.Add(this.logoutBtn);
            this.sidebar.Controls.Add(this.CustomersBtn);
            this.sidebar.Controls.Add(this.BarbersBtn);
            this.sidebar.Controls.Add(this.AppointmentsBtn);
            this.sidebar.Controls.Add(this.servicesBtn);
            this.sidebar.Controls.Add(this.homeBtn);
            this.sidebar.Controls.Add(this.panel2);
            this.sidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidebar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sidebar.Location = new System.Drawing.Point(0, 0);
            this.sidebar.Margin = new System.Windows.Forms.Padding(4);
            this.sidebar.Name = "sidebar";
            this.sidebar.Size = new System.Drawing.Size(267, 588);
            this.sidebar.TabIndex = 0;
            // 
            // reportsBtn
            // 
            this.reportsBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.reportsBtn.FlatAppearance.BorderSize = 0;
            this.reportsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.reportsBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reportsBtn.IconChar = FontAwesome.Sharp.IconChar.ChartColumn;
            this.reportsBtn.IconColor = System.Drawing.Color.White;
            this.reportsBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.reportsBtn.IconSize = 31;
            this.reportsBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.reportsBtn.Location = new System.Drawing.Point(0, 310);
            this.reportsBtn.Margin = new System.Windows.Forms.Padding(4);
            this.reportsBtn.Name = "reportsBtn";
            this.reportsBtn.Padding = new System.Windows.Forms.Padding(13, 0, 27, 0);
            this.reportsBtn.Size = new System.Drawing.Size(267, 35);
            this.reportsBtn.TabIndex = 10;
            this.reportsBtn.Tag = "Reports";
            this.reportsBtn.Text = "Reports";
            this.reportsBtn.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.reportsBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.reportsBtn.UseVisualStyleBackColor = true;
            this.reportsBtn.Click += new System.EventHandler(this.reportsBtn_Click);
            // 
            // inventoryBtn
            // 
            this.inventoryBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.inventoryBtn.FlatAppearance.BorderSize = 0;
            this.inventoryBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.inventoryBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inventoryBtn.IconChar = FontAwesome.Sharp.IconChar.BoxesAlt;
            this.inventoryBtn.IconColor = System.Drawing.Color.White;
            this.inventoryBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.inventoryBtn.IconSize = 31;
            this.inventoryBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.inventoryBtn.Location = new System.Drawing.Point(0, 275);
            this.inventoryBtn.Margin = new System.Windows.Forms.Padding(4);
            this.inventoryBtn.Name = "inventoryBtn";
            this.inventoryBtn.Padding = new System.Windows.Forms.Padding(13, 0, 27, 0);
            this.inventoryBtn.Size = new System.Drawing.Size(267, 35);
            this.inventoryBtn.TabIndex = 9;
            this.inventoryBtn.Tag = "Inventory";
            this.inventoryBtn.Text = "Inventory";
            this.inventoryBtn.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.inventoryBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.inventoryBtn.UseVisualStyleBackColor = true;
            this.inventoryBtn.Click += new System.EventHandler(this.inventoryBtn_Click);
            // 
            // suppliersBtn
            // 
            this.suppliersBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.suppliersBtn.FlatAppearance.BorderSize = 0;
            this.suppliersBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.suppliersBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.suppliersBtn.IconChar = FontAwesome.Sharp.IconChar.Users;
            this.suppliersBtn.IconColor = System.Drawing.Color.White;
            this.suppliersBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.suppliersBtn.IconSize = 31;
            this.suppliersBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.suppliersBtn.Location = new System.Drawing.Point(0, 240);
            this.suppliersBtn.Margin = new System.Windows.Forms.Padding(4);
            this.suppliersBtn.Name = "suppliersBtn";
            this.suppliersBtn.Padding = new System.Windows.Forms.Padding(13, 0, 27, 0);
            this.suppliersBtn.Size = new System.Drawing.Size(267, 35);
            this.suppliersBtn.TabIndex = 8;
            this.suppliersBtn.Tag = "Suppliers";
            this.suppliersBtn.Text = "Suppliers";
            this.suppliersBtn.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.suppliersBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.suppliersBtn.UseVisualStyleBackColor = true;
            this.suppliersBtn.Click += new System.EventHandler(this.suppliersBtn_Click);
            // 
            // logoutBtn
            // 
            this.logoutBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.logoutBtn.FlatAppearance.BorderSize = 0;
            this.logoutBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logoutBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutBtn.IconChar = FontAwesome.Sharp.IconChar.ArrowRightFromBracket;
            this.logoutBtn.IconColor = System.Drawing.Color.White;
            this.logoutBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.logoutBtn.IconSize = 31;
            this.logoutBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.logoutBtn.Location = new System.Drawing.Point(0, 551);
            this.logoutBtn.Margin = new System.Windows.Forms.Padding(4);
            this.logoutBtn.Name = "logoutBtn";
            this.logoutBtn.Padding = new System.Windows.Forms.Padding(13, 0, 27, 0);
            this.logoutBtn.Size = new System.Drawing.Size(267, 37);
            this.logoutBtn.TabIndex = 7;
            this.logoutBtn.Tag = "Logout";
            this.logoutBtn.Text = "Logout";
            this.logoutBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.logoutBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.logoutBtn.UseVisualStyleBackColor = true;
            this.logoutBtn.Click += new System.EventHandler(this.logoutBtn_Click);
            // 
            // CustomersBtn
            // 
            this.CustomersBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.CustomersBtn.FlatAppearance.BorderSize = 0;
            this.CustomersBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CustomersBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomersBtn.IconChar = FontAwesome.Sharp.IconChar.Users;
            this.CustomersBtn.IconColor = System.Drawing.Color.White;
            this.CustomersBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.CustomersBtn.IconSize = 31;
            this.CustomersBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CustomersBtn.Location = new System.Drawing.Point(0, 205);
            this.CustomersBtn.Margin = new System.Windows.Forms.Padding(4);
            this.CustomersBtn.Name = "CustomersBtn";
            this.CustomersBtn.Padding = new System.Windows.Forms.Padding(13, 0, 27, 0);
            this.CustomersBtn.Size = new System.Drawing.Size(267, 35);
            this.CustomersBtn.TabIndex = 6;
            this.CustomersBtn.Tag = "Customers";
            this.CustomersBtn.Text = "Customers";
            this.CustomersBtn.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.CustomersBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.CustomersBtn.UseVisualStyleBackColor = true;
            this.CustomersBtn.Click += new System.EventHandler(this.CustomersBtn_Click);
            // 
            // BarbersBtn
            // 
            this.BarbersBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.BarbersBtn.FlatAppearance.BorderSize = 0;
            this.BarbersBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BarbersBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BarbersBtn.IconChar = FontAwesome.Sharp.IconChar.Users;
            this.BarbersBtn.IconColor = System.Drawing.Color.White;
            this.BarbersBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.BarbersBtn.IconSize = 31;
            this.BarbersBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BarbersBtn.Location = new System.Drawing.Point(0, 170);
            this.BarbersBtn.Margin = new System.Windows.Forms.Padding(4);
            this.BarbersBtn.Name = "BarbersBtn";
            this.BarbersBtn.Padding = new System.Windows.Forms.Padding(13, 0, 27, 0);
            this.BarbersBtn.Size = new System.Drawing.Size(267, 35);
            this.BarbersBtn.TabIndex = 5;
            this.BarbersBtn.Tag = "Employees";
            this.BarbersBtn.Text = "Employees";
            this.BarbersBtn.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.BarbersBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.BarbersBtn.UseVisualStyleBackColor = true;
            this.BarbersBtn.Click += new System.EventHandler(this.BarbersBtn_Click);
            // 
            // AppointmentsBtn
            // 
            this.AppointmentsBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.AppointmentsBtn.FlatAppearance.BorderSize = 0;
            this.AppointmentsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AppointmentsBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AppointmentsBtn.IconChar = FontAwesome.Sharp.IconChar.CalendarCheck;
            this.AppointmentsBtn.IconColor = System.Drawing.Color.White;
            this.AppointmentsBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.AppointmentsBtn.IconSize = 31;
            this.AppointmentsBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.AppointmentsBtn.Location = new System.Drawing.Point(0, 135);
            this.AppointmentsBtn.Margin = new System.Windows.Forms.Padding(4);
            this.AppointmentsBtn.Name = "AppointmentsBtn";
            this.AppointmentsBtn.Padding = new System.Windows.Forms.Padding(13, 0, 27, 0);
            this.AppointmentsBtn.Size = new System.Drawing.Size(267, 35);
            this.AppointmentsBtn.TabIndex = 4;
            this.AppointmentsBtn.Tag = "Appointments";
            this.AppointmentsBtn.Text = "Appointments";
            this.AppointmentsBtn.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.AppointmentsBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.AppointmentsBtn.UseVisualStyleBackColor = true;
            this.AppointmentsBtn.Click += new System.EventHandler(this.AppointmentsBtn_Click);
            // 
            // servicesBtn
            // 
            this.servicesBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.servicesBtn.FlatAppearance.BorderSize = 0;
            this.servicesBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.servicesBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.servicesBtn.IconChar = FontAwesome.Sharp.IconChar.Scissors;
            this.servicesBtn.IconColor = System.Drawing.Color.White;
            this.servicesBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.servicesBtn.IconSize = 31;
            this.servicesBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.servicesBtn.Location = new System.Drawing.Point(0, 100);
            this.servicesBtn.Margin = new System.Windows.Forms.Padding(4);
            this.servicesBtn.Name = "servicesBtn";
            this.servicesBtn.Padding = new System.Windows.Forms.Padding(13, 0, 27, 0);
            this.servicesBtn.Size = new System.Drawing.Size(267, 35);
            this.servicesBtn.TabIndex = 3;
            this.servicesBtn.Tag = "Services";
            this.servicesBtn.Text = "Services";
            this.servicesBtn.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.servicesBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.servicesBtn.UseVisualStyleBackColor = true;
            this.servicesBtn.Click += new System.EventHandler(this.servicesBtn_Click);
            // 
            // homeBtn
            // 
            this.homeBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.homeBtn.FlatAppearance.BorderSize = 0;
            this.homeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.homeBtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeBtn.IconChar = FontAwesome.Sharp.IconChar.House;
            this.homeBtn.IconColor = System.Drawing.Color.White;
            this.homeBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.homeBtn.IconSize = 31;
            this.homeBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.homeBtn.Location = new System.Drawing.Point(0, 65);
            this.homeBtn.Margin = new System.Windows.Forms.Padding(4);
            this.homeBtn.Name = "homeBtn";
            this.homeBtn.Padding = new System.Windows.Forms.Padding(13, 0, 27, 0);
            this.homeBtn.Size = new System.Drawing.Size(267, 35);
            this.homeBtn.TabIndex = 2;
            this.homeBtn.Tag = "Home";
            this.homeBtn.Text = "Home";
            this.homeBtn.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.homeBtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.homeBtn.UseVisualStyleBackColor = true;
            this.homeBtn.Click += new System.EventHandler(this.homeBtn_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.MenuBtn);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(267, 65);
            this.panel2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(63, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Menu";
            // 
            // MenuBtn
            // 
            this.MenuBtn.Dock = System.Windows.Forms.DockStyle.Left;
            this.MenuBtn.FlatAppearance.BorderSize = 0;
            this.MenuBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MenuBtn.IconChar = FontAwesome.Sharp.IconChar.Navicon;
            this.MenuBtn.IconColor = System.Drawing.Color.White;
            this.MenuBtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.MenuBtn.IconSize = 44;
            this.MenuBtn.Location = new System.Drawing.Point(0, 0);
            this.MenuBtn.Name = "MenuBtn";
            this.MenuBtn.Size = new System.Drawing.Size(72, 65);
            this.MenuBtn.TabIndex = 0;
            this.MenuBtn.UseVisualStyleBackColor = true;
            this.MenuBtn.Click += new System.EventHandler(this.MenuBtn_Click);
            // 
            // ParentPanel
            // 
            this.ParentPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ParentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ParentPanel.Location = new System.Drawing.Point(267, 0);
            this.ParentPanel.Name = "ParentPanel";
            this.ParentPanel.Size = new System.Drawing.Size(800, 588);
            this.ParentPanel.TabIndex = 0;
            // 
            // taAppointments
            // 
            this.taAppointments.ClearBeforeFill = true;
            // 
            // taService
            // 
            this.taService.ClearBeforeFill = true;
            // 
            // HomeScreenUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 588);
            this.Controls.Add(this.ParentPanel);
            this.Controls.Add(this.sidebar);
            this.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "HomeScreenUI";
            this.Text = "HomeScreenUI";
            this.Load += new System.EventHandler(this.HomeScreenUI_Load);
            this.sidebar.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sidebar;
        private FontAwesome.Sharp.IconButton logoutBtn;
        private FontAwesome.Sharp.IconButton CustomersBtn;
        private FontAwesome.Sharp.IconButton BarbersBtn;
        private FontAwesome.Sharp.IconButton AppointmentsBtn;
        private FontAwesome.Sharp.IconButton servicesBtn;
        private FontAwesome.Sharp.IconButton homeBtn;
        private System.Windows.Forms.Panel panel2;
        private FontAwesome.Sharp.IconButton reportsBtn;
        private FontAwesome.Sharp.IconButton inventoryBtn;
        private FontAwesome.Sharp.IconButton suppliersBtn;
        private FontAwesome.Sharp.IconButton MenuBtn;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Panel ParentPanel;
        private dsG7TableAdapters.Appointment_tblTableAdapter taAppointments;
        private dsG7TableAdapters.ServiceTableAdapter taService;
    }
}