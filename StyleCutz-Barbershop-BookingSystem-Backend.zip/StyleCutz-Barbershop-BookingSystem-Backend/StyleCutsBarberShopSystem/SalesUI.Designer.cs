﻿
namespace StyleCutsBarberShopSystem
{
    partial class SalesUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SalesUI));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.UDRemoveSelected = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.appointmentidDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicenameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicepriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serviceidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataTable1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsG71 = new StyleCutsBarberShopSystem.dsG7();
            this.gvAppointmentsSearchTB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.appointmentidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeenameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentmethodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentamountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.appointment_date1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timeSlotDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.appointmentstatusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentnumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employee_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.innerJoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.PrintBtn = new System.Windows.Forms.Button();
            this.GenerateBtn = new System.Windows.Forms.Button();
            this.txtRRB = new System.Windows.Forms.RichTextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.appointmentidDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicenameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicepriceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serviceidDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataTable1BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dsG72 = new StyleCutsBarberShopSystem.dsG7();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.appointmentidDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customernameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeenameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentmethodDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentamountDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timeSlotDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.appointmentstatusDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentnumberDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.appointmentdate1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.innerJoinBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.taInnerJoin1 = new StyleCutsBarberShopSystem.dsG7TableAdapters.InnerJoinTableAdapter();
            this.taTable1 = new StyleCutsBarberShopSystem.dsG7TableAdapters.DataTable1TableAdapter();
            this.taAppointment = new StyleCutsBarberShopSystem.dsG7TableAdapters.Appointment_tblTableAdapter();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.inventory_tblTableAdapter1 = new StyleCutsBarberShopSystem.dsG7TableAdapters.Inventory_tblTableAdapter();
            this.service_InventoryTableAdapter1 = new StyleCutsBarberShopSystem.dsG7TableAdapters.Service_InventoryTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.innerJoinBindingSource)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.innerJoinBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(832, 450);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.comboBox1);
            this.tabPage1.Controls.Add(this.UDRemoveSelected);
            this.tabPage1.Controls.Add(this.dataGridView2);
            this.tabPage1.Controls.Add(this.gvAppointmentsSearchTB);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(824, 424);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Process Sale";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(465, 319);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 20);
            this.label3.TabIndex = 43;
            this.label3.Text = "Payment:";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(465, 288);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(140, 20);
            this.label2.TabIndex = 42;
            this.label2.Text = "Payment Method:";
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(465, 262);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(123, 20);
            this.label15.TabIndex = 40;
            this.label15.Text = "Amount Owing:";
            // 
            // textBox2
            // 
            this.textBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox2.Location = new System.Drawing.Point(611, 319);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(207, 20);
            this.textBox2.TabIndex = 39;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox1.Location = new System.Drawing.Point(611, 262);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(207, 20);
            this.textBox1.TabIndex = 38;
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "cash",
            "card"});
            this.comboBox1.Location = new System.Drawing.Point(611, 288);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(207, 21);
            this.comboBox1.TabIndex = 37;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // UDRemoveSelected
            // 
            this.UDRemoveSelected.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UDRemoveSelected.BackColor = System.Drawing.Color.Navy;
            this.UDRemoveSelected.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.UDRemoveSelected.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UDRemoveSelected.ForeColor = System.Drawing.Color.White;
            this.UDRemoveSelected.Location = new System.Drawing.Point(611, 363);
            this.UDRemoveSelected.Name = "UDRemoveSelected";
            this.UDRemoveSelected.Size = new System.Drawing.Size(207, 39);
            this.UDRemoveSelected.TabIndex = 36;
            this.UDRemoveSelected.Text = "Make Payment";
            this.UDRemoveSelected.UseVisualStyleBackColor = false;
            this.UDRemoveSelected.Click += new System.EventHandler(this.UDRemoveSelected_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.appointmentidDataGridViewTextBoxColumn1,
            this.servicenameDataGridViewTextBoxColumn,
            this.servicepriceDataGridViewTextBoxColumn,
            this.serviceidDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.dataTable1BindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(3, 252);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.dataGridView2.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView2.Size = new System.Drawing.Size(447, 150);
            this.dataGridView2.TabIndex = 35;
            // 
            // appointmentidDataGridViewTextBoxColumn1
            // 
            this.appointmentidDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.appointmentidDataGridViewTextBoxColumn1.DataPropertyName = "appointment_id";
            this.appointmentidDataGridViewTextBoxColumn1.HeaderText = "appointment_id";
            this.appointmentidDataGridViewTextBoxColumn1.Name = "appointmentidDataGridViewTextBoxColumn1";
            this.appointmentidDataGridViewTextBoxColumn1.ReadOnly = true;
            this.appointmentidDataGridViewTextBoxColumn1.Width = 104;
            // 
            // servicenameDataGridViewTextBoxColumn
            // 
            this.servicenameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.servicenameDataGridViewTextBoxColumn.DataPropertyName = "service_name";
            this.servicenameDataGridViewTextBoxColumn.HeaderText = "service_name";
            this.servicenameDataGridViewTextBoxColumn.Name = "servicenameDataGridViewTextBoxColumn";
            this.servicenameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // servicepriceDataGridViewTextBoxColumn
            // 
            this.servicepriceDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.servicepriceDataGridViewTextBoxColumn.DataPropertyName = "service_price";
            this.servicepriceDataGridViewTextBoxColumn.HeaderText = "service_price";
            this.servicepriceDataGridViewTextBoxColumn.Name = "servicepriceDataGridViewTextBoxColumn";
            this.servicepriceDataGridViewTextBoxColumn.ReadOnly = true;
            this.servicepriceDataGridViewTextBoxColumn.Width = 95;
            // 
            // serviceidDataGridViewTextBoxColumn
            // 
            this.serviceidDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.serviceidDataGridViewTextBoxColumn.DataPropertyName = "service_id";
            this.serviceidDataGridViewTextBoxColumn.HeaderText = "service_id";
            this.serviceidDataGridViewTextBoxColumn.Name = "serviceidDataGridViewTextBoxColumn";
            this.serviceidDataGridViewTextBoxColumn.ReadOnly = true;
            this.serviceidDataGridViewTextBoxColumn.Width = 80;
            // 
            // dataTable1BindingSource
            // 
            this.dataTable1BindingSource.DataMember = "DataTable1";
            this.dataTable1BindingSource.DataSource = this.dsG71;
            // 
            // dsG71
            // 
            this.dsG71.DataSetName = "dsG7";
            this.dsG71.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gvAppointmentsSearchTB
            // 
            this.gvAppointmentsSearchTB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gvAppointmentsSearchTB.ForeColor = System.Drawing.Color.Black;
            this.gvAppointmentsSearchTB.Location = new System.Drawing.Point(378, 31);
            this.gvAppointmentsSearchTB.Name = "gvAppointmentsSearchTB";
            this.gvAppointmentsSearchTB.Size = new System.Drawing.Size(178, 20);
            this.gvAppointmentsSearchTB.TabIndex = 34;
            this.gvAppointmentsSearchTB.TextChanged += new System.EventHandler(this.gvAppointmentsSearchTB_TextChanged);
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(233, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(131, 20);
            this.label6.TabIndex = 33;
            this.label6.Text = "Customer Name:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.appointmentidDataGridViewTextBoxColumn,
            this.customernameDataGridViewTextBoxColumn,
            this.employeenameDataGridViewTextBoxColumn,
            this.paymentmethodDataGridViewTextBoxColumn,
            this.paymentamountDataGridViewTextBoxColumn,
            this.appointment_date1,
            this.timeSlotDataGridViewTextBoxColumn,
            this.appointmentstatusDataGridViewTextBoxColumn,
            this.studentnumberDataGridViewTextBoxColumn,
            this.employee_id});
            this.dataGridView1.DataSource = this.innerJoinBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(3, 67);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Size = new System.Drawing.Size(815, 179);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // appointmentidDataGridViewTextBoxColumn
            // 
            this.appointmentidDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.appointmentidDataGridViewTextBoxColumn.DataPropertyName = "appointment_id";
            this.appointmentidDataGridViewTextBoxColumn.HeaderText = "id";
            this.appointmentidDataGridViewTextBoxColumn.Name = "appointmentidDataGridViewTextBoxColumn";
            this.appointmentidDataGridViewTextBoxColumn.ReadOnly = true;
            this.appointmentidDataGridViewTextBoxColumn.Width = 40;
            // 
            // customernameDataGridViewTextBoxColumn
            // 
            this.customernameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.customernameDataGridViewTextBoxColumn.DataPropertyName = "customer_name";
            this.customernameDataGridViewTextBoxColumn.HeaderText = "customer_name";
            this.customernameDataGridViewTextBoxColumn.Name = "customernameDataGridViewTextBoxColumn";
            this.customernameDataGridViewTextBoxColumn.ReadOnly = true;
            this.customernameDataGridViewTextBoxColumn.Width = 107;
            // 
            // employeenameDataGridViewTextBoxColumn
            // 
            this.employeenameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.employeenameDataGridViewTextBoxColumn.DataPropertyName = "employee_name";
            this.employeenameDataGridViewTextBoxColumn.HeaderText = "employee_name";
            this.employeenameDataGridViewTextBoxColumn.Name = "employeenameDataGridViewTextBoxColumn";
            this.employeenameDataGridViewTextBoxColumn.ReadOnly = true;
            this.employeenameDataGridViewTextBoxColumn.Width = 109;
            // 
            // paymentmethodDataGridViewTextBoxColumn
            // 
            this.paymentmethodDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.paymentmethodDataGridViewTextBoxColumn.DataPropertyName = "payment_method";
            this.paymentmethodDataGridViewTextBoxColumn.HeaderText = "payment_method";
            this.paymentmethodDataGridViewTextBoxColumn.Name = "paymentmethodDataGridViewTextBoxColumn";
            this.paymentmethodDataGridViewTextBoxColumn.ReadOnly = true;
            this.paymentmethodDataGridViewTextBoxColumn.Width = 113;
            // 
            // paymentamountDataGridViewTextBoxColumn
            // 
            this.paymentamountDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.paymentamountDataGridViewTextBoxColumn.DataPropertyName = "payment_amount";
            this.paymentamountDataGridViewTextBoxColumn.HeaderText = "payment_amount";
            this.paymentamountDataGridViewTextBoxColumn.Name = "paymentamountDataGridViewTextBoxColumn";
            this.paymentamountDataGridViewTextBoxColumn.ReadOnly = true;
            this.paymentamountDataGridViewTextBoxColumn.Width = 113;
            // 
            // appointment_date1
            // 
            this.appointment_date1.DataPropertyName = "appointment_date1";
            this.appointment_date1.HeaderText = "date";
            this.appointment_date1.Name = "appointment_date1";
            this.appointment_date1.ReadOnly = true;
            // 
            // timeSlotDataGridViewTextBoxColumn
            // 
            this.timeSlotDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.timeSlotDataGridViewTextBoxColumn.DataPropertyName = "TimeSlot";
            this.timeSlotDataGridViewTextBoxColumn.HeaderText = "TimeSlot";
            this.timeSlotDataGridViewTextBoxColumn.Name = "timeSlotDataGridViewTextBoxColumn";
            this.timeSlotDataGridViewTextBoxColumn.ReadOnly = true;
            this.timeSlotDataGridViewTextBoxColumn.Width = 73;
            // 
            // appointmentstatusDataGridViewTextBoxColumn
            // 
            this.appointmentstatusDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.appointmentstatusDataGridViewTextBoxColumn.DataPropertyName = "appointment_status";
            this.appointmentstatusDataGridViewTextBoxColumn.HeaderText = "appointment_status";
            this.appointmentstatusDataGridViewTextBoxColumn.Name = "appointmentstatusDataGridViewTextBoxColumn";
            this.appointmentstatusDataGridViewTextBoxColumn.ReadOnly = true;
            this.appointmentstatusDataGridViewTextBoxColumn.Width = 124;
            // 
            // studentnumberDataGridViewTextBoxColumn
            // 
            this.studentnumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.studentnumberDataGridViewTextBoxColumn.DataPropertyName = "student_number";
            this.studentnumberDataGridViewTextBoxColumn.HeaderText = "student_number";
            this.studentnumberDataGridViewTextBoxColumn.Name = "studentnumberDataGridViewTextBoxColumn";
            this.studentnumberDataGridViewTextBoxColumn.ReadOnly = true;
            this.studentnumberDataGridViewTextBoxColumn.Width = 108;
            // 
            // employee_id
            // 
            this.employee_id.DataPropertyName = "employee_id";
            this.employee_id.HeaderText = "employee_id";
            this.employee_id.Name = "employee_id";
            this.employee_id.ReadOnly = true;
            // 
            // innerJoinBindingSource
            // 
            this.innerJoinBindingSource.DataMember = "InnerJoin";
            this.innerJoinBindingSource.DataSource = this.dsG71;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.PrintBtn);
            this.tabPage2.Controls.Add(this.GenerateBtn);
            this.tabPage2.Controls.Add(this.txtRRB);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(824, 424);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Generate Receipt";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button2.BackColor = System.Drawing.Color.Navy;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(17, 379);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(152, 39);
            this.button2.TabIndex = 44;
            this.button2.Text = "Previous";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.Color.Navy;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(649, 379);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(152, 39);
            this.button1.TabIndex = 43;
            this.button1.Text = "Next";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button3.BackColor = System.Drawing.Color.Navy;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(175, 379);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(152, 39);
            this.button3.TabIndex = 21;
            this.button3.Text = "Clear";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // PrintBtn
            // 
            this.PrintBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PrintBtn.BackColor = System.Drawing.Color.Navy;
            this.PrintBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.PrintBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintBtn.ForeColor = System.Drawing.Color.White;
            this.PrintBtn.Location = new System.Drawing.Point(491, 379);
            this.PrintBtn.Name = "PrintBtn";
            this.PrintBtn.Size = new System.Drawing.Size(152, 39);
            this.PrintBtn.TabIndex = 20;
            this.PrintBtn.Text = "Print";
            this.PrintBtn.UseVisualStyleBackColor = false;
            this.PrintBtn.Click += new System.EventHandler(this.PrintBtn_Click);
            // 
            // GenerateBtn
            // 
            this.GenerateBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.GenerateBtn.BackColor = System.Drawing.Color.Navy;
            this.GenerateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.GenerateBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenerateBtn.ForeColor = System.Drawing.Color.White;
            this.GenerateBtn.Location = new System.Drawing.Point(333, 379);
            this.GenerateBtn.Name = "GenerateBtn";
            this.GenerateBtn.Size = new System.Drawing.Size(152, 39);
            this.GenerateBtn.TabIndex = 19;
            this.GenerateBtn.Text = "Generate";
            this.GenerateBtn.UseVisualStyleBackColor = false;
            this.GenerateBtn.Click += new System.EventHandler(this.GenerateBtn_Click);
            // 
            // txtRRB
            // 
            this.txtRRB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtRRB.Location = new System.Drawing.Point(142, 25);
            this.txtRRB.Name = "txtRRB";
            this.txtRRB.Size = new System.Drawing.Size(517, 338);
            this.txtRRB.TabIndex = 18;
            this.txtRRB.Text = "";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button4);
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Controls.Add(this.dateTimePicker1);
            this.tabPage3.Controls.Add(this.dataGridView4);
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(824, 424);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "View Sales";
            this.toolTip1.SetToolTip(this.tabPage3, "Select date of appointments you want to view");
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button4.BackColor = System.Drawing.Color.Navy;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(8, 377);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(152, 39);
            this.button4.TabIndex = 45;
            this.button4.Text = "Previous";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(279, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Select Date:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(383, 9);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(119, 20);
            this.dateTimePicker1.TabIndex = 2;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // dataGridView4
            // 
            this.dataGridView4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.appointmentidDataGridViewTextBoxColumn3,
            this.servicenameDataGridViewTextBoxColumn1,
            this.servicepriceDataGridViewTextBoxColumn1,
            this.serviceidDataGridViewTextBoxColumn1});
            this.dataGridView4.DataSource = this.dataTable1BindingSource1;
            this.dataGridView4.Location = new System.Drawing.Point(5, 210);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.ReadOnly = true;
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.dataGridView4.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView4.Size = new System.Drawing.Size(816, 150);
            this.dataGridView4.TabIndex = 1;
            // 
            // appointmentidDataGridViewTextBoxColumn3
            // 
            this.appointmentidDataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.appointmentidDataGridViewTextBoxColumn3.DataPropertyName = "appointment_id";
            this.appointmentidDataGridViewTextBoxColumn3.HeaderText = "appointment_id";
            this.appointmentidDataGridViewTextBoxColumn3.Name = "appointmentidDataGridViewTextBoxColumn3";
            this.appointmentidDataGridViewTextBoxColumn3.ReadOnly = true;
            this.appointmentidDataGridViewTextBoxColumn3.Width = 104;
            // 
            // servicenameDataGridViewTextBoxColumn1
            // 
            this.servicenameDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.servicenameDataGridViewTextBoxColumn1.DataPropertyName = "service_name";
            this.servicenameDataGridViewTextBoxColumn1.HeaderText = "service_name";
            this.servicenameDataGridViewTextBoxColumn1.Name = "servicenameDataGridViewTextBoxColumn1";
            this.servicenameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // servicepriceDataGridViewTextBoxColumn1
            // 
            this.servicepriceDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.servicepriceDataGridViewTextBoxColumn1.DataPropertyName = "service_price";
            this.servicepriceDataGridViewTextBoxColumn1.HeaderText = "service_price";
            this.servicepriceDataGridViewTextBoxColumn1.Name = "servicepriceDataGridViewTextBoxColumn1";
            this.servicepriceDataGridViewTextBoxColumn1.ReadOnly = true;
            this.servicepriceDataGridViewTextBoxColumn1.Width = 95;
            // 
            // serviceidDataGridViewTextBoxColumn1
            // 
            this.serviceidDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.serviceidDataGridViewTextBoxColumn1.DataPropertyName = "service_id";
            this.serviceidDataGridViewTextBoxColumn1.HeaderText = "service_id";
            this.serviceidDataGridViewTextBoxColumn1.Name = "serviceidDataGridViewTextBoxColumn1";
            this.serviceidDataGridViewTextBoxColumn1.ReadOnly = true;
            this.serviceidDataGridViewTextBoxColumn1.Width = 80;
            // 
            // dataTable1BindingSource1
            // 
            this.dataTable1BindingSource1.DataMember = "DataTable1";
            this.dataTable1BindingSource1.DataSource = this.dsG72;
            // 
            // dsG72
            // 
            this.dsG72.DataSetName = "dsG7";
            this.dsG72.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView3
            // 
            this.dataGridView3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.appointmentidDataGridViewTextBoxColumn2,
            this.customernameDataGridViewTextBoxColumn1,
            this.employeenameDataGridViewTextBoxColumn1,
            this.paymentmethodDataGridViewTextBoxColumn1,
            this.paymentamountDataGridViewTextBoxColumn1,
            this.timeSlotDataGridViewTextBoxColumn1,
            this.appointmentstatusDataGridViewTextBoxColumn1,
            this.studentnumberDataGridViewTextBoxColumn1,
            this.appointmentdate1DataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.innerJoinBindingSource1;
            this.dataGridView3.Location = new System.Drawing.Point(5, 43);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.dataGridView3.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView3.Size = new System.Drawing.Size(816, 150);
            this.dataGridView3.TabIndex = 0;
            this.dataGridView3.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellClick);
            // 
            // appointmentidDataGridViewTextBoxColumn2
            // 
            this.appointmentidDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.appointmentidDataGridViewTextBoxColumn2.DataPropertyName = "appointment_id";
            this.appointmentidDataGridViewTextBoxColumn2.HeaderText = "appointment_id";
            this.appointmentidDataGridViewTextBoxColumn2.Name = "appointmentidDataGridViewTextBoxColumn2";
            this.appointmentidDataGridViewTextBoxColumn2.ReadOnly = true;
            this.appointmentidDataGridViewTextBoxColumn2.Width = 104;
            // 
            // customernameDataGridViewTextBoxColumn1
            // 
            this.customernameDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.customernameDataGridViewTextBoxColumn1.DataPropertyName = "customer_name";
            this.customernameDataGridViewTextBoxColumn1.HeaderText = "customer_name";
            this.customernameDataGridViewTextBoxColumn1.Name = "customernameDataGridViewTextBoxColumn1";
            this.customernameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.customernameDataGridViewTextBoxColumn1.Width = 107;
            // 
            // employeenameDataGridViewTextBoxColumn1
            // 
            this.employeenameDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.employeenameDataGridViewTextBoxColumn1.DataPropertyName = "employee_name";
            this.employeenameDataGridViewTextBoxColumn1.HeaderText = "employee_name";
            this.employeenameDataGridViewTextBoxColumn1.Name = "employeenameDataGridViewTextBoxColumn1";
            this.employeenameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.employeenameDataGridViewTextBoxColumn1.Width = 109;
            // 
            // paymentmethodDataGridViewTextBoxColumn1
            // 
            this.paymentmethodDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.paymentmethodDataGridViewTextBoxColumn1.DataPropertyName = "payment_method";
            this.paymentmethodDataGridViewTextBoxColumn1.HeaderText = "payment_method";
            this.paymentmethodDataGridViewTextBoxColumn1.Name = "paymentmethodDataGridViewTextBoxColumn1";
            this.paymentmethodDataGridViewTextBoxColumn1.ReadOnly = true;
            this.paymentmethodDataGridViewTextBoxColumn1.Width = 113;
            // 
            // paymentamountDataGridViewTextBoxColumn1
            // 
            this.paymentamountDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.paymentamountDataGridViewTextBoxColumn1.DataPropertyName = "payment_amount";
            this.paymentamountDataGridViewTextBoxColumn1.HeaderText = "payment_amount";
            this.paymentamountDataGridViewTextBoxColumn1.Name = "paymentamountDataGridViewTextBoxColumn1";
            this.paymentamountDataGridViewTextBoxColumn1.ReadOnly = true;
            this.paymentamountDataGridViewTextBoxColumn1.Width = 113;
            // 
            // timeSlotDataGridViewTextBoxColumn1
            // 
            this.timeSlotDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.timeSlotDataGridViewTextBoxColumn1.DataPropertyName = "TimeSlot";
            this.timeSlotDataGridViewTextBoxColumn1.HeaderText = "TimeSlot";
            this.timeSlotDataGridViewTextBoxColumn1.Name = "timeSlotDataGridViewTextBoxColumn1";
            this.timeSlotDataGridViewTextBoxColumn1.ReadOnly = true;
            this.timeSlotDataGridViewTextBoxColumn1.Width = 73;
            // 
            // appointmentstatusDataGridViewTextBoxColumn1
            // 
            this.appointmentstatusDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.appointmentstatusDataGridViewTextBoxColumn1.DataPropertyName = "appointment_status";
            this.appointmentstatusDataGridViewTextBoxColumn1.HeaderText = "appointment_status";
            this.appointmentstatusDataGridViewTextBoxColumn1.Name = "appointmentstatusDataGridViewTextBoxColumn1";
            this.appointmentstatusDataGridViewTextBoxColumn1.ReadOnly = true;
            this.appointmentstatusDataGridViewTextBoxColumn1.Width = 124;
            // 
            // studentnumberDataGridViewTextBoxColumn1
            // 
            this.studentnumberDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.studentnumberDataGridViewTextBoxColumn1.DataPropertyName = "student_number";
            this.studentnumberDataGridViewTextBoxColumn1.HeaderText = "student_number";
            this.studentnumberDataGridViewTextBoxColumn1.Name = "studentnumberDataGridViewTextBoxColumn1";
            this.studentnumberDataGridViewTextBoxColumn1.ReadOnly = true;
            this.studentnumberDataGridViewTextBoxColumn1.Width = 108;
            // 
            // appointmentdate1DataGridViewTextBoxColumn
            // 
            this.appointmentdate1DataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.appointmentdate1DataGridViewTextBoxColumn.DataPropertyName = "appointment_date1";
            this.appointmentdate1DataGridViewTextBoxColumn.HeaderText = "appointment_date1";
            this.appointmentdate1DataGridViewTextBoxColumn.Name = "appointmentdate1DataGridViewTextBoxColumn";
            this.appointmentdate1DataGridViewTextBoxColumn.ReadOnly = true;
            this.appointmentdate1DataGridViewTextBoxColumn.Width = 123;
            // 
            // innerJoinBindingSource1
            // 
            this.innerJoinBindingSource1.DataMember = "InnerJoin";
            this.innerJoinBindingSource1.DataSource = this.dsG72;
            // 
            // taInnerJoin1
            // 
            this.taInnerJoin1.ClearBeforeFill = true;
            // 
            // taTable1
            // 
            this.taTable1.ClearBeforeFill = true;
            // 
            // taAppointment
            // 
            this.taAppointment.ClearBeforeFill = true;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // inventory_tblTableAdapter1
            // 
            this.inventory_tblTableAdapter1.ClearBeforeFill = true;
            // 
            // service_InventoryTableAdapter1
            // 
            this.service_InventoryTableAdapter1.ClearBeforeFill = true;
            // 
            // SalesUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(832, 450);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SalesUI";
            this.Text = "SalesUI";
            this.Load += new System.EventHandler(this.SalesUI_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.innerJoinBindingSource)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.innerJoinBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource innerJoinBindingSource;
        private dsG7 dsG71;
        private dsG7TableAdapters.InnerJoinTableAdapter taInnerJoin1;
        private System.Windows.Forms.TextBox gvAppointmentsSearchTB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingSource dataTable1BindingSource;
        private dsG7TableAdapters.DataTable1TableAdapter taTable1;
        private System.Windows.Forms.DataGridViewTextBoxColumn appointmentidDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicenameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicepriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceidDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        public System.Windows.Forms.Button UDRemoveSelected;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridViewTextBoxColumn appointmentidDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicenameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicepriceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceidDataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource dataTable1BindingSource1;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn appointmentidDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn customernameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeenameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentmethodDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentamountDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn timeSlotDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn appointmentstatusDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentnumberDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn appointmentdate1DataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource innerJoinBindingSource1;
        private dsG7 dsG72;
        private dsG7TableAdapters.Appointment_tblTableAdapter taAppointment;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button PrintBtn;
        private System.Windows.Forms.Button GenerateBtn;
        private System.Windows.Forms.RichTextBox txtRRB;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolTip toolTip1;
        private dsG7TableAdapters.Inventory_tblTableAdapter inventory_tblTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn appointmentidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeenameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentmethodDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentamountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn appointment_date1;
        private System.Windows.Forms.DataGridViewTextBoxColumn timeSlotDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn appointmentstatusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentnumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employee_id;
        private dsG7TableAdapters.Service_InventoryTableAdapter service_InventoryTableAdapter1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
    }
}