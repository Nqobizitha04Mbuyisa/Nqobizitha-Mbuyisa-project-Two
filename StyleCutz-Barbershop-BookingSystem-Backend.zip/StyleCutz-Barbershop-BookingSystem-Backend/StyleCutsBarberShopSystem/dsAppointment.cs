﻿namespace StyleCutsBarberShopSystem
{


    partial class dsAppointment
    {
    }
}
