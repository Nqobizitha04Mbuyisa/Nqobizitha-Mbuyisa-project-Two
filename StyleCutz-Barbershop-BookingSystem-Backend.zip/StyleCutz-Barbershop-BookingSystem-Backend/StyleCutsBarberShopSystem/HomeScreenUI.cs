﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StyleCutsBarberShopSystem
{
    public partial class HomeScreenUI : Form
    {
        public event EventHandler ButtonClicked;

        bool sideBarExpand;
        
        public HomeScreenUI()
        {
            InitializeComponent();
            CollapseMenu();
        }

        
        bool appointmentsMenuOpen = false;
        ContextMenuStrip appointmentsMenu = new ContextMenuStrip();

        private void AppointmentsBtn_Click(object sender, EventArgs e)
        {
            if (!appointmentsMenuOpen)
            {
                // Clear existing sub-buttons
                appointmentsMenu.Items.Clear();
               

                // Add sub-buttons to the context menu strip
                if (GlobalVariables.username == "Mpiyakhe" || GlobalVariables.username == "Mohomed")
                {
                    ToolStripMenuItem bookAppointmentBtn = new ToolStripMenuItem("Book Appointment");

                    // Apply the same style as AppointmentsBtn to the sub-buttons
                    bookAppointmentBtn.BackColor = AppointmentsBtn.BackColor;
                    bookAppointmentBtn.ForeColor = AppointmentsBtn.ForeColor;
                    bookAppointmentBtn.Font = AppointmentsBtn.Font;

                    bookAppointmentBtn.Click += BookAppointmentBtn_Click;
                    appointmentsMenu.Items.Add(bookAppointmentBtn);

                    ToolStripMenuItem saleBtn = new ToolStripMenuItem("Manage Sales");
                    saleBtn.BackColor = AppointmentsBtn.BackColor;
                    saleBtn.ForeColor = AppointmentsBtn.ForeColor;
                    saleBtn.Font = AppointmentsBtn.Font;
                    saleBtn.Click += saleBtn_Click;
                    appointmentsMenu.Items.Add(saleBtn);
                }
                

                ToolStripMenuItem viewAppointmentBtn = new ToolStripMenuItem("Manage Appointment");

                viewAppointmentBtn.BackColor = AppointmentsBtn.BackColor;
                viewAppointmentBtn.ForeColor = AppointmentsBtn.ForeColor;
                viewAppointmentBtn.Font = AppointmentsBtn.Font;

                // Add event handlers for sub-buttons
                viewAppointmentBtn.Click += ViewAppointmentBtn_Click;

                // Add sub-buttons to the context menu strip
                appointmentsMenu.Items.Add(viewAppointmentBtn);

                

                // Show the context menu strip at the position of the IconButton
                Point pos = AppointmentsBtn.PointToScreen(new Point(0, AppointmentsBtn.Height));
                appointmentsMenu.Show(pos);

                appointmentsMenuOpen = true;
            }
            else
            {
                // Close the context menu strip
                appointmentsMenu.Close();
                appointmentsMenuOpen = false;
            }
        }

        private void BookAppointmentBtn_Click(object sender, EventArgs e)
        {
            appointmentsMenuOpen = false;
            // Handle the click event for booking an appointment
            BookAppointmentUI book = new BookAppointmentUI();
            LoadFormIntoPanel(book);
        }

        private void ViewAppointmentBtn_Click(object sender, EventArgs e)
        {
            appointmentsMenuOpen = false;
            // Handle the click event for viewing appointments
            ViewAppointmentUI app = new ViewAppointmentUI();
            //app.vAppointmentSubmitTB.Click();
            LoadFormIntoPanel(app);

            if (GlobalVariables.username != "Mohomed" || GlobalVariables.username != "Mpiyakhe")
            {
                app.cancelAppointmentBtn.Enabled = false;
                app.UDRemoveSelected.Enabled = false;
                app.UDRemoveAll.Enabled = false;
                app.updateBtn.Enabled = false;

                app.UDRemoveSelected.BackColor = Color.Gray;
                app.updateBtn.BackColor = Color.Gray;
                app.UDRemoveAll.BackColor = Color.Gray;
                app.cancelAppointmentBtn.BackColor = Color.Gray;
            }
            if (GlobalVariables.username == "Mohomed" || GlobalVariables.username == "Mpiyakhe")
            {
                app.cancelAppointmentBtn.Enabled = true;
                app.UDRemoveSelected.Enabled = true;
                app.UDRemoveAll.Enabled = true;
                app.updateBtn.Enabled = true;

                app.UDRemoveSelected.BackColor = Color.Navy;
                app.updateBtn.BackColor = Color.Navy;
                app.UDRemoveAll.BackColor = Color.Navy;
                app.cancelAppointmentBtn.BackColor = Color.Navy;
            }
        }
        private void saleBtn_Click(object sender, EventArgs e)
        {
            appointmentsMenuOpen = false;
            SalesUI sales = new SalesUI();
            LoadFormIntoPanel(sales);
        }


        bool barbersMenuOpen = false;
        ContextMenuStrip barbersMenu = new ContextMenuStrip();

        private void BarbersBtn_Click(object sender, EventArgs e)
        {
            if (!barbersMenuOpen)
            {
                // Clear existing sub-buttons
                barbersMenu.Items.Clear();

                // Add sub-buttons to the context menu strip
                if (GlobalVariables.username == "Mpiyakhe" || GlobalVariables.username == "Mohomed")
                {
                    ToolStripMenuItem addBarberBtn = new ToolStripMenuItem("Add Employee");
                    // Apply the same style as AppointmentsBtn to the sub-buttons
                    addBarberBtn.BackColor = AppointmentsBtn.BackColor;
                    addBarberBtn.ForeColor = AppointmentsBtn.ForeColor;
                    addBarberBtn.Font = AppointmentsBtn.Font;

                    addBarberBtn.Click += AddBarberBtn_Click;
                    barbersMenu.Items.Add(addBarberBtn);

                }
                    
                ToolStripMenuItem viewBarberBtn = new ToolStripMenuItem("Manage Employees");

                

                viewBarberBtn.BackColor = AppointmentsBtn.BackColor;
                viewBarberBtn.ForeColor = AppointmentsBtn.ForeColor;
                viewBarberBtn.Font = AppointmentsBtn.Font;

                // Add event handlers to the sub-buttons
                
                viewBarberBtn.Click += ViewBarberBtn_Click;

                // Add sub-buttons to the context menu strip
                
                barbersMenu.Items.Add(viewBarberBtn);

                // Show the context menu strip at the position of the BarbersBtn
                Point pos = BarbersBtn.PointToScreen(new Point(0, BarbersBtn.Height));
                barbersMenu.Show(pos);

                barbersMenuOpen = true;
            }
            else
            {
                // Close the context menu strip
                barbersMenu.Close();
                barbersMenuOpen = false;
            }
        }

        private void AddBarberBtn_Click(object sender, EventArgs e)
        {
            barbersMenuOpen = false;
            //MessageBox.Show("Add Barber button clicked");
            AddBarberUI myBarb = new AddBarberUI();
            LoadFormIntoPanel(myBarb);
        }

        private void ViewBarberBtn_Click(object sender, EventArgs e)
        {
            barbersMenuOpen = false;
            //MessageBox.Show("View Barbers button clicked");
            ViewBarberUI barber = new ViewBarberUI();
            if (GlobalVariables.username != "Mohomed" || GlobalVariables.username != "Mpiyakhe")
            {
                barber.vBarberUpdateBtn.Enabled = false;
                barber.vBarberUpdateBtn.BackColor = Color.Gray;

                barber.deleteBtn.Enabled = false;
                barber.deleteBtn.BackColor = Color.Gray;
            }
            if (GlobalVariables.username == "Mohomed" || GlobalVariables.username == "Mpiyakhe")
            {
                barber.vBarberUpdateBtn.Enabled = true;
                barber.vBarberUpdateBtn.BackColor = Color.Navy;

                barber.deleteBtn.Enabled = true;
                barber.deleteBtn.BackColor = Color.Navy;
            }
            LoadFormIntoPanel(barber);

        }


        bool customersMenuOpen = false;
        ContextMenuStrip customersMenu = new ContextMenuStrip();

        private void CustomersBtn_Click(object sender, EventArgs e)
        {
            if (!customersMenuOpen)
            {
                // Clear existing sub-buttons
                customersMenu.Items.Clear();

                // Add sub-buttons to the context menu strip
                ToolStripMenuItem viewCustomersBtn = new ToolStripMenuItem("Manage Customers");

                // Apply the same style as AppointmentsBtn to the sub-buttons
                viewCustomersBtn.BackColor = AppointmentsBtn.BackColor;
                viewCustomersBtn.ForeColor = AppointmentsBtn.ForeColor;
                viewCustomersBtn.Font = AppointmentsBtn.Font;

                // Add event handler for the sub-buttons
                viewCustomersBtn.Click += ViewCustomersBtn_Click;

                // Add sub-button to the context menu strip
                customersMenu.Items.Add(viewCustomersBtn);

                // Show the context menu strip at the position of the CustomersBtn
                Point pos = CustomersBtn.PointToScreen(new Point(0, CustomersBtn.Height));
                customersMenu.Show(pos);

                customersMenuOpen = true;
            }
            else
            {
                // Close the context menu strip
                customersMenu.Close();
                customersMenuOpen = false;
            }
        }
        
        private void ViewCustomersBtn_Click(object sender, EventArgs e)
        {
            customersMenuOpen = false;
            // MessageBox.Show("View Customers button clicked");
            ViewCustomersUI cust = new ViewCustomersUI();
            if (GlobalVariables.username != "Mohomed" || GlobalVariables.username != "Mpiyakhe")
            {
                cust.vCustomerUpdateBtn.Enabled = false;
                cust.vCustomerUpdateBtn.BackColor = Color.Gray;
            }
            if (GlobalVariables.username == "Mohomed" || GlobalVariables.username == "Mpiyakhe")
            {
                cust.vCustomerUpdateBtn.Enabled = true;
                cust.vCustomerUpdateBtn.BackColor = Color.Navy;
            }
            LoadFormIntoPanel(cust);
        }


        bool suppliersMenuOpen = false;
        ContextMenuStrip suppliersMenu = new ContextMenuStrip();

        private void suppliersBtn_Click(object sender, EventArgs e)
        {
            if (!suppliersMenuOpen)
            {
                // Clear existing sub-buttons
                suppliersMenu.Items.Clear();

                // Add sub-buttons to the context menu strip
                if (GlobalVariables.username == "Mpiyakhe" || GlobalVariables.username == "Mohomed")
                {
                    ToolStripMenuItem addSupplierBtn = new ToolStripMenuItem("Add Supplier");

                    // Apply the same style as iconButton3 to the sub-buttons
                    addSupplierBtn.BackColor = AppointmentsBtn.BackColor;
                    addSupplierBtn.ForeColor = AppointmentsBtn.ForeColor;
                    addSupplierBtn.Font = AppointmentsBtn.Font;

                    addSupplierBtn.Click += AddSupplierBtn_Click;
                    suppliersMenu.Items.Add(addSupplierBtn);
                }
                    
                ToolStripMenuItem viewSuppliersBtn = new ToolStripMenuItem("Manage Suppliers");

                
                viewSuppliersBtn.BackColor = AppointmentsBtn.BackColor;
                viewSuppliersBtn.ForeColor = AppointmentsBtn.ForeColor;
                viewSuppliersBtn.Font = AppointmentsBtn.Font;

                // Add event handlers for the sub-buttons
                
                viewSuppliersBtn.Click += ViewSuppliersBtn_Click;

                // Add sub-buttons to the context menu strip
                
                suppliersMenu.Items.Add(viewSuppliersBtn);

                // Show the context menu strip at the position of the suppliersBtn
                Point pos = suppliersBtn.PointToScreen(new Point(0, suppliersBtn.Height));
                suppliersMenu.Show(pos);

                suppliersMenuOpen = true;
            }
            else
            {
                // Close the context menu strip
                suppliersMenu.Close();
                suppliersMenuOpen = false;
            }
        }

        private void AddSupplierBtn_Click(object sender, EventArgs e)
        {
            suppliersMenuOpen = false;
            //MessageBox.Show("Add Supplier button clicked");
            AddSupplierUI supp = new AddSupplierUI();
            LoadFormIntoPanel(supp);
        }

        private void ViewSuppliersBtn_Click(object sender, EventArgs e)
        {
            suppliersMenuOpen = false;
            //MessageBox.Show("View Suppliers button clicked");
            ViewSupplierUI supply = new ViewSupplierUI();
            if (GlobalVariables.username != "Mohomed" || GlobalVariables.username != "Mpiyakhe")
            {
                supply.vSupplierUpdateBtn.Enabled = false;
                supply.vSupplierUpdateBtn.BackColor = Color.Gray;

                supply.deleteBtn.Enabled = false;
                supply.deleteBtn.BackColor = Color.Gray;
            }
            if (GlobalVariables.username == "Mohomed" || GlobalVariables.username == "Mpiyakhe")
            {
                supply.vSupplierUpdateBtn.Enabled = true;
                supply.vSupplierUpdateBtn.BackColor = Color.Navy;

                supply.deleteBtn.Enabled = true;
                supply.deleteBtn.BackColor = Color.Navy;
            }
            LoadFormIntoPanel(supply);
        }



        bool inventoryMenuOpen = false;
        ContextMenuStrip inventoryMenu = new ContextMenuStrip();

        private void inventoryBtn_Click(object sender, EventArgs e)
        {
            if (!inventoryMenuOpen)
            {
                // Clear existing sub-buttons
                inventoryMenu.Items.Clear();

                // Add sub-buttons to the context menu strip
                if (GlobalVariables.username == "Mpiyakhe" || GlobalVariables.username == "Mohomed")
                {
                    ToolStripMenuItem addInventoryBtn = new ToolStripMenuItem("Add Product");

                    addInventoryBtn.BackColor = AppointmentsBtn.BackColor;
                    addInventoryBtn.ForeColor = AppointmentsBtn.ForeColor;
                    addInventoryBtn.Font = AppointmentsBtn.Font;

                    addInventoryBtn.Click += AddInventoryBtn_Click;
                    inventoryMenu.Items.Add(addInventoryBtn);
                   
                    ToolStripMenuItem updateStockbtn = new ToolStripMenuItem("Manage Stock");
                    updateStockbtn.BackColor = AppointmentsBtn.BackColor;
                    updateStockbtn.ForeColor = AppointmentsBtn.ForeColor;
                    updateStockbtn.Font = AppointmentsBtn.Font;

                    updateStockbtn.Click += UpdateStockbtn_Click;
                    inventoryMenu.Items.Add(updateStockbtn);
                }

                ToolStripMenuItem viewInventoryBtn = new ToolStripMenuItem("Manage Products");

                // Apply the same style as AppointmentsBtn to the sub-buttons
                
                viewInventoryBtn.BackColor = AppointmentsBtn.BackColor;
                viewInventoryBtn.ForeColor = AppointmentsBtn.ForeColor;
                viewInventoryBtn.Font = AppointmentsBtn.Font;

                // Add event handlers for the sub-buttons
                viewInventoryBtn.Click += ViewProductBtn_Click;

                // Add sub-buttons to the context menu strip
                
                inventoryMenu.Items.Add(viewInventoryBtn);

                // Show the context menu strip at the position of the inventoryBtn
                Point pos = inventoryBtn.PointToScreen(new Point(0, inventoryBtn.Height));
                inventoryMenu.Show(pos);

                inventoryMenuOpen = true;
            }
            else
            {
                // Close the context menu strip
                inventoryMenu.Close();
                inventoryMenuOpen = false;
            }
        }

        public void UpdateStockbtn_Click(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
            inventoryMenuOpen = false;
            UpdateStockUI stock = new UpdateStockUI();
            if (GlobalVariables.username != "Mohomed" || GlobalVariables.username != "Mpiyakhe")
            {
                // pro.vProductUpdateBtn.Enabled = false;
                stock.updatestkBtn.Enabled = false;
                stock.updatestkBtn.BackColor = Color.Gray;
               // pro.vProductUpdateBtn.BackColor = Color.Gray;
            }
            if (GlobalVariables.username == "Mohomed" || GlobalVariables.username == "Mpiyakhe")
            {
                // pro.vProductUpdateBtn.Enabled = true;
                stock.updatestkBtn.Enabled = true;
                stock.updatestkBtn.BackColor = Color.Navy;
                // pro.vProductUpdateBtn.BackColor = Color.Navy;
            }
            LoadFormIntoPanel(stock);
        }

        private void AddInventoryBtn_Click(object sender, EventArgs e)
        {
           DialogResult a = MessageBox.Show("Is there an existing supplier for new this product?", "Cornfirmation Message", MessageBoxButtons.YesNo);

            if (a == DialogResult.Yes)
            {
                inventoryMenuOpen = false;
                //MessageBox.Show("Add Inventory button clicked");
                AddProductUI myPro = new AddProductUI();
                LoadFormIntoPanel(myPro);
            }
            else
            {
                MessageBox.Show("Please add the new supplier details first");
                suppliersMenuOpen = false;
                //MessageBox.Show("Add Supplier button clicked");
                AddSupplierUI supp = new AddSupplierUI();
                LoadFormIntoPanel(supp);

            }
            
        }
        private void ViewProductBtn_Click(object sender, EventArgs e)
        {
            /************************************************/
            inventoryMenuOpen = false;
            //MessageBox.Show("Add Inventory button clicked");
            ViewProductUI pro = new ViewProductUI();
            if (GlobalVariables.username != "Mohomed" || GlobalVariables.username != "Mpiyakhe")
            {
                pro.vProductUpdateBtn.Enabled = false;
                pro.vProductUpdateBtn.BackColor = Color.Gray;

                pro.DeleteBtn.Enabled = false;
                pro.DeleteBtn.BackColor = Color.Gray;
            }
            if (GlobalVariables.username == "Mohomed" || GlobalVariables.username == "Mpiyakhe")
            {
                pro.vProductUpdateBtn.Enabled = true;
                pro.vProductUpdateBtn.BackColor = Color.Navy;

                pro.DeleteBtn.Enabled = true;
                pro.DeleteBtn.BackColor = Color.Navy;
            }
            LoadFormIntoPanel(pro);
            /********************************************/
            DBConnect2 connect2 = new DBConnect2();
            DataTable DT = connect2.QueryDT();
            int size = DT.Rows.Count;
            DialogResult c = DialogResult.None;
            int selecterow = 0;
            for(int i = 0; i < size; i++)
            {
                if ((int)DT.Rows[i]["quantityAvailable"] <= 20)
                {
                     c = MessageBox.Show("Urgent: " + (string)DT.Rows[i]["item_name"] + " is critically low! Only " + (int)DT.Rows[i]["quantityAvailable"] + " units remaining. Immediate restocking is recommended!!\n Would you like to update Stock Now?", 
                         "LOW STOCK ALERT!!", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                    selecterow = i;
                }   }
            /*
            if (c == DialogResult.No)
            {
                inventoryMenuOpen = false;
                //MessageBox.Show("Add Inventory button clicked");
                ViewProductUI pro = new ViewProductUI();
                if (GlobalVariables.username != "Mohomed" || GlobalVariables.username != "Mpiyakhe")
                {
                    pro.vProductUpdateBtn.Enabled = false;
                    pro.vProductUpdateBtn.BackColor = Color.Gray;
                }
                if (GlobalVariables.username == "Mohomed" || GlobalVariables.username == "Mpiyakhe")
                {
                    pro.vProductUpdateBtn.Enabled = true;
                    pro.vProductUpdateBtn.BackColor = Color.Navy;
                }
                LoadFormIntoPanel(pro);

            }*/
           // else
           if (c == DialogResult.Yes)
            {
                inventoryMenuOpen = false;
                //MessageBox.Show("Add Supplier button clicked");
                //AddSupplierUI supp = new AddSupplierUI();
                UpdateStockUI update = new UpdateStockUI();
               
                LoadFormIntoPanel(update);
                update.dataGridView1.Rows[selecterow].Selected = true;
                update.dataGridView1.ClearSelection();
                update.dataGridView1.CurrentCell =update.dataGridView1.Rows[selecterow].Cells[2];
                update.dataGridView1.FirstDisplayedScrollingRowIndex = selecterow;

            }
           /*
            else
            {
                inventoryMenuOpen = false;
                //MessageBox.Show("Add Inventory button clicked");
                //removed view product here
                 pro = new ViewProductUI();
                if (GlobalVariables.username != "Mohomed" || GlobalVariables.username != "Mpiyakhe")
                {
                    pro.vProductUpdateBtn.Enabled = false;
                    pro.vProductUpdateBtn.BackColor = Color.Gray;
                }
                if (GlobalVariables.username == "Mohomed" || GlobalVariables.username == "Mpiyakhe")
                {
                    pro.vProductUpdateBtn.Enabled = true;
                    pro.vProductUpdateBtn.BackColor = Color.Navy;
                }
                LoadFormIntoPanel(pro);
            }*/
           

        }

        private void ViewInventoryBtn_Click(object sender, EventArgs e)
        {
            inventoryMenuOpen = false;
            MessageBox.Show("View Inventory button clicked");
        }



        private void reportsBtn_Click(object sender, EventArgs e)
        {
            ViewReportUI h = new ViewReportUI();
           LoadFormIntoPanel(h);

        }

        bool servicesMenuOpen = false;
        ContextMenuStrip servicesMenu = new ContextMenuStrip();

        private void servicesBtn_Click(object sender, EventArgs e)
        {
            if (!servicesMenuOpen)
            {
                // Clear existing sub-buttons
                servicesMenu.Items.Clear();

                // Add sub-buttons to the context menu strip
                if (GlobalVariables.username == "Mpiyakhe" || GlobalVariables.username == "Mohomed")
                {
                    ToolStripMenuItem addServiceBtn = new ToolStripMenuItem("Add Service");

                    addServiceBtn.BackColor = AppointmentsBtn.BackColor;
                    addServiceBtn.ForeColor = AppointmentsBtn.ForeColor;
                    addServiceBtn.Font = AppointmentsBtn.Font;

                    addServiceBtn.Click += AddServiceBtn_Click;
                    servicesMenu.Items.Add(addServiceBtn);
                }
                    
                ToolStripMenuItem viewServicesBtn = new ToolStripMenuItem("Manage Services");

                // Apply the same style as AppointmentsBtn to the sub-buttons
                

                viewServicesBtn.BackColor = AppointmentsBtn.BackColor;
                viewServicesBtn.ForeColor = AppointmentsBtn.ForeColor;
                viewServicesBtn.Font = AppointmentsBtn.Font;

                // Add event handlers for the sub-buttons
                
                viewServicesBtn.Click += ViewServicesBtn_Click;

                // Add sub-buttons to the context menu strip
                servicesMenu.Items.Add(viewServicesBtn);

                // Show the context menu strip at the position of the servicesBtn
                Point pos = servicesBtn.PointToScreen(new Point(0, servicesBtn.Height));
                servicesMenu.Show(pos);

                servicesMenuOpen = true;
            }
            else
            {
                // Close the context menu strip
                servicesMenu.Close();
                servicesMenuOpen = false;
            }
        }

        private void AddServiceBtn_Click(object sender, EventArgs e)
        {
            servicesMenuOpen = false;
            //MessageBox.Show("Add Service button clicked");
            AddServiceUI serv = new AddServiceUI();
            LoadFormIntoPanel(serv);
        }

        private void ViewServicesBtn_Click(object sender, EventArgs e)
        {
            servicesMenuOpen = false;
            // MessageBox.Show("View Services button clicked");
            ViewServicesUI view = new ViewServicesUI();
            if (GlobalVariables.username != "Mohomed" || GlobalVariables.username != "Mpiyakhe")
            {
                view.vServiceUpdateBtn.Enabled = false;
                view.vServiceUpdateBtn.BackColor = Color.Gray;

                view.deleteBtn.Enabled = false;
                view.deleteBtn.BackColor = Color.Gray;
            }
            if(GlobalVariables.username == "Mohomed" || GlobalVariables.username == "Mpiyakhe")
            {
                view.vServiceUpdateBtn.Enabled = true;
                view.vServiceUpdateBtn.BackColor = Color.Navy;

                view.deleteBtn.Enabled = true;
                view.deleteBtn.BackColor = Color.Navy;
            }
            LoadFormIntoPanel(view);
        }

        public void LoadFormIntoPanel(Form form)
        {
            ParentPanel.Controls.Clear();
            form.TopLevel = false;
            ParentPanel.Controls.Add(form);
            form.Dock = DockStyle.Fill;
            form.Show();
        }

        private void logoutBtn_Click(object sender, EventArgs e)
        {
            List<Form> openForms = new List<Form>();

            // Populate the list with open forms
            foreach (Form form in Application.OpenForms)
            {
                openForms.Add(form);
            }

            // Close all open forms using the list
            foreach (Form form in openForms)
            {
                form.Close();
            }

            // Exit the application
            Application.Exit();
            RestartApplication();
        }
        private void RestartApplication()
        {
            System.Diagnostics.Process.Start(Application.ExecutablePath);
        }

        public void homeBtn_Click(object sender, EventArgs e)
        {
            // Clear existing controls in ParentPanel if needed
            HomeUI h = new HomeUI();
            ParentPanel.Controls.Clear();
            h.label5.Text = taAppointments.countQ().ToString();
            h.label7.Text = taAppointments.countCompletedApp().ToString();
            h.label6.Text = taService.countS().ToString();
            h.label1.Text = taAppointments.countCancelledApp().ToString();
            h.label9.Text = taAppointments.countCompletedAppDayBefore().ToString();
            h.label11.Text = taAppointments.countCompletedApp().ToString();
            LoadFormIntoPanel(h);

        }

        private void HomeScreenUI_Load(object sender, EventArgs e)
        {
            if(GlobalVariables.username != "Mohomed")
            {
                reportsBtn.Hide();
            }
            LoadFormIntoPanel(new HomeUI());
        }

        private void MenuBtn_Click(object sender, EventArgs e)
        {
            CollapseMenu();
        }

        private void CollapseMenu()
        {
            if(sidebar.Width > 200)
            {
                sidebar.Width = 60;
                label1.Visible = false;
                MenuBtn.Dock = DockStyle.Top;
                ParentPanel.Dock = DockStyle.Fill;
                foreach(Button menuButton in sidebar.Controls.OfType<Button>())
                {
                    menuButton.Text = "";
                    menuButton.ImageAlign = ContentAlignment.MiddleCenter;
                    menuButton.Padding = new Padding(0);

                }
            }
            else
            {
                sidebar.Width = 267;
                label1.Visible = true;
                MenuBtn.Dock = DockStyle.Left;
                foreach (Button menuButton in sidebar.Controls.OfType<Button>())
                {
                    menuButton.Text ="   " +menuButton.Tag.ToString();
                    menuButton.ImageAlign = ContentAlignment.MiddleLeft;
                    menuButton.Padding = new Padding(13, 0, 27, 0);

                }

            }
        }
    }
}
