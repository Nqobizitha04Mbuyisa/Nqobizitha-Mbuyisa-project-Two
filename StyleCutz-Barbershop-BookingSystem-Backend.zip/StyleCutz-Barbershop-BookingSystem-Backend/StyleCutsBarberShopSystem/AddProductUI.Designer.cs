﻿
namespace StyleCutsBarberShopSystem
{
    partial class AddProductUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.productQuantityTB = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.supplieridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.suppliernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplier_cellNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplier_email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplier_address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.suppliertblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsG7 = new StyleCutsBarberShopSystem.dsG7();
            this.productClearTB = new System.Windows.Forms.Button();
            this.productConfirmTB = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.productPriceTB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.productNameTB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.inventoryBS = new System.Windows.Forms.BindingSource(this.components);
            this.taInventory = new StyleCutsBarberShopSystem.dsG7TableAdapters.Inventory_tblTableAdapter();
            this.supplier_tblTableAdapter = new StyleCutsBarberShopSystem.dsG7TableAdapters.Supplier_tblTableAdapter();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.suppliertblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryBS)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.productQuantityTB);
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.productClearTB);
            this.groupBox1.Controls.Add(this.productConfirmTB);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.productPriceTB);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.productNameTB);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(110, 34);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(558, 377);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Product Details";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(44, 135);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 20);
            this.label4.TabIndex = 20;
            this.label4.Text = "Select supplier";
            // 
            // productQuantityTB
            // 
            this.productQuantityTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.productQuantityTB.Location = new System.Drawing.Point(170, 69);
            this.productQuantityTB.Name = "productQuantityTB";
            this.productQuantityTB.Size = new System.Drawing.Size(335, 26);
            this.productQuantityTB.TabIndex = 18;
            this.productQuantityTB.KeyDown += new System.Windows.Forms.KeyEventHandler(this.productQuantityTB_KeyDown);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.supplieridDataGridViewTextBoxColumn,
            this.suppliernameDataGridViewTextBoxColumn,
            this.supplier_cellNo,
            this.supplier_email,
            this.supplier_address});
            this.dataGridView1.DataSource = this.suppliertblBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(48, 158);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(457, 150);
            this.dataGridView1.TabIndex = 7;
            // 
            // supplieridDataGridViewTextBoxColumn
            // 
            this.supplieridDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.supplieridDataGridViewTextBoxColumn.DataPropertyName = "supplier_id";
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.supplieridDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.supplieridDataGridViewTextBoxColumn.HeaderText = "supplier_id";
            this.supplieridDataGridViewTextBoxColumn.Name = "supplieridDataGridViewTextBoxColumn";
            this.supplieridDataGridViewTextBoxColumn.ReadOnly = true;
            this.supplieridDataGridViewTextBoxColumn.Width = 111;
            // 
            // suppliernameDataGridViewTextBoxColumn
            // 
            this.suppliernameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.suppliernameDataGridViewTextBoxColumn.DataPropertyName = "supplier_name";
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.suppliernameDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.suppliernameDataGridViewTextBoxColumn.HeaderText = "supplier_name";
            this.suppliernameDataGridViewTextBoxColumn.Name = "suppliernameDataGridViewTextBoxColumn";
            this.suppliernameDataGridViewTextBoxColumn.ReadOnly = true;
            this.suppliernameDataGridViewTextBoxColumn.Width = 140;
            // 
            // supplier_cellNo
            // 
            this.supplier_cellNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.supplier_cellNo.DataPropertyName = "supplier_cellNo";
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.supplier_cellNo.DefaultCellStyle = dataGridViewCellStyle3;
            this.supplier_cellNo.HeaderText = "supplier_cellNo";
            this.supplier_cellNo.Name = "supplier_cellNo";
            this.supplier_cellNo.ReadOnly = true;
            this.supplier_cellNo.Width = 145;
            // 
            // supplier_email
            // 
            this.supplier_email.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.supplier_email.DataPropertyName = "supplier_email";
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.supplier_email.DefaultCellStyle = dataGridViewCellStyle4;
            this.supplier_email.HeaderText = "supplier_email";
            this.supplier_email.Name = "supplier_email";
            this.supplier_email.ReadOnly = true;
            this.supplier_email.Width = 137;
            // 
            // supplier_address
            // 
            this.supplier_address.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.supplier_address.DataPropertyName = "supplier_address";
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.supplier_address.DefaultCellStyle = dataGridViewCellStyle5;
            this.supplier_address.HeaderText = "supplier_address";
            this.supplier_address.Name = "supplier_address";
            this.supplier_address.ReadOnly = true;
            this.supplier_address.Width = 155;
            // 
            // suppliertblBindingSource
            // 
            this.suppliertblBindingSource.DataMember = "Supplier_tbl";
            this.suppliertblBindingSource.DataSource = this.dsG7;
            // 
            // dsG7
            // 
            this.dsG7.DataSetName = "dsG7";
            this.dsG7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productClearTB
            // 
            this.productClearTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.productClearTB.BackColor = System.Drawing.Color.Navy;
            this.productClearTB.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.productClearTB.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productClearTB.ForeColor = System.Drawing.Color.White;
            this.productClearTB.Location = new System.Drawing.Point(170, 335);
            this.productClearTB.Name = "productClearTB";
            this.productClearTB.Size = new System.Drawing.Size(75, 31);
            this.productClearTB.TabIndex = 14;
            this.productClearTB.Text = "Clear";
            this.productClearTB.UseVisualStyleBackColor = false;
            this.productClearTB.Click += new System.EventHandler(this.productClearTB_Click_1);
            // 
            // productConfirmTB
            // 
            this.productConfirmTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.productConfirmTB.BackColor = System.Drawing.Color.Navy;
            this.productConfirmTB.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.productConfirmTB.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productConfirmTB.ForeColor = System.Drawing.Color.White;
            this.productConfirmTB.Location = new System.Drawing.Point(430, 335);
            this.productConfirmTB.Name = "productConfirmTB";
            this.productConfirmTB.Size = new System.Drawing.Size(75, 31);
            this.productConfirmTB.TabIndex = 15;
            this.productConfirmTB.Text = "Confirm";
            this.productConfirmTB.UseVisualStyleBackColor = false;
            this.productConfirmTB.Click += new System.EventHandler(this.productConfirmTB_Click_1);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(44, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 20);
            this.label3.TabIndex = 17;
            this.label3.Text = "Price";
            // 
            // productPriceTB
            // 
            this.productPriceTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.productPriceTB.Location = new System.Drawing.Point(170, 103);
            this.productPriceTB.Name = "productPriceTB";
            this.productPriceTB.Size = new System.Drawing.Size(335, 26);
            this.productPriceTB.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(44, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 20);
            this.label2.TabIndex = 16;
            this.label2.Text = "Quantity";
            // 
            // productNameTB
            // 
            this.productNameTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.productNameTB.Location = new System.Drawing.Point(170, 37);
            this.productNameTB.Name = "productNameTB";
            this.productNameTB.Size = new System.Drawing.Size(335, 26);
            this.productNameTB.TabIndex = 10;
            this.productNameTB.KeyDown += new System.Windows.Forms.KeyEventHandler(this.productNameTB_KeyDown);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(44, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // inventoryBS
            // 
            this.inventoryBS.DataMember = "Inventory_tbl";
            this.inventoryBS.DataSource = this.dsG7;
            // 
            // taInventory
            // 
            this.taInventory.ClearBeforeFill = true;
            // 
            // supplier_tblTableAdapter
            // 
            this.supplier_tblTableAdapter.ClearBeforeFill = true;
            // 
            // AddProductUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddProductUI";
            this.Text = "AddProductUI";
            this.Load += new System.EventHandler(this.AddProductUI_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.suppliertblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryBS)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private dsG7 dsG7;
        private System.Windows.Forms.BindingSource inventoryBS;
        private dsG7TableAdapters.Inventory_tblTableAdapter taInventory;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox productQuantityTB;
        private System.Windows.Forms.Button productClearTB;
        private System.Windows.Forms.Button productConfirmTB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox productPriceTB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox productNameTB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource suppliertblBindingSource;
        private dsG7TableAdapters.Supplier_tblTableAdapter supplier_tblTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplieridDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn suppliernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplier_cellNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplier_email;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplier_address;
    }
}