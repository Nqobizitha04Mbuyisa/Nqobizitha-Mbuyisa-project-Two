﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StyleCutsBarberShopSystem
{
    public partial class UpdateStockUI : Form
    {
        decimal price = 0;
        List<int> items = new List<int>();
        List<int> quantity = new List<int>();
        public UpdateStockUI()
        {
            InitializeComponent();
        }

        private void UpdateStockUI_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dsG7.Order_Inventory' table. You can move, or remove it, as needed.
            this.order_InventoryTableAdapter.Fill(this.dsG7.Order_Inventory);
            // TODO: This line of code loads data into the 'dsG7.Supplier_tbl' table. You can move, or remove it, as needed.
            this.supplier_tblTableAdapter.Fill(this.dsG7.Supplier_tbl);
            // TODO: This line of code loads data into the 'dsG7.Service' table. You can move, or remove it, as needed.
            this.serviceTableAdapter.Fill(this.dsG7.Service);
            // TODO: This line of code loads data into the 'dataSet11.InventoryTwo' table. You can move, or remove it, as needed.
            //this.inventoryTwoTableAdapter.Fill(this.dataSet11.InventoryTwo);
            // TODO: This line of code loads data into the 'dsG71.Inventory_tbl' table. You can move, or remove it, as needed.
            //  this.inventory_tblTableAdapter.Fill(this.dsG71.Inventory_tbl);
            // TODO: This line of code loads data into the 'dsG7.Order_tbl' table. You can move, or remove it, as needed.
            this.order_tblTableAdapter.FillByPending(this.dsG7.Order_tbl);
            // TODO: This line of code loads data into the 'dsG7.Inventory_tbl' table. You can move, or remove it, as needed.
           // this.inventory_tblTableAdapter.Fill(this.dsG7.Inventory_tbl);
            taOrder.Fill(dsG71.Order_tbl);
            taOrder.FillBySuccessful(dsG73.Order_tbl);
            ordertblBindingSource2.MoveLast();

        }

        private void gvSuppliersSearchTB_TextChanged(object sender, EventArgs e)
        {
            inventory_tblTableAdapter.FillByItemName(dsG7.Inventory_tbl, searchProductTB.Text);
        }

        private void updatestkBtn_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Are you sure you want to update " + dataGridView1.CurrentRow.Cells[1].Value.ToString() + " by " + textBox1.Text + " units?","Update Stock Confirmation" ,MessageBoxButtons.YesNo);
            if (res == DialogResult.Yes)
            {
                inventory_tblTableAdapter.UpdateStock(Convert.ToInt16(textBox1.Text), Convert.ToInt16(dataGridView1.CurrentRow.Cells[0].Value));
                MessageBox.Show("Update Successfull");
                this.inventory_tblTableAdapter.Fill(this.dsG7.Inventory_tbl);
                textBox1.Clear();

            }
            else
            {
                textBox1.Clear();
                MessageBox.Show("Update Cancelled");
                //inventory_tblTableAdapter.FillBySupplierID()
            }
        }

        private void updatestkBtn_Click_1(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0 || dataGridView2.SelectedRows.Count == 0 )
            {
                MessageBox.Show("You must select at least one item from grids.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Exit the method if any grid is empty
            }
            int qty = 0;
            for (int i = 0; i < dataGridView2.Rows.Count; i++)
            {
                qty += Convert.ToInt32(dataGridView2.Rows[i].Cells[3].Value);
            }

                DialogResult res = MessageBox.Show("Are you sure you want to Confirm this order?", "Order Confirmation", MessageBoxButtons.YesNo);
            if (res == DialogResult.Yes)
            {
                taOrder.InsertOrder(Convert.ToInt32(dataGridView2.CurrentRow.Cells[0].Value), qty, Convert.ToDecimal(textBox2.Text), DateTime.Today.ToString("yyyy-MM-dd"));
                //  .ToString("yyyy-MM-dd")
                MessageBox.Show("Order Processed Successfully");

                for (int i = 0; i < dataGridView2.Rows.Count; i++)
                {
                    items.Add(Convert.ToInt32(dataGridView2.Rows[i].Cells[0].Value));
                    quantity.Add(Convert.ToInt32(dataGridView2.Rows[i].Cells[3].Value));
                }
                int id = Convert.ToInt32(textBox3.Text) + 1;
                try
                {
                    for (int i = 0; i < items.Count; i++)
                    {
                        taOrderInventory.InsertQuery(id, items[i], quantity[i]);
                    }

                }
                catch
                {

                }
                  
               // taOrderInventory.InsertQuery(id, 6, 1);

               // taOrderInventory.InsertQuery()
                    dataSet11.InventoryTwo.Clear();
                textBox1.Clear();
                textBox2.Clear();
                this.order_tblTableAdapter.FillByPending(this.dsG7.Order_tbl);
                if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
                {
                    tabControl1.SelectedIndex += 1;
                }

            }
            else
            {
                MessageBox.Show("Order cancelled ");
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("No items available to select.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; 
            }
            /* DataRow dr;
             dr = dsNew.ServiceTwo.NewRow();
             for (int i = 0; i < dr.ItemArray.Length; i++)
             {
                 dr[i] = dataGridView1.CurrentRow.Cells[i].Value;
             }
             dsNew.ServiceTwo.Rows.Add(dr);*/
            DataRow dr;
            dr = dataSet11.InventoryTwo.NewRow();

            /*for (int i = 0; i < dr.ItemArray.Length; i++)
            {
                dr[i] = dataGridView1.CurrentRow.Cells[i].Value;
            }*/
            


            dr[0] = dataGridView1.CurrentRow.Cells[0].Value;
            dr[1] = dataGridView1.CurrentRow.Cells[1].Value;
            dr[2] = dataGridView1.CurrentRow.Cells[3].Value;
            dataSet11.InventoryTwo.Rows.Add(dr);
            int a = dataGridView2.Rows.Count - 2;
            dataGridView2.CurrentCell = dataGridView2.Rows[a].Cells[0];
            // dataGridView1.FirstDisplayedScrollingRowIndex= dataGridView2.NewRowIndex;
            // dataGridView1.
            //dataGridView1.FirstDisplayedScrollingRowIndex = dataGridView1.NewRowIndex;
            //dataGridView1.CurrentCell =update.dataGridView1.Rows[selecterow].Cells[2];

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || !int.TryParse(textBox1.Text, out _))
            {
                MessageBox.Show("Please enter a valid quantity as an integer.","Input Error");
                return;
            }

            dataGridView2.CurrentRow.Cells[3].Value = textBox1.Text;
            for (int i = 0; i < dataGridView2.Rows.Count; i++)
            {
                price += (Convert.ToDecimal(dataGridView2.Rows[i].Cells[2].Value) * (Convert.ToInt16(dataGridView2.Rows[i].Cells[3].Value)));
            }
            textBox2.Text = price.ToString();
            price = 0;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // dataGridView2.Rows.Remove(dataGridView2.CurrentRow);
             dataGridView2.Rows.Remove(dataGridView2.CurrentRow);
            //price =price- (Convert.ToDecimal(dataGridView2.CurrentRow.Cells[3].Value) * (Convert.ToInt16(dataGridView2.CurrentRow.Cells[4].Value)));
            //  textBox2.Text = price.ToString("C2");
            for (int i = 0; i < dataGridView2.Rows.Count; i++)
            {
                price += (Convert.ToDecimal(dataGridView2.Rows[i].Cells[2].Value) * (Convert.ToInt16(dataGridView2.Rows[i].Cells[3].Value)));
            }
            textBox2.Text = price.ToString();
            price = 0;

        }

        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            inventory_tblTableAdapter.FillBySupplierID(dsG7.Inventory_tbl,Convert.ToInt32(dataGridView3.CurrentRow.Cells[0].Value));
        }

        private void dataGridView4_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            taOrderDetails.FillByOrderID(dsG71.OrderDetails_tbl, Convert.ToInt32(dataGridView4.CurrentRow.Cells[0].Value));
            textBox5.Text = "R"+dataGridView4.CurrentRow.Cells[3].Value.ToString();
            textBox4.Text = textBox5.Text;
        }
        private void UDRemoveSelected_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Are you sure you want to make this payment?", "Payment Confirmation ", MessageBoxButtons.YesNo);
            if (res == DialogResult.Yes)
            {

                for(int i = 0; i < dataGridView5.Rows.Count; i++)
                {
                    inventory_tblTableAdapter.UpdateStock(Convert.ToInt32(dataGridView5.Rows[i].Cells[3].Value),Convert.ToInt32(dataGridView5.Rows[i].Cells[4].Value));

                }

                dsG71.OrderDetails_tbl.Clear();

                MessageBox.Show("Order Successfully Paid for");

                order_tblTableAdapter.UpdateOrderStatus(Convert.ToInt32(dataGridView4.CurrentRow.Cells[0].Value));
                this.inventory_tblTableAdapter.Fill(this.dsG7.Inventory_tbl);
                order_tblTableAdapter.FillByPending(dsG7.Order_tbl);

               
                
            }
            else
            {
                MessageBox.Show("Payment Cancelled");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataSet11.InventoryTwo.Clear();
        }

        private void dataGridView6_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            taOrderDetails.FillByOrderID(dsG73.OrderDetails_tbl, Convert.ToInt32(dataGridView6.CurrentRow.Cells[0].Value));
        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Are you sure you want to Cancel the Order??", "Order Cancelletion Confirmation", MessageBoxButtons.YesNo);
            if (res == DialogResult.Yes)
            {
                
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            if (dataGridView8.SelectedRows.Count == 0)
            {
                MessageBox.Show("No order selected to cancel.","Cancellation Error");
                return;
            }
            DialogResult res = MessageBox.Show("Are you sure you want to Cancel the Order??", "Order Cancelletion Confirmation", MessageBoxButtons.YesNo);
            if (res == DialogResult.Yes)
            {
                order_tblTableAdapter.UpdateCancelledOrder(Convert.ToInt32(dataGridView8.CurrentRow.Cells[0].Value));
                //order_tblTableAdapter.
                MessageBox.Show("Order Cancelled Successfully");
                order_tblTableAdapter.FillByPending(dsG7.Order_tbl);

            }
            else
            {
                MessageBox.Show("Order Update Cancelled");
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Pending")
            {
                order_tblTableAdapter.FillByPending(this.dsG73.Order_tbl);

            }
            else if (comboBox1.Text == "Cancelled")
            {
                order_tblTableAdapter.FillByCancelled(this.dsG73.Order_tbl);
            }
            else if (comboBox1.Text == "Successful") order_tblTableAdapter.FillBySuccessful(this.dsG73.Order_tbl);
        }
    }
}
