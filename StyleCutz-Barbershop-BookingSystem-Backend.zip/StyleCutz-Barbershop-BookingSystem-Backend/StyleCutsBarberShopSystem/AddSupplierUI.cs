﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StyleCutsBarberShopSystem
{
    public partial class AddSupplierUI : Form
    {
        public AddSupplierUI()
        {
            InitializeComponent();
        }
        private bool IsValidInput()
        {
            // Validate Name
            if (string.IsNullOrWhiteSpace(supplierNameTB.Text) || !IsValidName(supplierNameTB.Text))
            {
                MessageBox.Show("Please enter a valid name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                supplierNameTB.Focus();
                return false;
            }

            // Validate Number
            if (string.IsNullOrWhiteSpace(supplierCellNoTB.Text) || !IsValidNumber(supplierCellNoTB.Text))
            {
                MessageBox.Show("Please enter a valid number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                supplierCellNoTB.Focus();
                return false;
            }

            // Validate Email
            if (string.IsNullOrWhiteSpace(supplierEmailTB.Text) || !IsValidEmail(supplierEmailTB.Text))
            {
                MessageBox.Show("Please enter a valid email address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                supplierEmailTB.Focus();
                return false;
            }

            // Validate Address
            if (string.IsNullOrWhiteSpace(supplierAddressTB.Text))
            {
                MessageBox.Show("Please enter an address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                supplierAddressTB.Focus();
                return false;
            }

            
            return true;
        }

        // Validation methods
        private bool IsValidName(string name)
        {
            // Simple validation: check if the name contains only letters and spaces
            return name.All(c => char.IsLetter(c) || char.IsWhiteSpace(c));
        }

        private bool IsValidNumber(string cellNumber)
        {
            // Simple validation: check if the number is a valid integer
            return cellNumber.All(char.IsDigit) && cellNumber.Length == 10;
        }

        private bool IsValidEmail(string email)
        {
            // Simple validation using regex for email format
            return System.Text.RegularExpressions.Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$");
        }

        private void AddSupplierUI_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dsG7.Supplier_tbl' table. You can move, or remove it, as needed.
            this.taSupplier.Fill(this.dsG7.Supplier_tbl);
        }

        private void supplierConfirmTB_Click(object sender, EventArgs e)
        {
            if (!IsValidInput())
            {
                return; 
            }
            try
            {
                taSupplier.InsertSupplier(supplierNameTB.Text, supplierCellNoTB.Text, supplierEmailTB.Text, supplierAddressTB.Text);
                supplierNameTB.Clear();
                supplierCellNoTB.Clear();
                supplierEmailTB.Clear();
                supplierAddressTB.Clear();
                MessageBox.Show("Supplier added successfully");
            }
            catch
            {
                MessageBox.Show("Enter valid details", "Invalid details", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void supplierClearTB_Click(object sender, EventArgs e)
        {
            supplierNameTB.Clear();
            supplierCellNoTB.Clear();
            supplierEmailTB.Clear();
            supplierAddressTB.Clear();
        }

        private void supplierNameTB_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Move the focus to the next control
                supplierCellNoTB.Focus();
            }
        }

        private void supplierCellNoTB_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Move the focus to the next control
                supplierEmailTB.Focus();
            }
        }

        private void supplierEmailTB_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Move the focus to the next control
                supplierAddressTB.Focus();
            }
        }
    }
}
