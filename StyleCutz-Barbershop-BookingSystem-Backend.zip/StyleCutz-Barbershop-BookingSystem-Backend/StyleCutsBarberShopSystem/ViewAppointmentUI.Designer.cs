﻿
namespace StyleCutsBarberShopSystem
{
    partial class ViewAppointmentUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.appointmentidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicenameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicepriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataTable1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsG71 = new StyleCutsBarberShopSystem.dsG7();
            this.gvAppointmentsSearchTB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.gvAppointments = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.appointment_date1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TimeSlot = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.student_number = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.appointment_status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employee_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.innerJoinBS = new System.Windows.Forms.BindingSource(this.components);
            this.dsViewAppointments = new StyleCutsBarberShopSystem.dsG7();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.UDRemoveSelected = new System.Windows.Forms.Button();
            this.UDRemoveAll = new System.Windows.Forms.Button();
            this.updateBtn = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.appointmentidDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicenameDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicepriceDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.service_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.serviceidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicenameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicepriceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serviceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.employeeidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeenameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeetblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label12 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.availableTimeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsAppointment1 = new StyleCutsBarberShopSystem.dsAppointment();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.Options = new System.Windows.Forms.GroupBox();
            this.cancelAppointmentBtn = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.vAppointmentFirstBtn = new System.Windows.Forms.Button();
            this.vAppointmentNextBtn = new System.Windows.Forms.Button();
            this.vAppointmentPreviousBtn = new System.Windows.Forms.Button();
            this.vAppointmentLastBtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.vAppointmentsAmount = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.vAppointmentsBarber = new System.Windows.Forms.TextBox();
            this.vAppointmentDateTB = new System.Windows.Forms.TextBox();
            this.vAppointmentNameTB = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button5 = new System.Windows.Forms.Button();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataTable1BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dsG72 = new StyleCutsBarberShopSystem.dsG7();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.innerJoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.iconDropDownButton1 = new FontAwesome.Sharp.IconDropDownButton();
            this.dsG7 = new StyleCutsBarberShopSystem.dsG7();
            this.serviceAppointmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ataViewAppointments = new StyleCutsBarberShopSystem.dsG7TableAdapters.Appointment_tblTableAdapter();
            this.taViewAppointments2 = new StyleCutsBarberShopSystem.dsG7TableAdapters.Appointment_tblTableAdapter();
            this.taService_Appointment = new StyleCutsBarberShopSystem.dsG7TableAdapters.Service_AppointmentTableAdapter();
            this.appointmenttblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.taInnerJoin = new StyleCutsBarberShopSystem.dsG7TableAdapters.InnerJoinTableAdapter();
            this.taAppointment_tbl = new StyleCutsBarberShopSystem.dsG7TableAdapters.Appointment_tblTableAdapter();
            this.dataTable1TableAdapter = new StyleCutsBarberShopSystem.dsG7TableAdapters.DataTable1TableAdapter();
            this.taInnerDetails = new StyleCutsBarberShopSystem.dsG7TableAdapters.DataTable1TableAdapter();
            this.taAvailableTimes = new StyleCutsBarberShopSystem.dsAppointmentTableAdapters.AvailableTimeTableAdapter();
            this.taService1 = new StyleCutsBarberShopSystem.dsG7TableAdapters.ServiceTableAdapter();
            this.tatimes1 = new StyleCutsBarberShopSystem.dsG7TableAdapters.TimesTableAdapter();
            this.employee_tblTableAdapter = new StyleCutsBarberShopSystem.dsG7TableAdapters.Employee_tblTableAdapter();
            this.dsG73 = new StyleCutsBarberShopSystem.dsG7();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvAppointments)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.innerJoinBS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsViewAppointments)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceBindingSource)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeetblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.availableTimeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAppointment1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.Options.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.innerJoinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceAppointmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointmenttblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG73)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Padding = new System.Drawing.Point(0, 0);
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 483);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.TabIndexChanged += new System.EventHandler(this.tabControl1_TabIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.dateTimePicker2);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.gvAppointmentsSearchTB);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.gvAppointments);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 457);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "View Appointments";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(480, 19);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(142, 20);
            this.dateTimePicker2.TabIndex = 34;
            this.dateTimePicker2.ValueChanged += new System.EventHandler(this.dateTimePicker2_ValueChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.appointmentidDataGridViewTextBoxColumn,
            this.servicenameDataGridViewTextBoxColumn,
            this.servicepriceDataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn4});
            this.dataGridView1.DataSource = this.dataTable1BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(8, 257);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Size = new System.Drawing.Size(778, 138);
            this.dataGridView1.TabIndex = 33;
            // 
            // appointmentidDataGridViewTextBoxColumn
            // 
            this.appointmentidDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.appointmentidDataGridViewTextBoxColumn.DataPropertyName = "appointment_id";
            this.appointmentidDataGridViewTextBoxColumn.HeaderText = "appointment_id";
            this.appointmentidDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.appointmentidDataGridViewTextBoxColumn.Name = "appointmentidDataGridViewTextBoxColumn";
            this.appointmentidDataGridViewTextBoxColumn.ReadOnly = true;
            this.appointmentidDataGridViewTextBoxColumn.Width = 104;
            // 
            // servicenameDataGridViewTextBoxColumn
            // 
            this.servicenameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.servicenameDataGridViewTextBoxColumn.DataPropertyName = "service_name";
            this.servicenameDataGridViewTextBoxColumn.HeaderText = "service_name";
            this.servicenameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.servicenameDataGridViewTextBoxColumn.Name = "servicenameDataGridViewTextBoxColumn";
            this.servicenameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // servicepriceDataGridViewTextBoxColumn
            // 
            this.servicepriceDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.servicepriceDataGridViewTextBoxColumn.DataPropertyName = "service_price";
            this.servicepriceDataGridViewTextBoxColumn.HeaderText = "service_price";
            this.servicepriceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.servicepriceDataGridViewTextBoxColumn.Name = "servicepriceDataGridViewTextBoxColumn";
            this.servicepriceDataGridViewTextBoxColumn.ReadOnly = true;
            this.servicepriceDataGridViewTextBoxColumn.Width = 95;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn4.DataPropertyName = "service_id";
            this.dataGridViewTextBoxColumn4.HeaderText = "service_id";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 80;
            // 
            // dataTable1BindingSource
            // 
            this.dataTable1BindingSource.DataMember = "DataTable1";
            this.dataTable1BindingSource.DataSource = this.dsG71;
            // 
            // dsG71
            // 
            this.dsG71.DataSetName = "dsG7";
            this.dsG71.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gvAppointmentsSearchTB
            // 
            this.gvAppointmentsSearchTB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gvAppointmentsSearchTB.ForeColor = System.Drawing.Color.Black;
            this.gvAppointmentsSearchTB.Location = new System.Drawing.Point(296, 19);
            this.gvAppointmentsSearchTB.Name = "gvAppointmentsSearchTB";
            this.gvAppointmentsSearchTB.Size = new System.Drawing.Size(178, 20);
            this.gvAppointmentsSearchTB.TabIndex = 32;
            this.gvAppointmentsSearchTB.TextChanged += new System.EventHandler(this.gvAppointmentsSearchTB_TextChanged);
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(180, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 20);
            this.label6.TabIndex = 31;
            this.label6.Text = "Barber Name:";
            // 
            // gvAppointments
            // 
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.gvAppointments.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.gvAppointments.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gvAppointments.AutoGenerateColumns = false;
            this.gvAppointments.BackgroundColor = System.Drawing.Color.White;
            this.gvAppointments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvAppointments.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.appointment_date1,
            this.TimeSlot,
            this.dataGridViewTextBoxColumn6,
            this.student_number,
            this.appointment_status,
            this.employee_id});
            this.gvAppointments.DataSource = this.innerJoinBS;
            this.gvAppointments.Location = new System.Drawing.Point(8, 65);
            this.gvAppointments.Name = "gvAppointments";
            this.gvAppointments.ReadOnly = true;
            this.gvAppointments.RowHeadersWidth = 51;
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.gvAppointments.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.gvAppointments.Size = new System.Drawing.Size(778, 174);
            this.gvAppointments.TabIndex = 0;
            this.gvAppointments.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvAppointments_CellClick);
            this.gvAppointments.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.gvAppointments_DataBindingComplete);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "appointment_id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Id";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 41;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "customer_name";
            this.dataGridViewTextBoxColumn2.HeaderText = "customer_name";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 107;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn3.DataPropertyName = "employee_name";
            this.dataGridViewTextBoxColumn3.HeaderText = "employee_name";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 109;
            // 
            // appointment_date1
            // 
            this.appointment_date1.DataPropertyName = "appointment_date1";
            this.appointment_date1.HeaderText = "date";
            this.appointment_date1.MinimumWidth = 6;
            this.appointment_date1.Name = "appointment_date1";
            this.appointment_date1.ReadOnly = true;
            this.appointment_date1.Width = 125;
            // 
            // TimeSlot
            // 
            this.TimeSlot.DataPropertyName = "TimeSlot";
            this.TimeSlot.HeaderText = "Time";
            this.TimeSlot.MinimumWidth = 6;
            this.TimeSlot.Name = "TimeSlot";
            this.TimeSlot.ReadOnly = true;
            this.TimeSlot.Width = 125;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn6.DataPropertyName = "payment_amount";
            this.dataGridViewTextBoxColumn6.HeaderText = "Amount";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 68;
            // 
            // student_number
            // 
            this.student_number.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.student_number.DataPropertyName = "student_number";
            this.student_number.HeaderText = "student_number";
            this.student_number.MinimumWidth = 6;
            this.student_number.Name = "student_number";
            this.student_number.ReadOnly = true;
            this.student_number.Width = 108;
            // 
            // appointment_status
            // 
            this.appointment_status.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.appointment_status.DataPropertyName = "appointment_status";
            this.appointment_status.HeaderText = "appointment_status";
            this.appointment_status.MinimumWidth = 6;
            this.appointment_status.Name = "appointment_status";
            this.appointment_status.ReadOnly = true;
            this.appointment_status.Width = 124;
            // 
            // employee_id
            // 
            this.employee_id.DataPropertyName = "employee_id";
            this.employee_id.HeaderText = "employee_id";
            this.employee_id.MinimumWidth = 6;
            this.employee_id.Name = "employee_id";
            this.employee_id.ReadOnly = true;
            this.employee_id.Width = 125;
            // 
            // innerJoinBS
            // 
            this.innerJoinBS.DataMember = "InnerJoin";
            this.innerJoinBS.DataSource = this.dsViewAppointments;
            // 
            // dsViewAppointments
            // 
            this.dsViewAppointments.DataSetName = "dsG7";
            this.dsViewAppointments.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button4);
            this.tabPage3.Controls.Add(this.button3);
            this.tabPage3.Controls.Add(this.textBox9);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.UDRemoveSelected);
            this.tabPage3.Controls.Add(this.UDRemoveAll);
            this.tabPage3.Controls.Add(this.updateBtn);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Controls.Add(this.dataGridView2);
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(792, 457);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Update Appointment";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button4.BackColor = System.Drawing.Color.Navy;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(3, 418);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(152, 39);
            this.button4.TabIndex = 36;
            this.button4.Text = "Previous";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button3.BackColor = System.Drawing.Color.Navy;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(637, 418);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(152, 39);
            this.button3.TabIndex = 35;
            this.button3.Text = "Next";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox9
            // 
            this.textBox9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox9.ForeColor = System.Drawing.Color.Black;
            this.textBox9.Location = new System.Drawing.Point(375, 138);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(178, 20);
            this.textBox9.TabIndex = 34;
            this.textBox9.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(233, 139);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(101, 17);
            this.label13.TabIndex = 33;
            this.label13.Text = "Service Name:";
            // 
            // UDRemoveSelected
            // 
            this.UDRemoveSelected.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UDRemoveSelected.BackColor = System.Drawing.Color.Navy;
            this.UDRemoveSelected.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.UDRemoveSelected.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UDRemoveSelected.ForeColor = System.Drawing.Color.White;
            this.UDRemoveSelected.Location = new System.Drawing.Point(162, 418);
            this.UDRemoveSelected.Name = "UDRemoveSelected";
            this.UDRemoveSelected.Size = new System.Drawing.Size(152, 39);
            this.UDRemoveSelected.TabIndex = 24;
            this.UDRemoveSelected.Text = "Remove Selected";
            this.UDRemoveSelected.UseVisualStyleBackColor = false;
            this.UDRemoveSelected.Click += new System.EventHandler(this.UDRemoveSelected_Click);
            // 
            // UDRemoveAll
            // 
            this.UDRemoveAll.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.UDRemoveAll.BackColor = System.Drawing.Color.Navy;
            this.UDRemoveAll.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.UDRemoveAll.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UDRemoveAll.ForeColor = System.Drawing.Color.White;
            this.UDRemoveAll.Location = new System.Drawing.Point(322, 418);
            this.UDRemoveAll.Name = "UDRemoveAll";
            this.UDRemoveAll.Size = new System.Drawing.Size(152, 39);
            this.UDRemoveAll.TabIndex = 23;
            this.UDRemoveAll.Text = "Remove All";
            this.UDRemoveAll.UseVisualStyleBackColor = false;
            this.UDRemoveAll.Click += new System.EventHandler(this.UDRemoveAll_Click);
            // 
            // updateBtn
            // 
            this.updateBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.updateBtn.BackColor = System.Drawing.Color.Navy;
            this.updateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.updateBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateBtn.ForeColor = System.Drawing.Color.White;
            this.updateBtn.Location = new System.Drawing.Point(480, 418);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(152, 39);
            this.updateBtn.TabIndex = 22;
            this.updateBtn.Text = "Update";
            this.updateBtn.UseVisualStyleBackColor = false;
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(277, 290);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(218, 17);
            this.label11.TabIndex = 21;
            this.label11.Text = "Scheduled appointment services";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(39, 139);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(136, 17);
            this.label10.TabIndex = 20;
            this.label10.Text = "All available service";
            // 
            // dataGridView3
            // 
            this.dataGridView3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.appointmentidDataGridViewTextBoxColumn1,
            this.servicenameDataGridViewTextBoxColumn2,
            this.servicepriceDataGridViewTextBoxColumn2,
            this.service_id});
            this.dataGridView3.DataSource = this.dataTable1BindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(8, 310);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowHeadersWidth = 51;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.dataGridView3.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView3.Size = new System.Drawing.Size(776, 107);
            this.dataGridView3.TabIndex = 2;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // appointmentidDataGridViewTextBoxColumn1
            // 
            this.appointmentidDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.appointmentidDataGridViewTextBoxColumn1.DataPropertyName = "appointment_id";
            this.appointmentidDataGridViewTextBoxColumn1.HeaderText = "appointment_id";
            this.appointmentidDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.appointmentidDataGridViewTextBoxColumn1.Name = "appointmentidDataGridViewTextBoxColumn1";
            this.appointmentidDataGridViewTextBoxColumn1.ReadOnly = true;
            this.appointmentidDataGridViewTextBoxColumn1.Width = 104;
            // 
            // servicenameDataGridViewTextBoxColumn2
            // 
            this.servicenameDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.servicenameDataGridViewTextBoxColumn2.DataPropertyName = "service_name";
            this.servicenameDataGridViewTextBoxColumn2.HeaderText = "service_name";
            this.servicenameDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.servicenameDataGridViewTextBoxColumn2.Name = "servicenameDataGridViewTextBoxColumn2";
            this.servicenameDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // servicepriceDataGridViewTextBoxColumn2
            // 
            this.servicepriceDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.servicepriceDataGridViewTextBoxColumn2.DataPropertyName = "service_price";
            this.servicepriceDataGridViewTextBoxColumn2.HeaderText = "service_price";
            this.servicepriceDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.servicepriceDataGridViewTextBoxColumn2.Name = "servicepriceDataGridViewTextBoxColumn2";
            this.servicepriceDataGridViewTextBoxColumn2.ReadOnly = true;
            this.servicepriceDataGridViewTextBoxColumn2.Width = 95;
            // 
            // service_id
            // 
            this.service_id.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.service_id.DataPropertyName = "service_id";
            this.service_id.HeaderText = "service_id";
            this.service_id.MinimumWidth = 6;
            this.service_id.Name = "service_id";
            this.service_id.ReadOnly = true;
            this.service_id.Width = 80;
            // 
            // dataGridView2
            // 
            this.dataGridView2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serviceidDataGridViewTextBoxColumn,
            this.servicenameDataGridViewTextBoxColumn1,
            this.servicepriceDataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.serviceBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(8, 159);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidth = 51;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.dataGridView2.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView2.Size = new System.Drawing.Size(776, 128);
            this.dataGridView2.TabIndex = 1;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // serviceidDataGridViewTextBoxColumn
            // 
            this.serviceidDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.serviceidDataGridViewTextBoxColumn.DataPropertyName = "service_id";
            this.serviceidDataGridViewTextBoxColumn.HeaderText = "service_id";
            this.serviceidDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.serviceidDataGridViewTextBoxColumn.Name = "serviceidDataGridViewTextBoxColumn";
            this.serviceidDataGridViewTextBoxColumn.ReadOnly = true;
            this.serviceidDataGridViewTextBoxColumn.Width = 80;
            // 
            // servicenameDataGridViewTextBoxColumn1
            // 
            this.servicenameDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.servicenameDataGridViewTextBoxColumn1.DataPropertyName = "service_name";
            this.servicenameDataGridViewTextBoxColumn1.HeaderText = "service_name";
            this.servicenameDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.servicenameDataGridViewTextBoxColumn1.Name = "servicenameDataGridViewTextBoxColumn1";
            this.servicenameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // servicepriceDataGridViewTextBoxColumn1
            // 
            this.servicepriceDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.servicepriceDataGridViewTextBoxColumn1.DataPropertyName = "service_price";
            this.servicepriceDataGridViewTextBoxColumn1.HeaderText = "service_price";
            this.servicepriceDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.servicepriceDataGridViewTextBoxColumn1.Name = "servicepriceDataGridViewTextBoxColumn1";
            this.servicepriceDataGridViewTextBoxColumn1.ReadOnly = true;
            this.servicepriceDataGridViewTextBoxColumn1.Width = 95;
            // 
            // serviceBindingSource
            // 
            this.serviceBindingSource.DataMember = "Service";
            this.serviceBindingSource.DataSource = this.dsG71;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.textBox10);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.dataGridView4);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.textBox8);
            this.groupBox3.Controls.Add(this.textBox7);
            this.groupBox3.Controls.Add(this.textBox6);
            this.groupBox3.Controls.Add(this.dateTimePicker1);
            this.groupBox3.Controls.Add(this.comboBox2);
            this.groupBox3.Controls.Add(this.textBox3);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.textBox4);
            this.groupBox3.Controls.Add(this.textBox5);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Location = new System.Drawing.Point(8, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(776, 133);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(6, 16);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(75, 17);
            this.label15.TabIndex = 42;
            this.label15.Text = "Customer:";
            // 
            // textBox10
            // 
            this.textBox10.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.innerJoinBS, "customer_name", true));
            this.textBox10.Location = new System.Drawing.Point(130, 15);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(178, 20);
            this.textBox10.TabIndex = 41;
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(609, 12);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(91, 17);
            this.label14.TabIndex = 40;
            this.label14.Text = "Select Barber";
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.employeeidDataGridViewTextBoxColumn,
            this.employeenameDataGridViewTextBoxColumn});
            this.dataGridView4.DataSource = this.employeetblBindingSource;
            this.dataGridView4.Location = new System.Drawing.Point(562, 32);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.ReadOnly = true;
            this.dataGridView4.RowHeadersWidth = 51;
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            this.dataGridView4.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView4.Size = new System.Drawing.Size(208, 95);
            this.dataGridView4.TabIndex = 39;
            this.dataGridView4.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellClick);
            // 
            // employeeidDataGridViewTextBoxColumn
            // 
            this.employeeidDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.employeeidDataGridViewTextBoxColumn.DataPropertyName = "employee_id";
            this.employeeidDataGridViewTextBoxColumn.HeaderText = "id";
            this.employeeidDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeeidDataGridViewTextBoxColumn.Name = "employeeidDataGridViewTextBoxColumn";
            this.employeeidDataGridViewTextBoxColumn.ReadOnly = true;
            this.employeeidDataGridViewTextBoxColumn.Width = 40;
            // 
            // employeenameDataGridViewTextBoxColumn
            // 
            this.employeenameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.employeenameDataGridViewTextBoxColumn.DataPropertyName = "employee_name";
            this.employeenameDataGridViewTextBoxColumn.HeaderText = "employee_name";
            this.employeenameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeenameDataGridViewTextBoxColumn.Name = "employeenameDataGridViewTextBoxColumn";
            this.employeenameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // employeetblBindingSource
            // 
            this.employeetblBindingSource.DataMember = "Employee_tbl";
            this.employeetblBindingSource.DataSource = this.dsG71;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(6, 112);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 17);
            this.label12.TabIndex = 38;
            this.label12.Text = "Amount:";
            // 
            // textBox8
            // 
            this.textBox8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.innerJoinBS, "payment_amount", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "C2"));
            this.textBox8.Location = new System.Drawing.Point(130, 109);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(178, 20);
            this.textBox8.TabIndex = 37;
            // 
            // textBox7
            // 
            this.textBox7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.innerJoinBS, "appointment_id", true));
            this.textBox7.Location = new System.Drawing.Point(535, 76);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(10, 20);
            this.textBox7.TabIndex = 36;
            // 
            // textBox6
            // 
            this.textBox6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.innerJoinBS, "employee_id", true));
            this.textBox6.Location = new System.Drawing.Point(535, 15);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(10, 20);
            this.textBox6.TabIndex = 35;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy/MM/dd";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(330, 76);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(199, 20);
            this.dateTimePicker1.TabIndex = 25;
            this.dateTimePicker1.Value = new System.DateTime(2024, 6, 23, 0, 0, 0, 0);
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.availableTimeBindingSource;
            this.comboBox2.DisplayMember = "TimeSlot";
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(330, 43);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(215, 21);
            this.comboBox2.TabIndex = 24;
            this.comboBox2.ValueMember = "TimeSlot";
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // availableTimeBindingSource
            // 
            this.availableTimeBindingSource.DataMember = "AvailableTime";
            this.availableTimeBindingSource.DataSource = this.dsAppointment1;
            // 
            // dsAppointment1
            // 
            this.dsAppointment1.DataSetName = "dsAppointment";
            this.dsAppointment1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // textBox3
            // 
            this.textBox3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.innerJoinBS, "appointment_date1", true));
            this.textBox3.Location = new System.Drawing.Point(130, 77);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(178, 20);
            this.textBox3.TabIndex = 22;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(6, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 17);
            this.label3.TabIndex = 21;
            this.label3.Text = "Date:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(327, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 17);
            this.label5.TabIndex = 19;
            this.label5.Text = "Barber:";
            // 
            // textBox4
            // 
            this.textBox4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.innerJoinBS, "employee_name", true));
            this.textBox4.Location = new System.Drawing.Point(386, 15);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(143, 20);
            this.textBox4.TabIndex = 20;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.innerJoinBS, "TimeSlot", true));
            this.textBox5.Location = new System.Drawing.Point(130, 44);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(178, 20);
            this.textBox5.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(6, 47);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 17);
            this.label9.TabIndex = 17;
            this.label9.Text = "Time:";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.Options);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 457);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Cancel Appointment";
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button2.BackColor = System.Drawing.Color.Navy;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(8, 410);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(164, 39);
            this.button2.TabIndex = 43;
            this.button2.Text = "Previous";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.Color.Navy;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(620, 410);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(164, 39);
            this.button1.TabIndex = 42;
            this.button1.Text = "Next";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Options
            // 
            this.Options.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Options.Controls.Add(this.cancelAppointmentBtn);
            this.Options.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Options.ForeColor = System.Drawing.Color.Black;
            this.Options.Location = new System.Drawing.Point(184, 325);
            this.Options.Name = "Options";
            this.Options.Size = new System.Drawing.Size(423, 67);
            this.Options.TabIndex = 41;
            this.Options.TabStop = false;
            this.Options.Text = "Options";
            // 
            // cancelAppointmentBtn
            // 
            this.cancelAppointmentBtn.BackColor = System.Drawing.Color.Navy;
            this.cancelAppointmentBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cancelAppointmentBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelAppointmentBtn.ForeColor = System.Drawing.Color.White;
            this.cancelAppointmentBtn.Location = new System.Drawing.Point(17, 22);
            this.cancelAppointmentBtn.Name = "cancelAppointmentBtn";
            this.cancelAppointmentBtn.Size = new System.Drawing.Size(393, 31);
            this.cancelAppointmentBtn.TabIndex = 15;
            this.cancelAppointmentBtn.Text = "Cancel Appointment";
            this.cancelAppointmentBtn.UseVisualStyleBackColor = false;
            this.cancelAppointmentBtn.Click += new System.EventHandler(this.cancelAppointmentBtn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(this.vAppointmentFirstBtn);
            this.groupBox2.Controls.Add(this.vAppointmentNextBtn);
            this.groupBox2.Controls.Add(this.vAppointmentPreviousBtn);
            this.groupBox2.Controls.Add(this.vAppointmentLastBtn);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Black;
            this.groupBox2.Location = new System.Drawing.Point(184, 225);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(423, 94);
            this.groupBox2.TabIndex = 32;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Navigation";
            // 
            // vAppointmentFirstBtn
            // 
            this.vAppointmentFirstBtn.BackColor = System.Drawing.Color.Navy;
            this.vAppointmentFirstBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vAppointmentFirstBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vAppointmentFirstBtn.ForeColor = System.Drawing.Color.White;
            this.vAppointmentFirstBtn.Location = new System.Drawing.Point(17, 36);
            this.vAppointmentFirstBtn.Name = "vAppointmentFirstBtn";
            this.vAppointmentFirstBtn.Size = new System.Drawing.Size(87, 32);
            this.vAppointmentFirstBtn.TabIndex = 13;
            this.vAppointmentFirstBtn.Text = "First";
            this.vAppointmentFirstBtn.UseVisualStyleBackColor = false;
            this.vAppointmentFirstBtn.Click += new System.EventHandler(this.vAppointmentFirstBtn_Click);
            // 
            // vAppointmentNextBtn
            // 
            this.vAppointmentNextBtn.BackColor = System.Drawing.Color.Navy;
            this.vAppointmentNextBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vAppointmentNextBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vAppointmentNextBtn.ForeColor = System.Drawing.Color.White;
            this.vAppointmentNextBtn.Location = new System.Drawing.Point(221, 36);
            this.vAppointmentNextBtn.Name = "vAppointmentNextBtn";
            this.vAppointmentNextBtn.Size = new System.Drawing.Size(87, 32);
            this.vAppointmentNextBtn.TabIndex = 12;
            this.vAppointmentNextBtn.Text = "Next";
            this.vAppointmentNextBtn.UseVisualStyleBackColor = false;
            this.vAppointmentNextBtn.Click += new System.EventHandler(this.vAppointmentNextBtn_Click);
            // 
            // vAppointmentPreviousBtn
            // 
            this.vAppointmentPreviousBtn.BackColor = System.Drawing.Color.Navy;
            this.vAppointmentPreviousBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vAppointmentPreviousBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vAppointmentPreviousBtn.ForeColor = System.Drawing.Color.White;
            this.vAppointmentPreviousBtn.Location = new System.Drawing.Point(119, 36);
            this.vAppointmentPreviousBtn.Name = "vAppointmentPreviousBtn";
            this.vAppointmentPreviousBtn.Size = new System.Drawing.Size(87, 32);
            this.vAppointmentPreviousBtn.TabIndex = 11;
            this.vAppointmentPreviousBtn.Text = "Previous";
            this.vAppointmentPreviousBtn.UseVisualStyleBackColor = false;
            this.vAppointmentPreviousBtn.Click += new System.EventHandler(this.vAppointmentPreviousBtn_Click);
            // 
            // vAppointmentLastBtn
            // 
            this.vAppointmentLastBtn.BackColor = System.Drawing.Color.Navy;
            this.vAppointmentLastBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vAppointmentLastBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vAppointmentLastBtn.ForeColor = System.Drawing.Color.White;
            this.vAppointmentLastBtn.Location = new System.Drawing.Point(323, 36);
            this.vAppointmentLastBtn.Name = "vAppointmentLastBtn";
            this.vAppointmentLastBtn.Size = new System.Drawing.Size(87, 32);
            this.vAppointmentLastBtn.TabIndex = 10;
            this.vAppointmentLastBtn.Text = "Last";
            this.vAppointmentLastBtn.UseVisualStyleBackColor = false;
            this.vAppointmentLastBtn.Click += new System.EventHandler(this.vAppointmentLastBtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.vAppointmentsAmount);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.vAppointmentsBarber);
            this.groupBox1.Controls.Add(this.vAppointmentDateTB);
            this.groupBox1.Controls.Add(this.vAppointmentNameTB);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(184, 17);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(423, 202);
            this.groupBox1.TabIndex = 31;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Appointment Details";
            // 
            // textBox2
            // 
            this.textBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.innerJoinBS, "appointment_id", true));
            this.textBox2.Location = new System.Drawing.Point(365, 153);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(10, 26);
            this.textBox2.TabIndex = 34;
            // 
            // textBox1
            // 
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.innerJoinBS, "appointment_date1", true));
            this.textBox1.Location = new System.Drawing.Point(181, 122);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(178, 26);
            this.textBox1.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(79, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 20);
            this.label1.TabIndex = 15;
            this.label1.Text = "Date:";
            // 
            // vAppointmentsAmount
            // 
            this.vAppointmentsAmount.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.innerJoinBS, "payment_amount", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "C2"));
            this.vAppointmentsAmount.Location = new System.Drawing.Point(181, 153);
            this.vAppointmentsAmount.Name = "vAppointmentsAmount";
            this.vAppointmentsAmount.ReadOnly = true;
            this.vAppointmentsAmount.Size = new System.Drawing.Size(178, 26);
            this.vAppointmentsAmount.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(79, 156);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 20);
            this.label8.TabIndex = 13;
            this.label8.Text = "Amount:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(79, 61);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 20);
            this.label7.TabIndex = 11;
            this.label7.Text = "Barber:";
            // 
            // vAppointmentsBarber
            // 
            this.vAppointmentsBarber.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.innerJoinBS, "employee_name", true));
            this.vAppointmentsBarber.Location = new System.Drawing.Point(181, 58);
            this.vAppointmentsBarber.Name = "vAppointmentsBarber";
            this.vAppointmentsBarber.ReadOnly = true;
            this.vAppointmentsBarber.Size = new System.Drawing.Size(178, 26);
            this.vAppointmentsBarber.TabIndex = 12;
            // 
            // vAppointmentDateTB
            // 
            this.vAppointmentDateTB.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.innerJoinBS, "TimeSlot", true));
            this.vAppointmentDateTB.Location = new System.Drawing.Point(181, 90);
            this.vAppointmentDateTB.Name = "vAppointmentDateTB";
            this.vAppointmentDateTB.ReadOnly = true;
            this.vAppointmentDateTB.Size = new System.Drawing.Size(178, 26);
            this.vAppointmentDateTB.TabIndex = 8;
            // 
            // vAppointmentNameTB
            // 
            this.vAppointmentNameTB.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.innerJoinBS, "customer_name", true));
            this.vAppointmentNameTB.Location = new System.Drawing.Point(181, 30);
            this.vAppointmentNameTB.Name = "vAppointmentNameTB";
            this.vAppointmentNameTB.ReadOnly = true;
            this.vAppointmentNameTB.Size = new System.Drawing.Size(178, 26);
            this.vAppointmentNameTB.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(79, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Time:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(79, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Customer:";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.button5);
            this.tabPage4.Controls.Add(this.dateTimePicker3);
            this.tabPage4.Controls.Add(this.dataGridView5);
            this.tabPage4.Controls.Add(this.dataGridView6);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(792, 457);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "View Cancelled";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button5.BackColor = System.Drawing.Color.Navy;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(7, 410);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(164, 39);
            this.button5.TabIndex = 44;
            this.button5.Text = "Previous";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker3.Location = new System.Drawing.Point(308, 28);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(142, 20);
            this.dateTimePicker3.TabIndex = 36;
            this.dateTimePicker3.ValueChanged += new System.EventHandler(this.dateTimePicker3_ValueChanged);
            // 
            // dataGridView5
            // 
            this.dataGridView5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView5.AutoGenerateColumns = false;
            this.dataGridView5.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.dataGridView5.DataSource = this.dataTable1BindingSource1;
            this.dataGridView5.Location = new System.Drawing.Point(7, 255);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.ReadOnly = true;
            this.dataGridView5.RowHeadersWidth = 51;
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            this.dataGridView5.RowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView5.Size = new System.Drawing.Size(778, 138);
            this.dataGridView5.TabIndex = 35;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn5.DataPropertyName = "appointment_id";
            this.dataGridViewTextBoxColumn5.HeaderText = "appointment_id";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 104;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn7.DataPropertyName = "service_name";
            this.dataGridViewTextBoxColumn7.HeaderText = "service_name";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn8.DataPropertyName = "service_price";
            this.dataGridViewTextBoxColumn8.HeaderText = "service_price";
            this.dataGridViewTextBoxColumn8.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 95;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn9.DataPropertyName = "service_id";
            this.dataGridViewTextBoxColumn9.HeaderText = "service_id";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 80;
            // 
            // dataTable1BindingSource1
            // 
            this.dataTable1BindingSource1.DataMember = "DataTable1";
            this.dataTable1BindingSource1.DataSource = this.dsG72;
            // 
            // dsG72
            // 
            this.dsG72.DataSetName = "dsG7";
            this.dsG72.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView6
            // 
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.dataGridView6.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView6.AutoGenerateColumns = false;
            this.dataGridView6.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18});
            this.dataGridView6.DataSource = this.innerJoinBindingSource;
            this.dataGridView6.Location = new System.Drawing.Point(7, 63);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.ReadOnly = true;
            this.dataGridView6.RowHeadersWidth = 51;
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            this.dataGridView6.RowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridView6.Size = new System.Drawing.Size(778, 174);
            this.dataGridView6.TabIndex = 34;
            this.dataGridView6.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView6_CellClick);
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn10.DataPropertyName = "appointment_id";
            this.dataGridViewTextBoxColumn10.HeaderText = "Id";
            this.dataGridViewTextBoxColumn10.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Width = 41;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn11.DataPropertyName = "customer_name";
            this.dataGridViewTextBoxColumn11.HeaderText = "customer_name";
            this.dataGridViewTextBoxColumn11.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Width = 107;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn12.DataPropertyName = "employee_name";
            this.dataGridViewTextBoxColumn12.HeaderText = "employee_name";
            this.dataGridViewTextBoxColumn12.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Width = 109;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "appointment_date1";
            this.dataGridViewTextBoxColumn13.HeaderText = "date";
            this.dataGridViewTextBoxColumn13.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Width = 125;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "TimeSlot";
            this.dataGridViewTextBoxColumn14.HeaderText = "Time";
            this.dataGridViewTextBoxColumn14.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Width = 125;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn15.DataPropertyName = "payment_amount";
            this.dataGridViewTextBoxColumn15.HeaderText = "Amount";
            this.dataGridViewTextBoxColumn15.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Width = 68;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn16.DataPropertyName = "student_number";
            this.dataGridViewTextBoxColumn16.HeaderText = "student_number";
            this.dataGridViewTextBoxColumn16.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Width = 108;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn17.DataPropertyName = "appointment_status";
            this.dataGridViewTextBoxColumn17.HeaderText = "appointment_status";
            this.dataGridViewTextBoxColumn17.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.Width = 124;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "employee_id";
            this.dataGridViewTextBoxColumn18.HeaderText = "employee_id";
            this.dataGridViewTextBoxColumn18.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.Width = 125;
            // 
            // innerJoinBindingSource
            // 
            this.innerJoinBindingSource.DataMember = "InnerJoin";
            this.innerJoinBindingSource.DataSource = this.dsG72;
            // 
            // iconDropDownButton1
            // 
            this.iconDropDownButton1.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconDropDownButton1.IconColor = System.Drawing.Color.Black;
            this.iconDropDownButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconDropDownButton1.Name = "iconDropDownButton1";
            this.iconDropDownButton1.Size = new System.Drawing.Size(23, 23);
            this.iconDropDownButton1.Text = "iconDropDownButton1";
            // 
            // dsG7
            // 
            this.dsG7.DataSetName = "dsG7";
            this.dsG7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // serviceAppointmentBindingSource
            // 
            this.serviceAppointmentBindingSource.DataMember = "Service_Appointment";
            this.serviceAppointmentBindingSource.DataSource = this.dsG7;
            // 
            // ataViewAppointments
            // 
            this.ataViewAppointments.ClearBeforeFill = true;
            // 
            // taViewAppointments2
            // 
            this.taViewAppointments2.ClearBeforeFill = true;
            // 
            // taService_Appointment
            // 
            this.taService_Appointment.ClearBeforeFill = true;
            // 
            // appointmenttblBindingSource
            // 
            this.appointmenttblBindingSource.DataMember = "Appointment_tbl";
            this.appointmenttblBindingSource.DataSource = this.dsViewAppointments;
            // 
            // taInnerJoin
            // 
            this.taInnerJoin.ClearBeforeFill = true;
            // 
            // taAppointment_tbl
            // 
            this.taAppointment_tbl.ClearBeforeFill = true;
            // 
            // dataTable1TableAdapter
            // 
            this.dataTable1TableAdapter.ClearBeforeFill = true;
            // 
            // taInnerDetails
            // 
            this.taInnerDetails.ClearBeforeFill = true;
            // 
            // taAvailableTimes
            // 
            this.taAvailableTimes.ClearBeforeFill = true;
            // 
            // taService1
            // 
            this.taService1.ClearBeforeFill = true;
            // 
            // tatimes1
            // 
            this.tatimes1.ClearBeforeFill = true;
            // 
            // employee_tblTableAdapter
            // 
            this.employee_tblTableAdapter.ClearBeforeFill = true;
            // 
            // dsG73
            // 
            this.dsG73.DataSetName = "dsG7";
            this.dsG73.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ViewAppointmentUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 483);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ViewAppointmentUI";
            this.Text = "ViewAppointmentUI";
            this.Load += new System.EventHandler(this.ViewAppointmentUI_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvAppointments)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.innerJoinBS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsViewAppointments)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceBindingSource)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeetblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.availableTimeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAppointment1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.Options.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.innerJoinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceAppointmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointmenttblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG73)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button vAppointmentFirstBtn;
        private System.Windows.Forms.Button vAppointmentNextBtn;
        private System.Windows.Forms.Button vAppointmentPreviousBtn;
        private System.Windows.Forms.Button vAppointmentLastBtn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox vAppointmentsAmount;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox vAppointmentsBarber;
        private System.Windows.Forms.TextBox vAppointmentDateTB;
        private System.Windows.Forms.TextBox vAppointmentNameTB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.BindingSource appointmenttblBindingSource;
        public dsG7 dsViewAppointments;
        public dsG7TableAdapters.Appointment_tblTableAdapter ataViewAppointments;
        public dsG7TableAdapters.Appointment_tblTableAdapter taViewAppointments2;
        public System.Windows.Forms.BindingSource innerJoinBS;
        public dsG7TableAdapters.InnerJoinTableAdapter taInnerJoin;
        private System.Windows.Forms.TextBox gvAppointmentsSearchTB;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        public System.Windows.Forms.DataGridView gvAppointments;
        private dsG7TableAdapters.Service_AppointmentTableAdapter taService_Appointment;
        private FontAwesome.Sharp.IconDropDownButton iconDropDownButton1;
        private dsG7 dsG7;
        private System.Windows.Forms.BindingSource serviceAppointmentBindingSource;
        private System.Windows.Forms.GroupBox Options;
        public System.Windows.Forms.Button cancelAppointmentBtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private dsG7TableAdapters.Appointment_tblTableAdapter taAppointment_tbl;
        private dsG7 dsG71;
        private System.Windows.Forms.BindingSource dataTable1BindingSource;
        private dsG7TableAdapters.DataTable1TableAdapter dataTable1TableAdapter;
        private dsG7TableAdapters.DataTable1TableAdapter taInnerDetails;
        private System.Windows.Forms.TabPage tabPage3;
        public System.Windows.Forms.Button UDRemoveSelected;
        public System.Windows.Forms.Button UDRemoveAll;
        public System.Windows.Forms.Button updateBtn;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox6;
        private dsAppointment dsAppointment1;
        private dsAppointmentTableAdapters.AvailableTimeTableAdapter taAvailableTimes;
        private System.Windows.Forms.BindingSource availableTimeBindingSource;
        private dsG7TableAdapters.ServiceTableAdapter taService1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicenameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicepriceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource serviceBindingSource;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private dsG7TableAdapters.TimesTableAdapter tatimes1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DataGridViewTextBoxColumn appointmentidDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicenameDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicepriceDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn service_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn appointmentidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicenameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicepriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.BindingSource employeetblBindingSource;
        private dsG7TableAdapters.Employee_tblTableAdapter employee_tblTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeenameDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn appointment_date1;
        private System.Windows.Forms.DataGridViewTextBoxColumn TimeSlot;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn student_number;
        private System.Windows.Forms.DataGridViewTextBoxColumn appointment_status;
        private System.Windows.Forms.DataGridViewTextBoxColumn employee_id;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        public System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private dsG7 dsG72;
        private System.Windows.Forms.BindingSource innerJoinBindingSource;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private dsG7 dsG73;
        private System.Windows.Forms.BindingSource dataTable1BindingSource1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button5;
    }
}