﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StyleCutsBarberShopSystem
{
    public partial class SalesUI : Form
    {
        decimal tot = 0;
        //String word = "";
        String cName = "";
        String EmployeeName = "";
        String timeslot = "";
        string sNum = "";
        string AppointmentDate = "";
        List<string> services= new List<string>();
        List<int> Service_Id = new List<int>();
        List<string> prices=new List<string>();
        string paymentMethod = "";
        decimal getT = 0;
        decimal change = 0;
        decimal paidAmt = 0;

        private int SelectedTabIndex;


        public SalesUI()
        {
            InitializeComponent();
        }
        public SalesUI(int selectedIndex,int date)
        {
            InitializeComponent();
            SelectedTabIndex = selectedIndex;
            dateTimePicker1.Value = DateTime.Now.AddDays(date);
            this.Load += SalesUI_Load;
            
        }

        private void SalesUI_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dsG72.DataTable1' table. You can move, or remove it, as needed.
           // this.taTable1.Fill(this.dsG72.DataTable1);
            // TODO: This line of code loads data into the 'dsG72.InnerJoin' table. You can move, or remove it, as needed.
            //this.taInnerJoin1.FillByCompleted(this.dsG72.InnerJoin);
            // TODO: This line of code loads data into the 'dsG71.DataTable1' table. You can move, or remove it, as needed.
           // this.taTable1.Fill(this.dsG71.DataTable1);
            // TODO: This line of code loads data into the 'dsG71.DataTable1' table. You can move, or remove it, as needed.
            //this.taTable1.Fill(this.dsG71.DataTable1);
            taInnerJoin1.FillByDate(dsG71.InnerJoin);
            taInnerJoin1.FillByDateTimePicker2(dsG72.InnerJoin, dateTimePicker1.Value.ToString("yyyy-MM-dd"));
            if (SelectedTabIndex >= 0 && SelectedTabIndex < tabControl1.TabPages.Count)
            {
                tabControl1.SelectedIndex = SelectedTabIndex;
            }



            //MessageBox.Show()
        }

        private void gvAppointmentsSearchTB_TextChanged(object sender, EventArgs e)
        {
            taInnerJoin1.FillByCustN(dsG71.InnerJoin, gvAppointmentsSearchTB.Text);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = "R"+dataGridView1.CurrentRow.Cells[4].Value.ToString();
            taTable1.FillByAppointmentID(dsG71.DataTable1, Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value));
        }

        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            taTable1.FillByAppointmentID(dsG72.DataTable1, Convert.ToInt32(dataGridView3.CurrentRow.Cells[0].Value));
        }

        private void UDRemoveSelected_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count==0 || dataGridView2.SelectedRows.Count == 0)
            {
                MessageBox.Show("No items to process payment for.","Payment Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (string.IsNullOrEmpty(textBox2.Text) || !int.TryParse(textBox2.Text, out _))
            {
                MessageBox.Show("Please enter a valid price as an integer.", "Input Error");
                return;
            }

            if (Convert.ToDecimal(textBox1.Text.Substring(1))<=Convert.ToDecimal(textBox2.Text))
            {
               // if(comboBox1.Text)
                change = Convert.ToDecimal(textBox2.Text) - Convert.ToDecimal(textBox1.Text.Substring(1));
                paidAmt = Convert.ToDecimal(textBox2.Text);
                sNum = dataGridView1.CurrentRow.Cells[8].Value.ToString();
                cName = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                EmployeeName = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                timeslot = dataGridView1.CurrentRow.Cells[6].Value.ToString();
                AppointmentDate = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                fillList();
                 getT = getTotal();
                paymentMethod = comboBox1.Text;

                taAppointment.UpdateQuery(comboBox1.Text,"completed", Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value));
                /****************************************************/
                int size = Convert.ToInt32(service_InventoryTableAdapter1.Size());
                DBConnect connect = new DBConnect();
                DataTable DT = connect.QueryDT();
                for (int i = 0; i < Service_Id.Count; i++)
                {
                    int current_id = Service_Id[i];
                    
                    for (int j = 0; j < size; j++)
                    {
                       if( Convert.ToInt32(DT.Rows[j]["service_id"]) == current_id)
                        {
                            int num = Convert.ToInt32(DT.Rows[j]["item_id"]);
                            int num2 = Convert.ToInt32(DT.Rows[j]["quantity"]);

                            inventory_tblTableAdapter1.UpdateQuantity(num2, num );
                        }

                        //MessageBox.Show(DT.Rows[0]["service_id"].ToString() + " " + DT.Rows[0]["item_id"].ToString() + " " + DT.Rows[0]["quantity"].ToString());



                    }
                  
                    

                    
                }
                /* for(int i = 0; i < services.Count; i++)
                {
                    if (services[i].Contains("dye"))
                    {
                        if (services[i].Contains("Blue"))
                        {
                            inventory_tblTableAdapter1.UpdateQuantity(1, 11);
                           

                        }
                        else if (services[i].Contains("Black"))
                        {
                            inventory_tblTableAdapter1.UpdateQuantity(1, 1);
                           
                        }
                        else if (services[i].Contains("Blonde"))
                        {
                            inventory_tblTableAdapter1.UpdateQuantity(1, 2);
                            
                        }
                        else if (services[i].Contains("Brown"))
                        {
                            inventory_tblTableAdapter1.UpdateQuantity(1, 3);
                           
                        }
                        else if (services[i].Contains("Grey"))
                        {
                            inventory_tblTableAdapter1.UpdateQuantity(1, 4);
                            
                        }
                        else if (services[i].Contains("White"))
                        {
                            inventory_tblTableAdapter1.UpdateQuantity(1, 5);
                           
                        }



                    }
                    else
                    {
                        inventory_tblTableAdapter1.UpdateQuantity(1, 9);
                        inventory_tblTableAdapter1.UpdateQuantity(1, 10);

                    }
                }*/





                /**************************************************/
                MessageBox.Show("Payment successful");
                Generate();
                taInnerJoin1.FillByCompleted(this.dsG72.InnerJoin);
                taInnerJoin1.FillByDate(dsG71.InnerJoin);
                tot = Convert.ToDecimal(textBox1.Text.Substring(1));
                if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
                {
                    tabControl1.SelectedIndex += 1;
                }
                textBox1.Clear();
                textBox2.Clear();
                dsG71.DataTable1.Clear();

                
                  



                
            }
            else
            {
                decimal owe = Convert.ToDecimal(textBox1.Text.Substring(1));
                Decimal paid = Convert.ToDecimal(textBox2.Text);
                MessageBox.Show("Still owing" + " R " + (owe - paid).ToString());
            }

            /***********************************************************************************/
            DBConnect2 connect2 = new DBConnect2();
            DataTable DT2 = connect2.QueryDT();
            int size2 = DT2.Rows.Count;
            DialogResult c = DialogResult.None;
           // int selecterow = 0;
            for (int i = 0; i < size2; i++)
            {
                if ((int)DT2.Rows[i]["quantityAvailable"] <= 20)
                {
                    c = MessageBox.Show("Urgent: " + (string)DT2.Rows[i]["item_name"] + " is critically low! Only " + (int)DT2.Rows[i]["quantityAvailable"] + " units remaining. Immediate restocking is recommended!!\n You must update the stock immediately!!!?",
                        "LOW STOCK ALERT!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                   // selecterow = i;
                }
            }





            /**********************************************************************************/
        }

        private void GenerateBtn_Click(object sender, EventArgs e)
        {
            
            
                txtRRB.Clear();
                txtRRB.Text += "*******************************************************\n";
                txtRRB.Text += "*                 StyleCuts BarberShop                *\n";
                txtRRB.Text += "*******************************************************\n";
                txtRRB.Text += "Date: " + DateTime.Now + "\n\n";
                txtRRB.Text += "Customer Name: " + cName  + "\n\n";
                txtRRB.Text += "Barber: " +  EmployeeName + "\n\n";
                txtRRB.Text += "Appointment Date: " +  AppointmentDate + "\n\n";
                txtRRB.Text += "Time Slot: " + timeslot+ "\n\n";
                txtRRB.Text += "Service Name: ";
                for (int i = 0; i < services.Count ; i++)
                {
                    if (i == 0)
                    {
                        txtRRB.Text += services[i] + "  R" + prices[i] + "\n\n";
                    }
                    else
                    {
                        txtRRB.Text += "                      " + services[i] + "  R" + prices[i] + "\n\n";
                    }

                }
                if (sNum != "N/A")
                {
                    txtRRB.Text += "Student Number: " + sNum + "\n\n";
                    txtRRB.Text += "Student Discount Rate: " + "15%" + "\n\n";
                    txtRRB.Text += "Total Price: " + getT.ToString("C2") + "\n\n";
                    txtRRB.Text += "Discounted Total: " + "R"+ tot + "\n\n\n";
                    txtRRB.Text += "Paid Amount: " + " R" +paidAmt  + "\n\n";
                    txtRRB.Text += "Payment Method: " + paymentMethod + "\n\n";
                    txtRRB.Text += "Change:" + " R" + change + "\n\n";

                }
                else
                {
                    txtRRB.Text += "Total Price: " + "R" + tot + "\n\n";
                    txtRRB.Text += "Paid Amount: " + " R" + paidAmt + "\n\n";
                    txtRRB.Text += "Payment Method: " + paymentMethod + "\n\n";
                    txtRRB.Text += "Change:" + " R" + change + "\n\n";
                }


                txtRRB.Text += "*******************************************************\n";
                txtRRB.Text += "Thank You for choosing SyleCuts Barber Shop\n";
                txtRRB.Text += "*******************************************************\n";

            prices.Clear();
            services.Clear();

        }
        private decimal getTotal()
        {
            decimal total = 0;
            for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
            {
                total += Convert.ToDecimal(dataGridView2.Rows[i].Cells[2].Value);

            }
            return total;
        }

        private void PrintBtn_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(txtRRB.Text, new Font("Microsoft Sans Serif", 18, FontStyle.Bold), Brushes.Black, new Point(10, 10));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtRRB.Clear();
        }
        private void fillList()
        {
            
            for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
            {
                Service_Id.Add(Convert.ToInt32(dataGridView2.Rows[i].Cells[3].Value));
                services.Add(Convert.ToString(dataGridView2.Rows[i].Cells[1].Value));
                prices.Add(Convert.ToString(dataGridView2.Rows[i].Cells[2].Value));
            }

            

           // for (int i = 0; i <= service_id.Count - 1; i++)
            //{
              //  taService_Appointment.Insert1(Appointment_id, service_id[i]);
           // }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "card")
            {
           
                textBox2.Text = textBox1.Text.Substring(1);
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            taInnerJoin1.FillByDateTimePicker2(dsG72.InnerJoin, dateTimePicker1.Value.ToString("yyyy-MM-dd"));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex > 0)
            {
                tabControl1.SelectedIndex -= 1;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex > 0)
            {
                tabControl1.SelectedIndex -= 1;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
            {
                tabControl1.SelectedIndex += 1;
            }
        }
        private void Generate()
        {

            txtRRB.Clear();
            txtRRB.Text += "*******************************************************\n";
            txtRRB.Text += "*                 StyleCuts BarberShop                *\n";
            txtRRB.Text += "*******************************************************\n";
            txtRRB.Text += "Date: " + DateTime.Now + "\n\n";
            txtRRB.Text += "Customer Name: " + cName + "\n\n";
            txtRRB.Text += "Barber: " + EmployeeName + "\n\n";
            txtRRB.Text += "Appointment Date: " + AppointmentDate + "\n\n";
            txtRRB.Text += "Time Slot: " + timeslot + "\n\n";
            txtRRB.Text += "Service Name: ";
            for (int i = 0; i < services.Count; i++)
            {
                if (i == 0)
                {
                    txtRRB.Text += services[i] + "  R" + prices[i] + "\n\n";
                }
                else
                {
                    txtRRB.Text += "                      " + services[i] + "  R" + prices[i] + "\n\n";
                }

            }
            if (sNum != "N/A")
            {
                txtRRB.Text += "Student Number: " + sNum + "\n\n";
                txtRRB.Text += "Student Discount Rate: " + "15%" + "\n\n";
                txtRRB.Text += "Total Price: " + getT.ToString("C2") + "\n\n";
                txtRRB.Text += "Discounted Total: " + "R" + tot + "\n\n\n";
                txtRRB.Text += "Paid Amount: " + " R" + paidAmt + "\n\n";
                txtRRB.Text += "Payment Method: " + paymentMethod + "\n\n";
                txtRRB.Text += "Change:" + " R" + change + "\n\n";

            }
            else
            {
                txtRRB.Text += "Total Price: " + "R" + tot + "\n\n";
                txtRRB.Text += "Paid Amount: " + " R" + paidAmt + "\n\n";
                txtRRB.Text += "Payment Method: " + paymentMethod + "\n\n";
                txtRRB.Text += "Change:" + " R" + change + "\n\n";
            }


            txtRRB.Text += "*******************************************************\n";
            txtRRB.Text += "Thank You for choosing SyleCuts Barber Shop\n";
            txtRRB.Text += "*******************************************************\n";

           // prices.Clear();
           // services.Clear();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
