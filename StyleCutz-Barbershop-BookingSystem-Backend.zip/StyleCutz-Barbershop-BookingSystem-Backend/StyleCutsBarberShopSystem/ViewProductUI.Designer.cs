﻿
namespace StyleCutsBarberShopSystem
{
    partial class ViewProductUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.gvProductsSearchTB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.gvProducts = new System.Windows.Forms.DataGridView();
            this.itemidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.suppliernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityAvailableDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itempriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataTable2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsViewProduct = new StyleCutsBarberShopSystem.dsG7();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Options = new System.Windows.Forms.GroupBox();
            this.DeleteBtn = new System.Windows.Forms.Button();
            this.vProductUpdateBtn = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.vProductFirstBtn = new System.Windows.Forms.Button();
            this.vProductNextBtn = new System.Windows.Forms.Button();
            this.vProductPrevousBtn = new System.Windows.Forms.Button();
            this.vProductLastBtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.vProductSupplierTB = new System.Windows.Forms.TextBox();
            this.vProductNameTB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.supplier_tblTableAdapter = new StyleCutsBarberShopSystem.dsG7TableAdapters.Supplier_tblTableAdapter();
            this.dsG71 = new StyleCutsBarberShopSystem.dsG7();
            this.taViewProductBS = new System.Windows.Forms.BindingSource(this.components);
            this.taViewProduct1 = new StyleCutsBarberShopSystem.dsG7TableAdapters.Inventory_tblTableAdapter();
            this.suppliertblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.inventorytblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataTable2TableAdapter = new StyleCutsBarberShopSystem.dsG7TableAdapters.DataTable2TableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvProducts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsViewProduct)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.Options.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dsG71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.taViewProductBS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.suppliertblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventorytblBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 450);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.gvProductsSearchTB);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.gvProducts);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 424);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "View Product Details";
            // 
            // gvProductsSearchTB
            // 
            this.gvProductsSearchTB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gvProductsSearchTB.ForeColor = System.Drawing.Color.Black;
            this.gvProductsSearchTB.Location = new System.Drawing.Point(325, 28);
            this.gvProductsSearchTB.Name = "gvProductsSearchTB";
            this.gvProductsSearchTB.Size = new System.Drawing.Size(178, 20);
            this.gvProductsSearchTB.TabIndex = 47;
            this.gvProductsSearchTB.TextChanged += new System.EventHandler(this.gvProductsSearchTB_TextChanged);
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(189, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 20);
            this.label6.TabIndex = 46;
            this.label6.Text = "Product Name:";
            // 
            // gvProducts
            // 
            this.gvProducts.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gvProducts.AutoGenerateColumns = false;
            this.gvProducts.BackgroundColor = System.Drawing.Color.White;
            this.gvProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvProducts.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.itemidDataGridViewTextBoxColumn,
            this.suppliernameDataGridViewTextBoxColumn,
            this.quantityAvailableDataGridViewTextBoxColumn,
            this.itemnameDataGridViewTextBoxColumn,
            this.itempriceDataGridViewTextBoxColumn});
            this.gvProducts.DataSource = this.dataTable2BindingSource;
            this.gvProducts.Location = new System.Drawing.Point(8, 70);
            this.gvProducts.Name = "gvProducts";
            this.gvProducts.ReadOnly = true;
            this.gvProducts.RowHeadersWidth = 51;
            this.gvProducts.Size = new System.Drawing.Size(776, 328);
            this.gvProducts.TabIndex = 45;
            this.gvProducts.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvProducts_CellClick);
            // 
            // itemidDataGridViewTextBoxColumn
            // 
            this.itemidDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.itemidDataGridViewTextBoxColumn.DataPropertyName = "item_id";
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.itemidDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.itemidDataGridViewTextBoxColumn.HeaderText = "item_id";
            this.itemidDataGridViewTextBoxColumn.Name = "itemidDataGridViewTextBoxColumn";
            this.itemidDataGridViewTextBoxColumn.ReadOnly = true;
            this.itemidDataGridViewTextBoxColumn.Width = 65;
            // 
            // suppliernameDataGridViewTextBoxColumn
            // 
            this.suppliernameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.suppliernameDataGridViewTextBoxColumn.DataPropertyName = "supplier_name";
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.suppliernameDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.suppliernameDataGridViewTextBoxColumn.HeaderText = "supplier_name";
            this.suppliernameDataGridViewTextBoxColumn.Name = "suppliernameDataGridViewTextBoxColumn";
            this.suppliernameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // quantityAvailableDataGridViewTextBoxColumn
            // 
            this.quantityAvailableDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.quantityAvailableDataGridViewTextBoxColumn.DataPropertyName = "quantityAvailable";
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.quantityAvailableDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle3;
            this.quantityAvailableDataGridViewTextBoxColumn.HeaderText = "quantityAvailable";
            this.quantityAvailableDataGridViewTextBoxColumn.Name = "quantityAvailableDataGridViewTextBoxColumn";
            this.quantityAvailableDataGridViewTextBoxColumn.ReadOnly = true;
            this.quantityAvailableDataGridViewTextBoxColumn.Width = 112;
            // 
            // itemnameDataGridViewTextBoxColumn
            // 
            this.itemnameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.itemnameDataGridViewTextBoxColumn.DataPropertyName = "item_name";
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.itemnameDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle4;
            this.itemnameDataGridViewTextBoxColumn.HeaderText = "item_name";
            this.itemnameDataGridViewTextBoxColumn.Name = "itemnameDataGridViewTextBoxColumn";
            this.itemnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // itempriceDataGridViewTextBoxColumn
            // 
            this.itempriceDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.itempriceDataGridViewTextBoxColumn.DataPropertyName = "item_price";
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.itempriceDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle5;
            this.itempriceDataGridViewTextBoxColumn.HeaderText = "item_price";
            this.itempriceDataGridViewTextBoxColumn.Name = "itempriceDataGridViewTextBoxColumn";
            this.itempriceDataGridViewTextBoxColumn.ReadOnly = true;
            this.itempriceDataGridViewTextBoxColumn.Width = 80;
            // 
            // dataTable2BindingSource
            // 
            this.dataTable2BindingSource.DataMember = "DataTable2";
            this.dataTable2BindingSource.DataSource = this.dsViewProduct;
            // 
            // dsViewProduct
            // 
            this.dsViewProduct.DataSetName = "dsG7";
            this.dsViewProduct.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.Options);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 424);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Modify Product Details";
            // 
            // Options
            // 
            this.Options.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Options.Controls.Add(this.DeleteBtn);
            this.Options.Controls.Add(this.vProductUpdateBtn);
            this.Options.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Options.ForeColor = System.Drawing.Color.Black;
            this.Options.Location = new System.Drawing.Point(187, 306);
            this.Options.Name = "Options";
            this.Options.Size = new System.Drawing.Size(423, 74);
            this.Options.TabIndex = 40;
            this.Options.TabStop = false;
            this.Options.Text = "Options";
            // 
            // DeleteBtn
            // 
            this.DeleteBtn.BackColor = System.Drawing.Color.Navy;
            this.DeleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.DeleteBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteBtn.ForeColor = System.Drawing.Color.White;
            this.DeleteBtn.Location = new System.Drawing.Point(16, 22);
            this.DeleteBtn.Name = "DeleteBtn";
            this.DeleteBtn.Size = new System.Drawing.Size(189, 37);
            this.DeleteBtn.TabIndex = 16;
            this.DeleteBtn.Text = "Delete";
            this.DeleteBtn.UseVisualStyleBackColor = false;
            this.DeleteBtn.Click += new System.EventHandler(this.DeleteBtn_Click);
            // 
            // vProductUpdateBtn
            // 
            this.vProductUpdateBtn.BackColor = System.Drawing.Color.Navy;
            this.vProductUpdateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vProductUpdateBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vProductUpdateBtn.ForeColor = System.Drawing.Color.White;
            this.vProductUpdateBtn.Location = new System.Drawing.Point(221, 22);
            this.vProductUpdateBtn.Name = "vProductUpdateBtn";
            this.vProductUpdateBtn.Size = new System.Drawing.Size(189, 37);
            this.vProductUpdateBtn.TabIndex = 15;
            this.vProductUpdateBtn.Text = "Update";
            this.vProductUpdateBtn.UseVisualStyleBackColor = false;
            this.vProductUpdateBtn.Click += new System.EventHandler(this.vProductUpdateBtn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(this.vProductFirstBtn);
            this.groupBox2.Controls.Add(this.vProductNextBtn);
            this.groupBox2.Controls.Add(this.vProductPrevousBtn);
            this.groupBox2.Controls.Add(this.vProductLastBtn);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Black;
            this.groupBox2.Location = new System.Drawing.Point(187, 223);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(423, 77);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Navigation";
            // 
            // vProductFirstBtn
            // 
            this.vProductFirstBtn.BackColor = System.Drawing.Color.Navy;
            this.vProductFirstBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vProductFirstBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vProductFirstBtn.ForeColor = System.Drawing.Color.White;
            this.vProductFirstBtn.Location = new System.Drawing.Point(16, 25);
            this.vProductFirstBtn.Name = "vProductFirstBtn";
            this.vProductFirstBtn.Size = new System.Drawing.Size(87, 37);
            this.vProductFirstBtn.TabIndex = 13;
            this.vProductFirstBtn.Text = "First";
            this.vProductFirstBtn.UseVisualStyleBackColor = false;
            this.vProductFirstBtn.Click += new System.EventHandler(this.vProductFirstBtn_Click);
            // 
            // vProductNextBtn
            // 
            this.vProductNextBtn.BackColor = System.Drawing.Color.Navy;
            this.vProductNextBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vProductNextBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vProductNextBtn.ForeColor = System.Drawing.Color.White;
            this.vProductNextBtn.Location = new System.Drawing.Point(221, 25);
            this.vProductNextBtn.Name = "vProductNextBtn";
            this.vProductNextBtn.Size = new System.Drawing.Size(87, 37);
            this.vProductNextBtn.TabIndex = 12;
            this.vProductNextBtn.Text = "Next";
            this.vProductNextBtn.UseVisualStyleBackColor = false;
            this.vProductNextBtn.Click += new System.EventHandler(this.vProductNextBtn_Click);
            // 
            // vProductPrevousBtn
            // 
            this.vProductPrevousBtn.BackColor = System.Drawing.Color.Navy;
            this.vProductPrevousBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vProductPrevousBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vProductPrevousBtn.ForeColor = System.Drawing.Color.White;
            this.vProductPrevousBtn.Location = new System.Drawing.Point(118, 25);
            this.vProductPrevousBtn.Name = "vProductPrevousBtn";
            this.vProductPrevousBtn.Size = new System.Drawing.Size(87, 37);
            this.vProductPrevousBtn.TabIndex = 11;
            this.vProductPrevousBtn.Text = "Previous";
            this.vProductPrevousBtn.UseVisualStyleBackColor = false;
            this.vProductPrevousBtn.Click += new System.EventHandler(this.vProductPrevousBtn_Click);
            // 
            // vProductLastBtn
            // 
            this.vProductLastBtn.BackColor = System.Drawing.Color.Navy;
            this.vProductLastBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vProductLastBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vProductLastBtn.ForeColor = System.Drawing.Color.White;
            this.vProductLastBtn.Location = new System.Drawing.Point(323, 25);
            this.vProductLastBtn.Name = "vProductLastBtn";
            this.vProductLastBtn.Size = new System.Drawing.Size(87, 37);
            this.vProductLastBtn.TabIndex = 10;
            this.vProductLastBtn.Text = "Last";
            this.vProductLastBtn.UseVisualStyleBackColor = false;
            this.vProductLastBtn.Click += new System.EventHandler(this.vProductLastBtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.vProductSupplierTB);
            this.groupBox1.Controls.Add(this.vProductNameTB);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(187, 52);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(423, 152);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Product Details";
            // 
            // textBox1
            // 
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dataTable2BindingSource, "item_price", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "N0"));
            this.textBox1.Location = new System.Drawing.Point(166, 102);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(178, 26);
            this.textBox1.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(60, 105);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Price:";
            // 
            // vProductSupplierTB
            // 
            this.vProductSupplierTB.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dataTable2BindingSource, "supplier_name", true));
            this.vProductSupplierTB.Location = new System.Drawing.Point(166, 70);
            this.vProductSupplierTB.Name = "vProductSupplierTB";
            this.vProductSupplierTB.Size = new System.Drawing.Size(178, 26);
            this.vProductSupplierTB.TabIndex = 7;
            // 
            // vProductNameTB
            // 
            this.vProductNameTB.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dataTable2BindingSource, "item_name", true));
            this.vProductNameTB.Location = new System.Drawing.Point(166, 40);
            this.vProductNameTB.Name = "vProductNameTB";
            this.vProductNameTB.Size = new System.Drawing.Size(178, 26);
            this.vProductNameTB.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(60, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Supplier:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(60, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Name:";
            // 
            // supplier_tblTableAdapter
            // 
            this.supplier_tblTableAdapter.ClearBeforeFill = true;
            // 
            // dsG71
            // 
            this.dsG71.DataSetName = "dsG7";
            this.dsG71.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // taViewProductBS
            // 
            this.taViewProductBS.DataMember = "Inventory_tbl";
            this.taViewProductBS.DataSource = this.dsViewProduct;
            // 
            // taViewProduct1
            // 
            this.taViewProduct1.ClearBeforeFill = true;
            // 
            // suppliertblBindingSource
            // 
            this.suppliertblBindingSource.DataMember = "Supplier_tbl";
            this.suppliertblBindingSource.DataSource = this.dsViewProduct;
            // 
            // inventorytblBindingSource
            // 
            this.inventorytblBindingSource.DataMember = "Inventory_tbl";
            this.inventorytblBindingSource.DataSource = this.dsViewProduct;
            // 
            // dataTable2TableAdapter
            // 
            this.dataTable2TableAdapter.ClearBeforeFill = true;
            // 
            // ViewProductUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ViewProductUI";
            this.Text = "ViewProductUI";
            this.Load += new System.EventHandler(this.ViewProductUI_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvProducts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsViewProduct)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.Options.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dsG71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.taViewProductBS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.suppliertblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventorytblBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox Options;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button vProductFirstBtn;
        private System.Windows.Forms.Button vProductNextBtn;
        private System.Windows.Forms.Button vProductPrevousBtn;
        private System.Windows.Forms.Button vProductLastBtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox vProductSupplierTB;
        private System.Windows.Forms.TextBox vProductNameTB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox gvProductsSearchTB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView gvProducts;
        private dsG7TableAdapters.Inventory_tblTableAdapter taViewProduct1;
        private dsG7 dsViewProduct;
        private System.Windows.Forms.BindingSource taViewProductBS;
        public System.Windows.Forms.Button vProductUpdateBtn;
        private System.Windows.Forms.BindingSource suppliertblBindingSource;
        private dsG7TableAdapters.Supplier_tblTableAdapter supplier_tblTableAdapter;
        private dsG7 dsG71;
        private System.Windows.Forms.BindingSource inventorytblBindingSource;
        private System.Windows.Forms.BindingSource dataTable2BindingSource;
        private dsG7TableAdapters.DataTable2TableAdapter dataTable2TableAdapter;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Button DeleteBtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn suppliernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityAvailableDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itempriceDataGridViewTextBoxColumn;
    }
}