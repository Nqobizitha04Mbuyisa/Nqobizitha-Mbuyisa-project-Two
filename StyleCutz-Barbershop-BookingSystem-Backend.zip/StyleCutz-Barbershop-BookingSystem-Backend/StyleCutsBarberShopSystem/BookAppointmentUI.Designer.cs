﻿
namespace StyleCutsBarberShopSystem
{
    partial class BookAppointmentUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BookAppointmentUI));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button16 = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.employeeidDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeenameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeetblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsG71 = new StyleCutsBarberShopSystem.dsG7();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.customeridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customercellNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customeremailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customeraddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentnumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customertblBS = new System.Windows.Forms.BindingSource(this.components);
            this.Service = new System.Windows.Forms.TabPage();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.serviceidDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicenameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicepriceDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serviceTwoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsNew = new StyleCutsBarberShopSystem.DataSet1();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.serviceidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicenameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicepriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serviceBS1 = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.gvBAB = new System.Windows.Forms.DataGridView();
            this.employeeidDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeenameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeecellNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeemailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empoyeegenderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employee_position = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeetblBS = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button14 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.appointmenttblBS = new System.Windows.Forms.BindingSource(this.components);
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.StudentNoTB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.bookAppointmentBTB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.physicalAddressTB = new System.Windows.Forms.TextBox();
            this.priceTB = new System.Windows.Forms.TextBox();
            this.priceLabel = new System.Windows.Forms.Label();
            this.acnameTB = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.BarberLB = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.atimeCB = new System.Windows.Forms.ComboBox();
            this.availableTimeBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dsAppointment1 = new StyleCutsBarberShopSystem.dsAppointment();
            this.aemailAddressTB = new System.Windows.Forms.TextBox();
            this.acustcellNumberTB = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button15 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.PrintBtn = new System.Windows.Forms.Button();
            this.GenerateBtn = new System.Windows.Forms.Button();
            this.txtRRB = new System.Windows.Forms.RichTextBox();
            this.custBS = new System.Windows.Forms.BindingSource(this.components);
            this.dsG72 = new StyleCutsBarberShopSystem.dsG7();
            this.barBS = new System.Windows.Forms.BindingSource(this.components);
            this.timesBS = new System.Windows.Forms.BindingSource(this.components);
            this.timesBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.appointmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.taServiceTwo = new StyleCutsBarberShopSystem.DataSet1TableAdapters.ServiceTwoTableAdapter();
            this.taService1 = new StyleCutsBarberShopSystem.dsG7TableAdapters.ServiceTableAdapter();
            this.taEmployee1 = new StyleCutsBarberShopSystem.dsG7TableAdapters.Employee_tblTableAdapter();
            this.taCustomer = new StyleCutsBarberShopSystem.dsG7TableAdapters.Customer_tblTableAdapter();
            this.timesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.timesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.timesBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.dsAppointment = new StyleCutsBarberShopSystem.dsAppointment();
            this.timesTableAdapter = new StyleCutsBarberShopSystem.dsAppointmentTableAdapters.TimesTableAdapter();
            this.previousAppointmentTableAdapter1 = new StyleCutsBarberShopSystem.dsAppointmentTableAdapters.PreviousAppointmentTableAdapter();
            this.availableTimeTableAdapter1 = new StyleCutsBarberShopSystem.dsAppointmentTableAdapters.AvailableTimeTableAdapter();
            this.appointment_tblTableAdapter1 = new StyleCutsBarberShopSystem.dsAppointmentTableAdapters.Appointment_tblTableAdapter();
            this.dsAppointment1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.availableTimeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.taAvailable = new StyleCutsBarberShopSystem.dsAppointmentTableAdapters.AvailableTimeTableAdapter();
            this.taNewApointment = new StyleCutsBarberShopSystem.dsG7TableAdapters.Appointment_tblTableAdapter();
            this.dsAppointment2 = new StyleCutsBarberShopSystem.dsAppointment();
            this.taTimes1 = new StyleCutsBarberShopSystem.dsAppointmentTableAdapters.TimesTableAdapter();
            this.customertblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.taCustomer33 = new StyleCutsBarberShopSystem.dsG7TableAdapters.Customer_tblTableAdapter();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.taAppointment_tbl = new StyleCutsBarberShopSystem.dsG7TableAdapters.Appointment_tblTableAdapter();
            this.taService_Appointment = new StyleCutsBarberShopSystem.dsG7TableAdapters.Service_AppointmentTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeetblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG71)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customertblBS)).BeginInit();
            this.Service.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceTwoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsNew)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceBS1)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvBAB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeetblBS)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.appointmenttblBS)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.availableTimeBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAppointment1)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.custBS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barBS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.timesBS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.timesBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.timesBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.timesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.timesBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAppointment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAppointment1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.availableTimeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAppointment2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customertblBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.Service);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 481);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            this.tabControl1.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl1_Selected);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.White;
            this.tabPage4.Controls.Add(this.button16);
            this.tabPage4.Controls.Add(this.dataGridView4);
            this.tabPage4.Controls.Add(this.groupBox1);
            this.tabPage4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage4.Location = new System.Drawing.Point(4, 26);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage4.Size = new System.Drawing.Size(792, 451);
            this.tabPage4.TabIndex = 4;
            this.tabPage4.Text = "Create New Customer";
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // button16
            // 
            this.button16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button16.BackColor = System.Drawing.Color.Navy;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button16.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.White;
            this.button16.Location = new System.Drawing.Point(599, 391);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(164, 39);
            this.button16.TabIndex = 26;
            this.button16.Text = "Next";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // dataGridView4
            // 
            this.dataGridView4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.employeeidDataGridViewTextBoxColumn2,
            this.employeenameDataGridViewTextBoxColumn1});
            this.dataGridView4.DataSource = this.employeetblBindingSource;
            this.dataGridView4.Location = new System.Drawing.Point(523, 46);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.ReadOnly = true;
            this.dataGridView4.RowHeadersWidth = 51;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.dataGridView4.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView4.Size = new System.Drawing.Size(240, 150);
            this.dataGridView4.TabIndex = 25;
            this.dataGridView4.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellClick);
            // 
            // employeeidDataGridViewTextBoxColumn2
            // 
            this.employeeidDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.employeeidDataGridViewTextBoxColumn2.DataPropertyName = "employee_id";
            this.employeeidDataGridViewTextBoxColumn2.HeaderText = "id";
            this.employeeidDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.employeeidDataGridViewTextBoxColumn2.Name = "employeeidDataGridViewTextBoxColumn2";
            this.employeeidDataGridViewTextBoxColumn2.ReadOnly = true;
            this.employeeidDataGridViewTextBoxColumn2.Width = 47;
            // 
            // employeenameDataGridViewTextBoxColumn1
            // 
            this.employeenameDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.employeenameDataGridViewTextBoxColumn1.DataPropertyName = "employee_name";
            this.employeenameDataGridViewTextBoxColumn1.HeaderText = "employee_name";
            this.employeenameDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.employeenameDataGridViewTextBoxColumn1.Name = "employeenameDataGridViewTextBoxColumn1";
            this.employeenameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // employeetblBindingSource
            // 
            this.employeetblBindingSource.DataMember = "Employee_tbl";
            this.employeetblBindingSource.DataSource = this.dsG71;
            // 
            // dsG71
            // 
            this.dsG71.DataSetName = "dsG7";
            this.dsG71.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(this.textBox9);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.textBox6);
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.button6);
            this.groupBox1.Controls.Add(this.textBox7);
            this.groupBox1.Controls.Add(this.textBox8);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(56, 34);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(451, 318);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Customer Details";
            // 
            // textBox9
            // 
            this.textBox9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox9.Location = new System.Drawing.Point(220, 217);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(180, 26);
            this.textBox9.TabIndex = 38;
            // 
            // textBox2
            // 
            this.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox2.Location = new System.Drawing.Point(220, 184);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(201, 26);
            this.textBox2.TabIndex = 37;
            this.textBox2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox2_KeyDown);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 184);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 20);
            this.label4.TabIndex = 36;
            this.label4.Text = "Student No";
            // 
            // textBox3
            // 
            this.textBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox3.Location = new System.Drawing.Point(406, 217);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(15, 26);
            this.textBox3.TabIndex = 35;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(25, 153);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(129, 20);
            this.label5.TabIndex = 34;
            this.label5.Text = "Physical Address";
            // 
            // textBox4
            // 
            this.textBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox4.Location = new System.Drawing.Point(220, 153);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(201, 26);
            this.textBox4.TabIndex = 33;
            this.textBox4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox4_KeyDown);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(220, 50);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(201, 26);
            this.textBox6.TabIndex = 25;
            this.textBox6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox6_KeyDown);
            // 
            // button5
            // 
            this.button5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button5.BackColor = System.Drawing.Color.Navy;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(347, 264);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 35);
            this.button5.TabIndex = 31;
            this.button5.Text = "Confirm";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(25, 217);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 20);
            this.label7.TabIndex = 32;
            this.label7.Text = "Barber";
            // 
            // button6
            // 
            this.button6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button6.BackColor = System.Drawing.Color.Navy;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(220, 264);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 35);
            this.button6.TabIndex = 30;
            this.button6.Text = "Clear";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // textBox7
            // 
            this.textBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox7.Location = new System.Drawing.Point(220, 119);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(201, 26);
            this.textBox7.TabIndex = 29;
            this.textBox7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox7_KeyDown);
            // 
            // textBox8
            // 
            this.textBox8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox8.Location = new System.Drawing.Point(220, 83);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(201, 26);
            this.textBox8.TabIndex = 28;
            this.textBox8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox8_KeyDown);
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(25, 119);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(108, 20);
            this.label10.TabIndex = 27;
            this.label10.Text = "Email Address";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(25, 83);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(147, 20);
            this.label13.TabIndex = 26;
            this.label13.Text = "Cellphone Number";
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(25, 48);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 20);
            this.label15.TabIndex = 24;
            this.label15.Text = "Name";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.White;
            this.tabPage3.Controls.Add(this.button9);
            this.tabPage3.Controls.Add(this.button8);
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Controls.Add(this.textBox1);
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage3.Location = new System.Drawing.Point(4, 26);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(792, 451);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Select Customer";
            this.toolTip1.SetToolTip(this.tabPage3, "Click on the cell content to select a customer");
            // 
            // button9
            // 
            this.button9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button9.BackColor = System.Drawing.Color.Navy;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button9.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(17, 372);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(164, 39);
            this.button9.TabIndex = 17;
            this.button9.Text = "Previous";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button8.BackColor = System.Drawing.Color.Navy;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button8.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(608, 372);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(164, 39);
            this.button8.TabIndex = 16;
            this.button8.Text = "Next";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(169, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Customer Name";
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox1.Location = new System.Drawing.Point(311, 48);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(266, 23);
            this.textBox1.TabIndex = 1;
            this.toolTip1.SetToolTip(this.textBox1, "WRFG");
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // dataGridView3
            // 
            this.dataGridView3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.customeridDataGridViewTextBoxColumn,
            this.employeeidDataGridViewTextBoxColumn,
            this.customernameDataGridViewTextBoxColumn,
            this.customercellNoDataGridViewTextBoxColumn,
            this.customeremailDataGridViewTextBoxColumn,
            this.customeraddressDataGridViewTextBoxColumn,
            this.studentnumberDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.customertblBS;
            this.dataGridView3.Location = new System.Drawing.Point(17, 109);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowHeadersWidth = 51;
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.dataGridView3.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView3.Size = new System.Drawing.Size(755, 241);
            this.dataGridView3.TabIndex = 0;
            this.toolTip1.SetToolTip(this.dataGridView3, "Click to select a customer");
            this.dataGridView3.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellClick);
            // 
            // customeridDataGridViewTextBoxColumn
            // 
            this.customeridDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.customeridDataGridViewTextBoxColumn.DataPropertyName = "customer_id";
            this.customeridDataGridViewTextBoxColumn.HeaderText = "customer_id";
            this.customeridDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.customeridDataGridViewTextBoxColumn.Name = "customeridDataGridViewTextBoxColumn";
            this.customeridDataGridViewTextBoxColumn.ReadOnly = true;
            this.customeridDataGridViewTextBoxColumn.Width = 112;
            // 
            // employeeidDataGridViewTextBoxColumn
            // 
            this.employeeidDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.employeeidDataGridViewTextBoxColumn.DataPropertyName = "employee_id";
            this.employeeidDataGridViewTextBoxColumn.HeaderText = "employee_id";
            this.employeeidDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeeidDataGridViewTextBoxColumn.Name = "employeeidDataGridViewTextBoxColumn";
            this.employeeidDataGridViewTextBoxColumn.ReadOnly = true;
            this.employeeidDataGridViewTextBoxColumn.Width = 116;
            // 
            // customernameDataGridViewTextBoxColumn
            // 
            this.customernameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.customernameDataGridViewTextBoxColumn.DataPropertyName = "customer_name";
            this.customernameDataGridViewTextBoxColumn.HeaderText = "customer_name";
            this.customernameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.customernameDataGridViewTextBoxColumn.Name = "customernameDataGridViewTextBoxColumn";
            this.customernameDataGridViewTextBoxColumn.ReadOnly = true;
            this.customernameDataGridViewTextBoxColumn.Width = 138;
            // 
            // customercellNoDataGridViewTextBoxColumn
            // 
            this.customercellNoDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.customercellNoDataGridViewTextBoxColumn.DataPropertyName = "customer_cellNo";
            this.customercellNoDataGridViewTextBoxColumn.HeaderText = "customer_cellNo";
            this.customercellNoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.customercellNoDataGridViewTextBoxColumn.Name = "customercellNoDataGridViewTextBoxColumn";
            this.customercellNoDataGridViewTextBoxColumn.ReadOnly = true;
            this.customercellNoDataGridViewTextBoxColumn.Width = 141;
            // 
            // customeremailDataGridViewTextBoxColumn
            // 
            this.customeremailDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.customeremailDataGridViewTextBoxColumn.DataPropertyName = "customer_email";
            this.customeremailDataGridViewTextBoxColumn.HeaderText = "customer_email";
            this.customeremailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.customeremailDataGridViewTextBoxColumn.Name = "customeremailDataGridViewTextBoxColumn";
            this.customeremailDataGridViewTextBoxColumn.ReadOnly = true;
            this.customeremailDataGridViewTextBoxColumn.Width = 136;
            // 
            // customeraddressDataGridViewTextBoxColumn
            // 
            this.customeraddressDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.customeraddressDataGridViewTextBoxColumn.DataPropertyName = "customer_address";
            this.customeraddressDataGridViewTextBoxColumn.HeaderText = "customer_address";
            this.customeraddressDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.customeraddressDataGridViewTextBoxColumn.Name = "customeraddressDataGridViewTextBoxColumn";
            this.customeraddressDataGridViewTextBoxColumn.ReadOnly = true;
            this.customeraddressDataGridViewTextBoxColumn.Width = 149;
            // 
            // studentnumberDataGridViewTextBoxColumn
            // 
            this.studentnumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.studentnumberDataGridViewTextBoxColumn.DataPropertyName = "student_number";
            this.studentnumberDataGridViewTextBoxColumn.HeaderText = "student_number";
            this.studentnumberDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.studentnumberDataGridViewTextBoxColumn.Name = "studentnumberDataGridViewTextBoxColumn";
            this.studentnumberDataGridViewTextBoxColumn.ReadOnly = true;
            this.studentnumberDataGridViewTextBoxColumn.Width = 138;
            // 
            // customertblBS
            // 
            this.customertblBS.DataMember = "Customer_tbl";
            this.customertblBS.DataSource = this.dsG71;
            // 
            // Service
            // 
            this.Service.BackColor = System.Drawing.Color.White;
            this.Service.Controls.Add(this.button11);
            this.Service.Controls.Add(this.button10);
            this.Service.Controls.Add(this.button7);
            this.Service.Controls.Add(this.button4);
            this.Service.Controls.Add(this.dataGridView2);
            this.Service.Controls.Add(this.dataGridView1);
            this.Service.Location = new System.Drawing.Point(4, 26);
            this.Service.Name = "Service";
            this.Service.Padding = new System.Windows.Forms.Padding(3);
            this.Service.Size = new System.Drawing.Size(792, 451);
            this.Service.TabIndex = 0;
            this.Service.Text = "Select Services";
            this.toolTip1.SetToolTip(this.Service, "Click on the cell content to select a service");
            // 
            // button11
            // 
            this.button11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button11.BackColor = System.Drawing.Color.Navy;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button11.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(18, 395);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(164, 39);
            this.button11.TabIndex = 19;
            this.button11.Text = "Previous";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button10.BackColor = System.Drawing.Color.Navy;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button10.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(611, 395);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(164, 39);
            this.button10.TabIndex = 18;
            this.button10.Text = "Next";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button7
            // 
            this.button7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button7.BackColor = System.Drawing.Color.Navy;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button7.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(416, 395);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(164, 39);
            this.button7.TabIndex = 17;
            this.button7.Text = "Remove All ";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button4
            // 
            this.button4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button4.BackColor = System.Drawing.Color.Navy;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(208, 395);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(164, 39);
            this.button4.TabIndex = 16;
            this.button4.Text = "Remove ";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.ColumnHeadersHeight = 29;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serviceidDataGridViewTextBoxColumn1,
            this.servicenameDataGridViewTextBoxColumn1,
            this.servicepriceDataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.serviceTwoBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(38, 226);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidth = 51;
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.dataGridView2.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView2.Size = new System.Drawing.Size(697, 150);
            this.dataGridView2.TabIndex = 1;
            // 
            // serviceidDataGridViewTextBoxColumn1
            // 
            this.serviceidDataGridViewTextBoxColumn1.DataPropertyName = "service_id";
            this.serviceidDataGridViewTextBoxColumn1.HeaderText = "service_id";
            this.serviceidDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.serviceidDataGridViewTextBoxColumn1.Name = "serviceidDataGridViewTextBoxColumn1";
            this.serviceidDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // servicenameDataGridViewTextBoxColumn1
            // 
            this.servicenameDataGridViewTextBoxColumn1.DataPropertyName = "service_name";
            this.servicenameDataGridViewTextBoxColumn1.HeaderText = "service_name";
            this.servicenameDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.servicenameDataGridViewTextBoxColumn1.Name = "servicenameDataGridViewTextBoxColumn1";
            this.servicenameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // servicepriceDataGridViewTextBoxColumn1
            // 
            this.servicepriceDataGridViewTextBoxColumn1.DataPropertyName = "service_price";
            this.servicepriceDataGridViewTextBoxColumn1.HeaderText = "service_price";
            this.servicepriceDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.servicepriceDataGridViewTextBoxColumn1.Name = "servicepriceDataGridViewTextBoxColumn1";
            this.servicepriceDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // serviceTwoBindingSource
            // 
            this.serviceTwoBindingSource.DataMember = "ServiceTwo";
            this.serviceTwoBindingSource.DataSource = this.dsNew;
            // 
            // dsNew
            // 
            this.dsNew.DataSetName = "DataSet1";
            this.dsNew.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serviceidDataGridViewTextBoxColumn,
            this.servicenameDataGridViewTextBoxColumn,
            this.servicepriceDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.serviceBS1;
            this.dataGridView1.Location = new System.Drawing.Point(38, 27);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(697, 193);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // serviceidDataGridViewTextBoxColumn
            // 
            this.serviceidDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.serviceidDataGridViewTextBoxColumn.DataPropertyName = "service_id";
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.serviceidDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle4;
            this.serviceidDataGridViewTextBoxColumn.HeaderText = "service_id";
            this.serviceidDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.serviceidDataGridViewTextBoxColumn.Name = "serviceidDataGridViewTextBoxColumn";
            this.serviceidDataGridViewTextBoxColumn.ReadOnly = true;
            this.serviceidDataGridViewTextBoxColumn.Width = 96;
            // 
            // servicenameDataGridViewTextBoxColumn
            // 
            this.servicenameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.servicenameDataGridViewTextBoxColumn.DataPropertyName = "service_name";
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.servicenameDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle5;
            this.servicenameDataGridViewTextBoxColumn.HeaderText = "service_name";
            this.servicenameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.servicenameDataGridViewTextBoxColumn.Name = "servicenameDataGridViewTextBoxColumn";
            this.servicenameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // servicepriceDataGridViewTextBoxColumn
            // 
            this.servicepriceDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.servicepriceDataGridViewTextBoxColumn.DataPropertyName = "service_price";
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            this.servicepriceDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle6;
            this.servicepriceDataGridViewTextBoxColumn.HeaderText = "service_price";
            this.servicepriceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.servicepriceDataGridViewTextBoxColumn.Name = "servicepriceDataGridViewTextBoxColumn";
            this.servicepriceDataGridViewTextBoxColumn.ReadOnly = true;
            this.servicepriceDataGridViewTextBoxColumn.Width = 116;
            // 
            // serviceBS1
            // 
            this.serviceBS1.DataMember = "Service";
            this.serviceBS1.DataSource = this.dsG71;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.button13);
            this.tabPage1.Controls.Add(this.button12);
            this.tabPage1.Controls.Add(this.gvBAB);
            this.tabPage1.Location = new System.Drawing.Point(4, 26);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(792, 451);
            this.tabPage1.TabIndex = 3;
            this.tabPage1.Text = "Select Barber";
            this.toolTip1.SetToolTip(this.tabPage1, "Click on the cell content to select a barber");
            // 
            // button13
            // 
            this.button13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button13.BackColor = System.Drawing.Color.Navy;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button13.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(8, 393);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(164, 39);
            this.button13.TabIndex = 20;
            this.button13.Text = "Previous";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button12
            // 
            this.button12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button12.BackColor = System.Drawing.Color.Navy;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button12.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(620, 393);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(164, 39);
            this.button12.TabIndex = 19;
            this.button12.Text = "Next";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // gvBAB
            // 
            this.gvBAB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gvBAB.AutoGenerateColumns = false;
            this.gvBAB.BackgroundColor = System.Drawing.Color.White;
            this.gvBAB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvBAB.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.employeeidDataGridViewTextBoxColumn1,
            this.employeenameDataGridViewTextBoxColumn,
            this.employeecellNoDataGridViewTextBoxColumn,
            this.employeeemailDataGridViewTextBoxColumn,
            this.empoyeegenderDataGridViewTextBoxColumn,
            this.employee_position});
            this.gvBAB.DataSource = this.employeetblBS;
            this.gvBAB.Location = new System.Drawing.Point(8, 90);
            this.gvBAB.Name = "gvBAB";
            this.gvBAB.ReadOnly = true;
            this.gvBAB.RowHeadersWidth = 51;
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            this.gvBAB.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.gvBAB.Size = new System.Drawing.Size(776, 239);
            this.gvBAB.TabIndex = 0;
            this.gvBAB.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvBAB_CellClick);
            // 
            // employeeidDataGridViewTextBoxColumn1
            // 
            this.employeeidDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.employeeidDataGridViewTextBoxColumn1.DataPropertyName = "employee_id";
            this.employeeidDataGridViewTextBoxColumn1.HeaderText = "employee_id";
            this.employeeidDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.employeeidDataGridViewTextBoxColumn1.Name = "employeeidDataGridViewTextBoxColumn1";
            this.employeeidDataGridViewTextBoxColumn1.ReadOnly = true;
            this.employeeidDataGridViewTextBoxColumn1.Width = 116;
            // 
            // employeenameDataGridViewTextBoxColumn
            // 
            this.employeenameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.employeenameDataGridViewTextBoxColumn.DataPropertyName = "employee_name";
            this.employeenameDataGridViewTextBoxColumn.HeaderText = "employee_name";
            this.employeenameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeenameDataGridViewTextBoxColumn.Name = "employeenameDataGridViewTextBoxColumn";
            this.employeenameDataGridViewTextBoxColumn.ReadOnly = true;
            this.employeenameDataGridViewTextBoxColumn.Width = 142;
            // 
            // employeecellNoDataGridViewTextBoxColumn
            // 
            this.employeecellNoDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.employeecellNoDataGridViewTextBoxColumn.DataPropertyName = "employee_cellNo";
            this.employeecellNoDataGridViewTextBoxColumn.HeaderText = "employee_cellNo";
            this.employeecellNoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeecellNoDataGridViewTextBoxColumn.Name = "employeecellNoDataGridViewTextBoxColumn";
            this.employeecellNoDataGridViewTextBoxColumn.ReadOnly = true;
            this.employeecellNoDataGridViewTextBoxColumn.Width = 145;
            // 
            // employeeemailDataGridViewTextBoxColumn
            // 
            this.employeeemailDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.employeeemailDataGridViewTextBoxColumn.DataPropertyName = "employee_email";
            this.employeeemailDataGridViewTextBoxColumn.HeaderText = "employee_email";
            this.employeeemailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeeemailDataGridViewTextBoxColumn.Name = "employeeemailDataGridViewTextBoxColumn";
            this.employeeemailDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // empoyeegenderDataGridViewTextBoxColumn
            // 
            this.empoyeegenderDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.empoyeegenderDataGridViewTextBoxColumn.DataPropertyName = "empoyee_gender";
            this.empoyeegenderDataGridViewTextBoxColumn.HeaderText = "empoyee_gender";
            this.empoyeegenderDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.empoyeegenderDataGridViewTextBoxColumn.Name = "empoyeegenderDataGridViewTextBoxColumn";
            this.empoyeegenderDataGridViewTextBoxColumn.ReadOnly = true;
            this.empoyeegenderDataGridViewTextBoxColumn.Width = 147;
            // 
            // employee_position
            // 
            this.employee_position.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.employee_position.DataPropertyName = "employee_position";
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            this.employee_position.DefaultCellStyle = dataGridViewCellStyle7;
            this.employee_position.HeaderText = "employee_position";
            this.employee_position.Name = "employee_position";
            this.employee_position.ReadOnly = true;
            this.employee_position.Width = 155;
            // 
            // employeetblBS
            // 
            this.employeetblBS.DataMember = "Employee_tbl";
            this.employeetblBS.DataSource = this.dsG71;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.button14);
            this.tabPage2.Controls.Add(this.button17);
            this.tabPage2.Controls.Add(this.textBox5);
            this.tabPage2.Controls.Add(this.monthCalendar1);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 451);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Confirm Appointment";
            // 
            // button14
            // 
            this.button14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button14.BackColor = System.Drawing.Color.Navy;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button14.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.Location = new System.Drawing.Point(18, 404);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(164, 39);
            this.button14.TabIndex = 24;
            this.button14.Text = "Previous";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button17
            // 
            this.button17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button17.BackColor = System.Drawing.Color.Navy;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button17.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.ForeColor = System.Drawing.Color.White;
            this.button17.Location = new System.Drawing.Point(605, 404);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(164, 39);
            this.button17.TabIndex = 25;
            this.button17.Text = "Next";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // textBox5
            // 
            this.textBox5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appointmenttblBS, "appointment_id", true));
            this.textBox5.Location = new System.Drawing.Point(497, 217);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(15, 23);
            this.textBox5.TabIndex = 24;
            // 
            // appointmenttblBS
            // 
            this.appointmenttblBS.DataMember = "Appointment_tbl";
            this.appointmenttblBS.DataSource = this.dsG71;
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.monthCalendar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(51)))), ((int)(((byte)(153)))));
            this.monthCalendar1.Location = new System.Drawing.Point(497, 42);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 23;
            this.monthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(this.StudentNoTB);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.bookAppointmentBTB);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.physicalAddressTB);
            this.groupBox2.Controls.Add(this.priceTB);
            this.groupBox2.Controls.Add(this.priceLabel);
            this.groupBox2.Controls.Add(this.acnameTB);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.BarberLB);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.atimeCB);
            this.groupBox2.Controls.Add(this.aemailAddressTB);
            this.groupBox2.Controls.Add(this.acustcellNumberTB);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Black;
            this.groupBox2.Location = new System.Drawing.Point(34, 34);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(451, 365);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Customer Details";
            // 
            // StudentNoTB
            // 
            this.StudentNoTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.StudentNoTB.Location = new System.Drawing.Point(225, 178);
            this.StudentNoTB.Name = "StudentNoTB";
            this.StudentNoTB.Size = new System.Drawing.Size(201, 26);
            this.StudentNoTB.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(30, 178);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 20);
            this.label3.TabIndex = 22;
            this.label3.Text = "Student No";
            // 
            // bookAppointmentBTB
            // 
            this.bookAppointmentBTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.bookAppointmentBTB.Location = new System.Drawing.Point(225, 246);
            this.bookAppointmentBTB.Name = "bookAppointmentBTB";
            this.bookAppointmentBTB.Size = new System.Drawing.Size(201, 26);
            this.bookAppointmentBTB.TabIndex = 21;
            this.bookAppointmentBTB.TextChanged += new System.EventHandler(this.bookAppointmentBTB_TextChanged);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(30, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 20);
            this.label2.TabIndex = 20;
            this.label2.Text = "Physical Address";
            // 
            // physicalAddressTB
            // 
            this.physicalAddressTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.physicalAddressTB.Location = new System.Drawing.Point(225, 144);
            this.physicalAddressTB.Name = "physicalAddressTB";
            this.physicalAddressTB.Size = new System.Drawing.Size(201, 26);
            this.physicalAddressTB.TabIndex = 19;
            // 
            // priceTB
            // 
            this.priceTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.priceTB.Location = new System.Drawing.Point(225, 283);
            this.priceTB.Name = "priceTB";
            this.priceTB.Size = new System.Drawing.Size(201, 26);
            this.priceTB.TabIndex = 18;
            this.priceTB.TextChanged += new System.EventHandler(this.priceTB_TextChanged);
            // 
            // priceLabel
            // 
            this.priceLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.priceLabel.AutoSize = true;
            this.priceLabel.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.priceLabel.ForeColor = System.Drawing.Color.Black;
            this.priceLabel.Location = new System.Drawing.Point(30, 281);
            this.priceLabel.Name = "priceLabel";
            this.priceLabel.Size = new System.Drawing.Size(46, 20);
            this.priceLabel.TabIndex = 18;
            this.priceLabel.Text = "Price";
            // 
            // acnameTB
            // 
            this.acnameTB.Location = new System.Drawing.Point(225, 37);
            this.acnameTB.Name = "acnameTB";
            this.acnameTB.Size = new System.Drawing.Size(201, 26);
            this.acnameTB.TabIndex = 1;
            this.acnameTB.TextChanged += new System.EventHandler(this.acnameTB_TextChanged);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.Navy;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(351, 320);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 39);
            this.button1.TabIndex = 15;
            this.button1.Text = "Confirm";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // BarberLB
            // 
            this.BarberLB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BarberLB.AutoSize = true;
            this.BarberLB.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BarberLB.ForeColor = System.Drawing.Color.Black;
            this.BarberLB.Location = new System.Drawing.Point(30, 245);
            this.BarberLB.Name = "BarberLB";
            this.BarberLB.Size = new System.Drawing.Size(58, 20);
            this.BarberLB.TabIndex = 16;
            this.BarberLB.Text = "Barber";
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.BackColor = System.Drawing.Color.Navy;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(225, 320);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 39);
            this.button2.TabIndex = 14;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // atimeCB
            // 
            this.atimeCB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.atimeCB.DataSource = this.availableTimeBindingSource1;
            this.atimeCB.DisplayMember = "TimeSlot";
            this.atimeCB.FormattingEnabled = true;
            this.atimeCB.Location = new System.Drawing.Point(225, 212);
            this.atimeCB.Name = "atimeCB";
            this.atimeCB.Size = new System.Drawing.Size(201, 28);
            this.atimeCB.TabIndex = 13;
            this.atimeCB.ValueMember = "TimeSlot";
            this.atimeCB.SelectedIndexChanged += new System.EventHandler(this.atimeCB_SelectedIndexChanged);
            this.atimeCB.TextChanged += new System.EventHandler(this.atimeCB_TextChanged);
            // 
            // availableTimeBindingSource1
            // 
            this.availableTimeBindingSource1.DataMember = "AvailableTime";
            this.availableTimeBindingSource1.DataSource = this.dsAppointment1;
            // 
            // dsAppointment1
            // 
            this.dsAppointment1.DataSetName = "dsAppointment";
            this.dsAppointment1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // aemailAddressTB
            // 
            this.aemailAddressTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.aemailAddressTB.Location = new System.Drawing.Point(225, 109);
            this.aemailAddressTB.Name = "aemailAddressTB";
            this.aemailAddressTB.Size = new System.Drawing.Size(201, 26);
            this.aemailAddressTB.TabIndex = 11;
            // 
            // acustcellNumberTB
            // 
            this.acustcellNumberTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.acustcellNumberTB.Location = new System.Drawing.Point(225, 73);
            this.acustcellNumberTB.Name = "acustcellNumberTB";
            this.acustcellNumberTB.Size = new System.Drawing.Size(201, 26);
            this.acustcellNumberTB.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(30, 212);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 20);
            this.label8.TabIndex = 8;
            this.label8.Text = "Time";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(30, 109);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(108, 20);
            this.label11.TabIndex = 5;
            this.label11.Text = "Email Address";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(30, 73);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(147, 20);
            this.label12.TabIndex = 4;
            this.label12.Text = "Cellphone Number";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(30, 37);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 20);
            this.label14.TabIndex = 0;
            this.label14.Text = "Name";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.White;
            this.tabPage5.Controls.Add(this.button15);
            this.tabPage5.Controls.Add(this.button3);
            this.tabPage5.Controls.Add(this.PrintBtn);
            this.tabPage5.Controls.Add(this.GenerateBtn);
            this.tabPage5.Controls.Add(this.txtRRB);
            this.tabPage5.Location = new System.Drawing.Point(4, 26);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(792, 451);
            this.tabPage5.TabIndex = 5;
            this.tabPage5.Text = "Generate Invoice";
            // 
            // button15
            // 
            this.button15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button15.BackColor = System.Drawing.Color.Navy;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button15.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.Color.White;
            this.button15.Location = new System.Drawing.Point(17, 401);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(164, 39);
            this.button15.TabIndex = 19;
            this.button15.Text = "Previous";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button3
            // 
            this.button3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button3.BackColor = System.Drawing.Color.Navy;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(198, 402);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(164, 39);
            this.button3.TabIndex = 17;
            this.button3.Text = "Clear";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // PrintBtn
            // 
            this.PrintBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PrintBtn.BackColor = System.Drawing.Color.Navy;
            this.PrintBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.PrintBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintBtn.ForeColor = System.Drawing.Color.White;
            this.PrintBtn.Location = new System.Drawing.Point(599, 402);
            this.PrintBtn.Name = "PrintBtn";
            this.PrintBtn.Size = new System.Drawing.Size(164, 39);
            this.PrintBtn.TabIndex = 16;
            this.PrintBtn.Text = "Print";
            this.PrintBtn.UseVisualStyleBackColor = false;
            this.PrintBtn.Click += new System.EventHandler(this.PrintBtn_Click);
            // 
            // GenerateBtn
            // 
            this.GenerateBtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.GenerateBtn.BackColor = System.Drawing.Color.Navy;
            this.GenerateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.GenerateBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenerateBtn.ForeColor = System.Drawing.Color.White;
            this.GenerateBtn.Location = new System.Drawing.Point(393, 402);
            this.GenerateBtn.Name = "GenerateBtn";
            this.GenerateBtn.Size = new System.Drawing.Size(164, 39);
            this.GenerateBtn.TabIndex = 15;
            this.GenerateBtn.Text = "Generate";
            this.GenerateBtn.UseVisualStyleBackColor = false;
            this.GenerateBtn.Click += new System.EventHandler(this.GenerateBtn_Click);
            // 
            // txtRRB
            // 
            this.txtRRB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtRRB.Location = new System.Drawing.Point(133, 49);
            this.txtRRB.Name = "txtRRB";
            this.txtRRB.Size = new System.Drawing.Size(517, 338);
            this.txtRRB.TabIndex = 0;
            this.txtRRB.Text = "";
            this.txtRRB.TextChanged += new System.EventHandler(this.txtRRB_TextChanged);
            // 
            // custBS
            // 
            this.custBS.DataMember = "Customer_tbl";
            this.custBS.DataSource = this.dsG72;
            // 
            // dsG72
            // 
            this.dsG72.DataSetName = "dsG7";
            this.dsG72.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // barBS
            // 
            this.barBS.DataMember = "Employee_tbl";
            this.barBS.DataSource = this.dsG72;
            // 
            // timesBS
            // 
            this.timesBS.DataMember = "Times";
            this.timesBS.DataSource = this.dsAppointment1;
            // 
            // timesBindingSource3
            // 
            this.timesBindingSource3.DataMember = "Times";
            this.timesBindingSource3.DataSource = this.dsAppointment1;
            // 
            // taServiceTwo
            // 
            this.taServiceTwo.ClearBeforeFill = true;
            // 
            // taService1
            // 
            this.taService1.ClearBeforeFill = true;
            // 
            // taEmployee1
            // 
            this.taEmployee1.ClearBeforeFill = true;
            // 
            // taCustomer
            // 
            this.taCustomer.ClearBeforeFill = true;
            // 
            // timesBindingSource1
            // 
            this.timesBindingSource1.DataMember = "Times";
            this.timesBindingSource1.DataSource = this.dsAppointment1;
            // 
            // timesBindingSource
            // 
            this.timesBindingSource.DataMember = "Times";
            this.timesBindingSource.DataSource = this.dsAppointment1;
            // 
            // timesBindingSource2
            // 
            this.timesBindingSource2.DataMember = "Times";
            this.timesBindingSource2.DataSource = this.dsAppointment1;
            // 
            // dsAppointment
            // 
            this.dsAppointment.DataSetName = "dsAppointment";
            this.dsAppointment.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // timesTableAdapter
            // 
            this.timesTableAdapter.ClearBeforeFill = true;
            // 
            // previousAppointmentTableAdapter1
            // 
            this.previousAppointmentTableAdapter1.ClearBeforeFill = true;
            // 
            // availableTimeTableAdapter1
            // 
            this.availableTimeTableAdapter1.ClearBeforeFill = true;
            // 
            // appointment_tblTableAdapter1
            // 
            this.appointment_tblTableAdapter1.ClearBeforeFill = true;
            // 
            // dsAppointment1BindingSource
            // 
            this.dsAppointment1BindingSource.DataSource = this.dsAppointment1;
            this.dsAppointment1BindingSource.Position = 0;
            // 
            // availableTimeBindingSource
            // 
            this.availableTimeBindingSource.DataMember = "AvailableTime";
            this.availableTimeBindingSource.DataSource = this.dsAppointment1;
            // 
            // taAvailable
            // 
            this.taAvailable.ClearBeforeFill = true;
            // 
            // taNewApointment
            // 
            this.taNewApointment.ClearBeforeFill = true;
            // 
            // dsAppointment2
            // 
            this.dsAppointment2.DataSetName = "dsAppointment";
            this.dsAppointment2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // taTimes1
            // 
            this.taTimes1.ClearBeforeFill = true;
            // 
            // customertblBindingSource
            // 
            this.customertblBindingSource.DataMember = "Customer_tbl";
            this.customertblBindingSource.DataSource = this.dsG71;
            // 
            // taCustomer33
            // 
            this.taCustomer33.ClearBeforeFill = true;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // taAppointment_tbl
            // 
            this.taAppointment_tbl.ClearBeforeFill = true;
            // 
            // taService_Appointment
            // 
            this.taService_Appointment.ClearBeforeFill = true;
            // 
            // BookAppointmentUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 481);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BookAppointmentUI";
            this.Text = "BookAppointmentUI";
            this.Load += new System.EventHandler(this.BookAppointmentUI_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeetblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG71)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customertblBS)).EndInit();
            this.Service.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceTwoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsNew)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceBS1)).EndInit();
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gvBAB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeetblBS)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.appointmenttblBS)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.availableTimeBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAppointment1)).EndInit();
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.custBS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barBS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.timesBS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.timesBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.timesBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.timesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.timesBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAppointment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAppointment1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.availableTimeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsAppointment2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customertblBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private dsG7 dsG71;
        private System.Windows.Forms.BindingSource serviceBS1;
        private dsG7TableAdapters.ServiceTableAdapter taService1;
        private System.Windows.Forms.BindingSource employeetblBS;
        private dsG7TableAdapters.Employee_tblTableAdapter taEmployee1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Service;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox acnameTB;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label BarberLB;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox atimeCB;
        private System.Windows.Forms.TextBox aemailAddressTB;
        private System.Windows.Forms.TextBox acustcellNumberTB;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicenameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicepriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox priceTB;
        private System.Windows.Forms.Label priceLabel;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.BindingSource customertblBS;
        private dsG7TableAdapters.Customer_tblTableAdapter taCustomer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox physicalAddressTB;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView gvBAB;
        private System.Windows.Forms.TextBox bookAppointmentBTB;
        private dsG7 dsG72;
        private System.Windows.Forms.BindingSource custBS;
        private System.Windows.Forms.BindingSource barBS;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceidDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicenameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicepriceDataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource serviceTwoBindingSource;
        private DataSet1 dsNew;
        private DataSet1TableAdapters.ServiceTwoTableAdapter taServiceTwo;
        private dsAppointment dsAppointment;
        private System.Windows.Forms.BindingSource timesBindingSource2;
        private dsAppointmentTableAdapters.TimesTableAdapter timesTableAdapter;
        private dsAppointmentTableAdapters.PreviousAppointmentTableAdapter previousAppointmentTableAdapter1;
        private dsAppointmentTableAdapters.AvailableTimeTableAdapter availableTimeTableAdapter1;
        private dsAppointmentTableAdapters.Appointment_tblTableAdapter appointment_tblTableAdapter1;
        private System.Windows.Forms.BindingSource dsAppointment1BindingSource;
        private System.Windows.Forms.BindingSource availableTimeBindingSource;
        private System.Windows.Forms.BindingSource timesBindingSource;
        private System.Windows.Forms.BindingSource timesBindingSource1;
        private System.Windows.Forms.BindingSource availableTimeBindingSource1;
        private dsG7TableAdapters.Appointment_tblTableAdapter taNewApointment;
        private dsAppointment dsAppointment2;
        private System.Windows.Forms.BindingSource appointmentBindingSource;
       // private dsAppointmentTableAdapters.AppointmentTableAdapter appointmentTableAdapter;
        /*private System.Windows.Forms.DataGridViewTextBoxColumn appointmentidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customeridDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeidDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn appointmentdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentmethodDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentamountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn appointmenttimeIDDataGridViewTextBoxColumn;*/
        private System.Windows.Forms.BindingSource timesBindingSource3;
        private System.Windows.Forms.BindingSource timesBS;
        private dsAppointmentTableAdapters.TimesTableAdapter taTimes1;
        private System.Windows.Forms.TextBox StudentNoTB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.BindingSource customertblBindingSource;
        private dsG7TableAdapters.Customer_tblTableAdapter taCustomer33;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.RichTextBox txtRRB;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Button PrintBtn;
        private System.Windows.Forms.Button GenerateBtn;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.BindingSource appointmenttblBS;
        private dsG7TableAdapters.Appointment_tblTableAdapter taAppointment_tbl;
        private dsG7TableAdapters.Service_AppointmentTableAdapter taService_Appointment;
        public dsAppointmentTableAdapters.AvailableTimeTableAdapter taAvailable;
        public dsAppointment dsAppointment1;
        public System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.DataGridViewTextBoxColumn customeridDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customercellNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customeremailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customeraddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentnumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeidDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeenameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource employeetblBindingSource;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeidDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeenameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeecellNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeemailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empoyeegenderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employee_position;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
    }
}