﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StyleCutsBarberShopSystem
{
    public partial class ViewBarberUI : Form
    {
        public ViewBarberUI()
        {
            InitializeComponent();
        }

        private void vBarberFirstBtn_Click(object sender, EventArgs e)
        {
            viewBarberBS.MoveFirst();
        }

        private void vBarberNextBtn_Click(object sender, EventArgs e)
        {
            viewBarberBS.MoveNext();
        }

        private void vBarberPreviousTB_Click(object sender, EventArgs e)
        {
            viewBarberBS.MovePrevious();
        }

        private void vBarberLastTB_Click(object sender, EventArgs e)
        {
            viewBarberBS.MoveLast();
        }

        private void vBarberSubmit_Click(object sender, EventArgs e)
        {
        }

        private void gvBarbersSearchTB_TextChanged(object sender, EventArgs e)
        {
            taViewBarber1.FillByEmployeeName(dsViewBarber.Employee_tbl, gvBarbersSearchTB.Text);
        }

        private void vBarberUpdateBtn_Click(object sender, EventArgs e)
        {
            DialogResult confirmation;
            confirmation = MessageBox.Show("Are you sure you want to update?", "Confirm", MessageBoxButtons.YesNo);
            if (confirmation == DialogResult.Yes)
            {
                viewBarberBS.EndEdit();  
                taViewBarber1.Update(dsViewBarber);
                MessageBox.Show("Update successful");
            }
            else
            {
                MessageBox.Show("Update cancelled");
                taViewBarber1.Fill(dsViewBarber.Employee_tbl);
            }
        }

        
        private void ViewBarberUI_Load(object sender, EventArgs e)
        {
            try
            {
                taViewBarber1.Fill(dsViewBarber.Employee_tbl);
                textBox3.Visible = false;
                
               
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading appointments: {ex.Message}");
            }
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {    
           
            DialogResult confirmation;
            confirmation = MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo);
            if (confirmation == DialogResult.Yes)
            {
                taViewBarber1.UpdateStatus("inactive", Convert.ToInt32(gvBarbers.CurrentRow.Cells[0].Value));
                taViewBarber1.Fill(dsViewBarber.Employee_tbl);
                MessageBox.Show("Deletion successful");
            }
            else
            {
                MessageBox.Show("Deletion cancelled");
                
            }

        }

        private void gvBarbers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
            {
                tabControl1.SelectedIndex += 1;
            }
        }
    }
}
