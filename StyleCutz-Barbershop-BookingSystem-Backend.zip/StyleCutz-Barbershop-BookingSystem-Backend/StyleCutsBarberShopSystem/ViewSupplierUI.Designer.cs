﻿
namespace StyleCutsBarberShopSystem
{
    partial class ViewSupplierUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.supplieridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.suppliernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.suppliercellNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplieremailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplieraddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplierBS = new System.Windows.Forms.BindingSource(this.components);
            this.dsG7 = new StyleCutsBarberShopSystem.dsG7();
            this.gvSuppliersSearchTB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Options = new System.Windows.Forms.GroupBox();
            this.deleteBtn = new System.Windows.Forms.Button();
            this.vSupplierUpdateBtn = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.vSupplierFistBtn = new System.Windows.Forms.Button();
            this.vSupplierNextBtn = new System.Windows.Forms.Button();
            this.vSupplierPreviousBtn = new System.Windows.Forms.Button();
            this.vSupplierLastBtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.vSupplierEmailTB = new System.Windows.Forms.TextBox();
            this.vSupplierCellTB = new System.Windows.Forms.TextBox();
            this.vSupplierNameTB = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.suppliertblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.taSupplier = new StyleCutsBarberShopSystem.dsG7TableAdapters.Supplier_tblTableAdapter();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.taInventory = new StyleCutsBarberShopSystem.dsG7TableAdapters.Inventory_tblTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG7)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.Options.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.suppliertblBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(832, 450);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.gvSuppliersSearchTB);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(824, 424);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "View Supplier Details";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.supplieridDataGridViewTextBoxColumn,
            this.suppliernameDataGridViewTextBoxColumn,
            this.suppliercellNoDataGridViewTextBoxColumn,
            this.supplieremailDataGridViewTextBoxColumn,
            this.supplieraddressDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.supplierBS;
            this.dataGridView1.Location = new System.Drawing.Point(20, 84);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(783, 296);
            this.dataGridView1.TabIndex = 58;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseClick);
            // 
            // supplieridDataGridViewTextBoxColumn
            // 
            this.supplieridDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.supplieridDataGridViewTextBoxColumn.DataPropertyName = "supplier_id";
            this.supplieridDataGridViewTextBoxColumn.HeaderText = "supplier_id";
            this.supplieridDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.supplieridDataGridViewTextBoxColumn.Name = "supplieridDataGridViewTextBoxColumn";
            this.supplieridDataGridViewTextBoxColumn.ReadOnly = true;
            this.supplieridDataGridViewTextBoxColumn.Width = 82;
            // 
            // suppliernameDataGridViewTextBoxColumn
            // 
            this.suppliernameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.suppliernameDataGridViewTextBoxColumn.DataPropertyName = "supplier_name";
            this.suppliernameDataGridViewTextBoxColumn.HeaderText = "supplier_name";
            this.suppliernameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.suppliernameDataGridViewTextBoxColumn.Name = "suppliernameDataGridViewTextBoxColumn";
            this.suppliernameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // suppliercellNoDataGridViewTextBoxColumn
            // 
            this.suppliercellNoDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.suppliercellNoDataGridViewTextBoxColumn.DataPropertyName = "supplier_cellNo";
            this.suppliercellNoDataGridViewTextBoxColumn.HeaderText = "supplier_cellNo";
            this.suppliercellNoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.suppliercellNoDataGridViewTextBoxColumn.Name = "suppliercellNoDataGridViewTextBoxColumn";
            this.suppliercellNoDataGridViewTextBoxColumn.ReadOnly = true;
            this.suppliercellNoDataGridViewTextBoxColumn.Width = 104;
            // 
            // supplieremailDataGridViewTextBoxColumn
            // 
            this.supplieremailDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.supplieremailDataGridViewTextBoxColumn.DataPropertyName = "supplier_email";
            this.supplieremailDataGridViewTextBoxColumn.HeaderText = "supplier_email";
            this.supplieremailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.supplieremailDataGridViewTextBoxColumn.Name = "supplieremailDataGridViewTextBoxColumn";
            this.supplieremailDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // supplieraddressDataGridViewTextBoxColumn
            // 
            this.supplieraddressDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.supplieraddressDataGridViewTextBoxColumn.DataPropertyName = "supplier_address";
            this.supplieraddressDataGridViewTextBoxColumn.HeaderText = "supplier_address";
            this.supplieraddressDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.supplieraddressDataGridViewTextBoxColumn.Name = "supplieraddressDataGridViewTextBoxColumn";
            this.supplieraddressDataGridViewTextBoxColumn.ReadOnly = true;
            this.supplieraddressDataGridViewTextBoxColumn.Width = 111;
            // 
            // supplierBS
            // 
            this.supplierBS.DataMember = "Supplier_tbl";
            this.supplierBS.DataSource = this.dsG7;
            // 
            // dsG7
            // 
            this.dsG7.DataSetName = "dsG7";
            this.dsG7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gvSuppliersSearchTB
            // 
            this.gvSuppliersSearchTB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gvSuppliersSearchTB.ForeColor = System.Drawing.Color.Black;
            this.gvSuppliersSearchTB.Location = new System.Drawing.Point(353, 39);
            this.gvSuppliersSearchTB.Name = "gvSuppliersSearchTB";
            this.gvSuppliersSearchTB.Size = new System.Drawing.Size(178, 20);
            this.gvSuppliersSearchTB.TabIndex = 55;
            this.gvSuppliersSearchTB.TextChanged += new System.EventHandler(this.gvSuppliersSearchTB_TextChanged);
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(220, 39);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 20);
            this.label6.TabIndex = 54;
            this.label6.Text = "Supplier Name:";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.Options);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(824, 424);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Modify Supplier Details";
            // 
            // Options
            // 
            this.Options.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Options.Controls.Add(this.deleteBtn);
            this.Options.Controls.Add(this.vSupplierUpdateBtn);
            this.Options.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Options.ForeColor = System.Drawing.Color.Black;
            this.Options.Location = new System.Drawing.Point(206, 290);
            this.Options.Name = "Options";
            this.Options.Size = new System.Drawing.Size(423, 82);
            this.Options.TabIndex = 33;
            this.Options.TabStop = false;
            this.Options.Text = "Options";
            // 
            // deleteBtn
            // 
            this.deleteBtn.BackColor = System.Drawing.Color.Navy;
            this.deleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.deleteBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteBtn.ForeColor = System.Drawing.Color.White;
            this.deleteBtn.Location = new System.Drawing.Point(18, 25);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(186, 37);
            this.deleteBtn.TabIndex = 16;
            this.deleteBtn.Text = "Delete";
            this.deleteBtn.UseVisualStyleBackColor = false;
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // vSupplierUpdateBtn
            // 
            this.vSupplierUpdateBtn.BackColor = System.Drawing.Color.Navy;
            this.vSupplierUpdateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vSupplierUpdateBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vSupplierUpdateBtn.ForeColor = System.Drawing.Color.White;
            this.vSupplierUpdateBtn.Location = new System.Drawing.Point(219, 25);
            this.vSupplierUpdateBtn.Name = "vSupplierUpdateBtn";
            this.vSupplierUpdateBtn.Size = new System.Drawing.Size(186, 37);
            this.vSupplierUpdateBtn.TabIndex = 15;
            this.vSupplierUpdateBtn.Text = "Update";
            this.vSupplierUpdateBtn.UseVisualStyleBackColor = false;
            this.vSupplierUpdateBtn.Click += new System.EventHandler(this.vSupplierUpdateBtn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(this.vSupplierFistBtn);
            this.groupBox2.Controls.Add(this.vSupplierNextBtn);
            this.groupBox2.Controls.Add(this.vSupplierPreviousBtn);
            this.groupBox2.Controls.Add(this.vSupplierLastBtn);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Black;
            this.groupBox2.Location = new System.Drawing.Point(206, 206);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(423, 78);
            this.groupBox2.TabIndex = 32;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Navigation";
            // 
            // vSupplierFistBtn
            // 
            this.vSupplierFistBtn.BackColor = System.Drawing.Color.Navy;
            this.vSupplierFistBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vSupplierFistBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vSupplierFistBtn.ForeColor = System.Drawing.Color.White;
            this.vSupplierFistBtn.Location = new System.Drawing.Point(15, 25);
            this.vSupplierFistBtn.Name = "vSupplierFistBtn";
            this.vSupplierFistBtn.Size = new System.Drawing.Size(87, 37);
            this.vSupplierFistBtn.TabIndex = 13;
            this.vSupplierFistBtn.Text = "First";
            this.vSupplierFistBtn.UseVisualStyleBackColor = false;
            this.vSupplierFistBtn.Click += new System.EventHandler(this.vSupplierFistBtn_Click);
            // 
            // vSupplierNextBtn
            // 
            this.vSupplierNextBtn.BackColor = System.Drawing.Color.Navy;
            this.vSupplierNextBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vSupplierNextBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vSupplierNextBtn.ForeColor = System.Drawing.Color.White;
            this.vSupplierNextBtn.Location = new System.Drawing.Point(117, 25);
            this.vSupplierNextBtn.Name = "vSupplierNextBtn";
            this.vSupplierNextBtn.Size = new System.Drawing.Size(87, 37);
            this.vSupplierNextBtn.TabIndex = 12;
            this.vSupplierNextBtn.Text = "Next";
            this.vSupplierNextBtn.UseVisualStyleBackColor = false;
            this.vSupplierNextBtn.Click += new System.EventHandler(this.vSupplierNextBtn_Click);
            // 
            // vSupplierPreviousBtn
            // 
            this.vSupplierPreviousBtn.BackColor = System.Drawing.Color.Navy;
            this.vSupplierPreviousBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vSupplierPreviousBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vSupplierPreviousBtn.ForeColor = System.Drawing.Color.White;
            this.vSupplierPreviousBtn.Location = new System.Drawing.Point(219, 25);
            this.vSupplierPreviousBtn.Name = "vSupplierPreviousBtn";
            this.vSupplierPreviousBtn.Size = new System.Drawing.Size(87, 37);
            this.vSupplierPreviousBtn.TabIndex = 11;
            this.vSupplierPreviousBtn.Text = "Previous";
            this.vSupplierPreviousBtn.UseVisualStyleBackColor = false;
            this.vSupplierPreviousBtn.Click += new System.EventHandler(this.vSupplierPreviousBtn_Click);
            // 
            // vSupplierLastBtn
            // 
            this.vSupplierLastBtn.BackColor = System.Drawing.Color.Navy;
            this.vSupplierLastBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vSupplierLastBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vSupplierLastBtn.ForeColor = System.Drawing.Color.White;
            this.vSupplierLastBtn.Location = new System.Drawing.Point(318, 25);
            this.vSupplierLastBtn.Name = "vSupplierLastBtn";
            this.vSupplierLastBtn.Size = new System.Drawing.Size(87, 37);
            this.vSupplierLastBtn.TabIndex = 10;
            this.vSupplierLastBtn.Text = "Last";
            this.vSupplierLastBtn.UseVisualStyleBackColor = false;
            this.vSupplierLastBtn.Click += new System.EventHandler(this.vSupplierLastBtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.vSupplierEmailTB);
            this.groupBox1.Controls.Add(this.vSupplierCellTB);
            this.groupBox1.Controls.Add(this.vSupplierNameTB);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(206, 47);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(423, 153);
            this.groupBox1.TabIndex = 31;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Supplier Details";
            // 
            // textBox1
            // 
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.supplierBS, "supplier_address", true));
            this.textBox1.Location = new System.Drawing.Point(171, 111);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(178, 26);
            this.textBox1.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(53, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Address:";
            // 
            // vSupplierEmailTB
            // 
            this.vSupplierEmailTB.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.supplierBS, "supplier_email", true));
            this.vSupplierEmailTB.Location = new System.Drawing.Point(171, 78);
            this.vSupplierEmailTB.Name = "vSupplierEmailTB";
            this.vSupplierEmailTB.Size = new System.Drawing.Size(178, 26);
            this.vSupplierEmailTB.TabIndex = 8;
            // 
            // vSupplierCellTB
            // 
            this.vSupplierCellTB.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.supplierBS, "supplier_cellNo", true));
            this.vSupplierCellTB.Location = new System.Drawing.Point(171, 49);
            this.vSupplierCellTB.Name = "vSupplierCellTB";
            this.vSupplierCellTB.Size = new System.Drawing.Size(178, 26);
            this.vSupplierCellTB.TabIndex = 7;
            // 
            // vSupplierNameTB
            // 
            this.vSupplierNameTB.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.supplierBS, "supplier_name", true));
            this.vSupplierNameTB.Location = new System.Drawing.Point(171, 19);
            this.vSupplierNameTB.Name = "vSupplierNameTB";
            this.vSupplierNameTB.Size = new System.Drawing.Size(178, 26);
            this.vSupplierNameTB.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(53, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Email Address:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(53, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Cellphone:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(53, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Full Name:";
            // 
            // suppliertblBindingSource
            // 
            this.suppliertblBindingSource.DataMember = "Supplier_tbl";
            this.suppliertblBindingSource.DataSource = this.dsG7;
            // 
            // taSupplier
            // 
            this.taSupplier.ClearBeforeFill = true;
            // 
            // taInventory
            // 
            this.taInventory.ClearBeforeFill = true;
            // 
            // ViewSupplierUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(832, 450);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ViewSupplierUI";
            this.Text = "ViewSupplierUI";
            this.Load += new System.EventHandler(this.ViewSupplierUI_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG7)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.Options.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.suppliertblBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox Options;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button vSupplierFistBtn;
        private System.Windows.Forms.Button vSupplierNextBtn;
        private System.Windows.Forms.Button vSupplierPreviousBtn;
        private System.Windows.Forms.Button vSupplierLastBtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox vSupplierEmailTB;
        private System.Windows.Forms.TextBox vSupplierCellTB;
        private System.Windows.Forms.TextBox vSupplierNameTB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox gvSuppliersSearchTB;
        private System.Windows.Forms.Label label6;
        private dsG7 dsG7;
        private System.Windows.Forms.BindingSource suppliertblBindingSource;
        private dsG7TableAdapters.Supplier_tblTableAdapter taSupplier;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource supplierBS;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplieridDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn suppliernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn suppliercellNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplieremailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplieraddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplierproductsDataGridViewTextBoxColumn;
        public System.Windows.Forms.Button vSupplierUpdateBtn;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Button deleteBtn;
        private dsG7TableAdapters.Inventory_tblTableAdapter taInventory;
    }
}