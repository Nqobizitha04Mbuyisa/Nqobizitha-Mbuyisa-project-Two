﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StyleCutsBarberShopSystem
{
    public partial class HomeUI : Form
    {
        
        public HomeUI()
        {
            InitializeComponent();
        }
        
        private void LoadFormIntoPanel(Form form)
        {
            ParentPanel.Controls.Clear();
            form.TopLevel = false;
            ParentPanel.Controls.Add(form);
            form.Dock = DockStyle.Fill;
            form.Show();
        }
        private void HomeUI_Load(object sender, EventArgs e)
        {
            iconButton1.Text = GlobalVariables.username;
            label5.Text = taAppointments.countQ().ToString();
            label7.Text = taEmployee.countEmployees().ToString();
            label6.Text = taService.countS().ToString();
            label1.Text = taAppointments.countCancelledApp().ToString();
            label9.Text = taAppointments.countCompletedAppDayBefore().ToString();
            label11.Text = taAppointments.countCompletedApp().ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadFormIntoPanel(new ViewAppointmentUI());
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LoadFormIntoPanel(new ViewAppointmentUI(3));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoadFormIntoPanel(new ViewBarberUI());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LoadFormIntoPanel(new ViewServicesUI());
        }

        private void button6_Click(object sender, EventArgs e)
        {
            LoadFormIntoPanel(new SalesUI(2,0));
        }

        private void button7_Click(object sender, EventArgs e)
        {
            LoadFormIntoPanel(new SalesUI(2, -1));
        }
    }
}
