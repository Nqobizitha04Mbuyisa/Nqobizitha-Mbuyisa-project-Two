﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using System.Collections;

namespace StyleCutsBarberShopSystem
{
    /*public static class AppointmentData
    {
        public static int CustomerId { get; set; }
        public static int EmployeeId { get; set; }
        public static string AppointmentDate { get; set; }
        public static decimal Price { get; set; }
        public static int TimeSlot { get; set; }
    }*/
    public partial class BookAppointmentUI : Form
    {
        List<string> services = new List<string>();
        List<string> prices = new List<string>();
        int a;
        public BookAppointmentUI()
        {
            InitializeComponent();
        }


        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private void BookAppointmentUI_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dsAppointment2.Appointment' table. You can move, or remove it, as needed.
            // this.appointmentTableAdapter.Fill(this.dsAppointment2.Appointment);
            // TODO: This line of code loads data into the 'dsAppointment1.Times' table. You can move, or remove it, as needed.
            //this.timesTableAdapter.Fill(this.dsAppointment1.Times);

            // TODO: This line of code loads data into the 'dsG71.Customer_tbl' table. You can move, or remove it, as needed.
            this.taCustomer.Fill(this.dsG71.Customer_tbl);
            // TODO: This line of code loads data into the 'dsG71.Employee_tbl' table. You can move, or remove it, as needed.
            this.taEmployee1.FillByBarbers(this.dsG71.Employee_tbl);
            // TODO: This line of code loads data into the 'dsG71.Service' table. You can move, or remove it, as needed.
            this.taService1.Fill(this.dsG71.Service);

            //taAppointment_tbl.Fill(dsG71.Appointment_tbl);
            //appointmenttblBS.MoveLast();

            gvBAB.DataBindingComplete += GvBAB_DataBindingComplete;
            //adateTB.Text = DateTime.Now.ToShortDateString();
            //label3.Text = DateTime.Now.ToString();
            //timesTableAdapter.Fill(dsAppointment.Times);
            //pointment_tblTableAdapter1.Fill(dsAppointment1.Appointment_tbl);
            //timesTableAdapter.Fill(dsAppointment.Times);

            //taAvailable.FillByAvailableTime(dsAppointment1.AvailableTime, DateTime.Today.ToString("yyyy-MM-dd"));
            //essageBox.Show(monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd"));
            //ssageBox.Show(dsAppointment1.PreviousAppointment.Rows.Count.ToString());
            // appointment_tblTableAdapter1.Fill(dsAppointment1.Appointment_tbl);

            taCustomer33.Fill(dsG71.Customer_tbl);
            customertblBindingSource.MoveLast();
            customertblBindingSource.AddNew();

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            taCustomer.FillByCName(dsG71.Customer_tbl, textBox1.Text);
        }
        /*
        private void dataGridView3_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //label3.Text = DateTime.Now.ToString();
                acnameTB.Text = dataGridView3.CurrentRow.Cells[2].Value.ToString();
                acustcellNumberTB.Text = dataGridView3.CurrentRow.Cells[3].Value.ToString();
                aemailAddressTB.Text = dataGridView3.CurrentRow.Cells[4].Value.ToString();
                physicalAddressTB.Text = dataGridView3.CurrentRow.Cells[5].Value.ToString();
                StudentNoTB.Text = dataGridView3.CurrentRow.Cells[6].Value.ToString();

                GlobalVariables.cname = dataGridView3.CurrentRow.Cells[2].Value.ToString();
                GlobalVariables.cCellNo = dataGridView3.CurrentRow.Cells[3].Value.ToString();
                GlobalVariables.cEmailAddress = dataGridView3.CurrentRow.Cells[4].Value.ToString();
                GlobalVariables.cPhycalAddress = dataGridView3.CurrentRow.Cells[5].Value.ToString();
                GlobalVariables.cStudendNo = dataGridView3.CurrentRow.Cells[6].Value.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Multiple clicks detected. Please click only twice.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }*/
        private void GvBAB_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {

        }
        /*
        private void gvBAB_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                bookAppointmentBTB.Text = gvBAB.CurrentRow.Cells[1].Value.ToString();
                GlobalVariables.barber = gvBAB.CurrentRow.Cells[1].Value.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Multiple clicks detected. Please click only twice.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                
            }
        }*/


        private void button1_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(acnameTB.Text) || string.IsNullOrEmpty(acustcellNumberTB.Text) ||string.IsNullOrEmpty(aemailAddressTB.Text) || string.IsNullOrEmpty(physicalAddressTB.Text) ||
           string.IsNullOrEmpty(StudentNoTB.Text) ||string.IsNullOrEmpty(bookAppointmentBTB.Text) ||string.IsNullOrEmpty(priceTB.Text))
            {
                MessageBox.Show("Please fill in all required fields.");
                return;
            }
           
            //timesTableAdapter.FillByTimeSlots(dsAppointment.Times, atimeCB.SelectedValue.ToString());
            //int id = taTimes1.FillByT(dsAppointment1.Times, atimeCB.Text);

            // MessageBox.Show("Message: " +timesTableAdapter.FillByTimeSlots(dsAppointment.Times, atimeCB.SelectedValue.ToString()));
            /* if(monthCalendar1.SelectionRange.Start == DateTime.Today)
             {
                 //MessageBox.Show(atimeCB.Text.Substring(0, 5));
                 String inputDate = atimeCB.Text.Substring(0, 5);//input Time from comboBox

                 DateTime inputTime;
                 DateTime.TryParseExact(inputDate, "HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out inputTime);
                 DateTime now = DateTime.Now;

                 DateTime currentTime = new DateTime(now.Year, now.Month, now.Day, now.Hour, now.Minute, 0);

                 if(inputTime < currentTime)
                 {
                     MessageBox.Show("We cannot accomodate bookings for times that have already passed ");
                 }
                 else
                 {
                     MessageBox.Show("procceed with booking");
                 }
                // MessageBox.Show(DateTime.Now.ToShortTimeString());
             }*/

            if (atimeCB.Text == "19:30-20:00")
            {
                a = 22;
            }
            else if (atimeCB.Text == "09:00-09:30")
            {
                a = 1;
            }
            else if (atimeCB.Text == "09:30-10:00")
            {
                a = 2;
            }
            else if (atimeCB.Text == "10:00-10:30")
            {
                a = 3;
            }
            else if (atimeCB.Text == "10:30-11:00")
            {
                a = 4;
            }
            else if (atimeCB.Text == "11:00-11:30")
            {
                a = 5;
            }
            else if (atimeCB.Text == "11:30-12:00")
            {
                a = 6;
            }
            else if (atimeCB.Text == "12:00-12:30")
            {
                a = 7;
            }
            else if (atimeCB.Text == "12:30-13:00")
            {
                a = 8;
            }
            else if (atimeCB.Text == "13:00-13:30")
            {
                a = 9;
            }
            else if (atimeCB.Text == "13:30-14:00")
            {
                a = 10;
            }
            else if (atimeCB.Text == "14:00-14:30")
            {
                a = 11;
            }
            else if (atimeCB.Text == "14:30-15:00")
            {
                a = 12;
            }
            else if (atimeCB.Text == "15:00-15:30")
            {
                a = 13;
            }
            else if (atimeCB.Text == "15:30-16:00")
            {
                a = 14;
            }
            else if (atimeCB.Text == "16:00-16:30")
            {
                a = 15;
            }
            else if (atimeCB.Text == "16:30-17:00")
            {
                a = 16;
            }
            else if (atimeCB.Text == "17:00-17:30")
            {
                a = 17;
            }
            else if (atimeCB.Text == "17:30-18:00")
            {
                a = 18;
            }
            else if (atimeCB.Text == "18:00-18:30")
            {
                a = 19;
            }
            else if (atimeCB.Text == "18:30-19:00")
            {
                a = 20;
            }
            else if (atimeCB.Text == "19:00-19:30")
            {
                a = 21;
            }

            //a=22;
            //insertquery faka u a in place of timeslot id
            if (monthCalendar1.SelectionRange.Start < DateTime.Today)
            {
                MessageBox.Show("Cannot book prior to today (Select Today's date or future dates)", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            /*
            else if (monthCalendar1.SelectionRange.Start == DateTime.Today)
            {
                //MessageBox.Show(atimeCB.Text.Substring(0, 5));
                String inputDate = atimeCB.Text.Substring(0, 5);//input Time from comboBox

                DateTime inputTime;
                DateTime.TryParseExact(inputDate, "HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out inputTime);
                DateTime now = DateTime.Now;

                DateTime currentTime = new DateTime(now.Year, now.Month, now.Day, now.Hour, now.Minute, 0);

                if (inputTime < currentTime)
                {
                    MessageBox.Show("We cannot accomodate bookings for times that have already passed (Select relevant time slot) ", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    // MessageBox.Show("procceed with booking");
                    DialogResult result = MessageBox.Show("Do you want to confirm the appointment booking?", "Appointment Confirm", MessageBoxButtons.OKCancel);
                    DateTime selectedDate = monthCalendar1.SelectionRange.Start;
                    DateTime now2 = DateTime.Today;
                    if (result == DialogResult.OK)
                    {
                        try
                        {
                            // Use parameterized query with appropriate data types
                            appointment_tblTableAdapter1.InsertQuery(
                                Convert.ToInt32(dataGridView3.CurrentRow.Cells[0].Value),
                                Convert.ToInt32(gvBAB.CurrentRow.Cells[0].Value),
                                selectedDate.ToString("yyyy-MM-dd"),
                                decimal.Parse(priceTB.Text, System.Globalization.NumberStyles.Currency),
                                a, "pending", "pending"


                            );
                            GlobalVariables.time = atimeCB.Text;

                            taAvailable.FillByAvailableTime(dsAppointment1.AvailableTime, monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd"));
                            MessageBox.Show("Appointment has been Confirmed");
                           // /*********************************************************************************************************

                            int Appointment_id = 0;
                            if (textBox5.Text.Length == 0)
                            {
                                Appointment_id = 1;
                            }
                            else if (textBox5.Text.Length > 0)
                            {
                                Appointment_id = Convert.ToInt32(textBox5.Text);
                                Appointment_id += 1;
                            }

                            List<int> service_id = new List<int>();
                            for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
                            {
                                service_id.Add(Convert.ToInt32(dataGridView2.Rows[i].Cells[0].Value));
                            }

                            for (int i = 0; i <= service_id.Count - 1; i++)
                            {
                                taService_Appointment.Insert1(Appointment_id, service_id[i]);
                            }

                            service_id.Clear();

                            /**********************************************************************************************************
                            acnameTB.Clear();
                            acustcellNumberTB.Clear();
                            aemailAddressTB.Clear();
                            physicalAddressTB.Clear();
                            atimeCB.SelectedIndex = -1;
                            bookAppointmentBTB.Clear();
                            priceTB.Clear();
                            StudentNoTB.Clear();
                            textBox5.Clear();
                            atimeCB.Text = "";

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error booking appointment: {ex.Message}");
                        }
                    }
                    try
                    {
                        // Use proper date format string for queries
                        previousAppointmentTableAdapter1.FillByDate(dsAppointment.PreviousAppointment, now2.ToString("yyyy-MM-dd"));
                        availableTimeTableAdapter1.FillByAvailableTime(dsAppointment.AvailableTime, monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd"));
                        //MessageBox.Show("This here gave no errors");
                    }
                    catch (Exception ex)
                    {
                        //MessageBox.Show($"Error loading data: {ex.Message}");
                    }
                }
                // MessageBox.Show(DateTime.Now.ToShortTimeString());
            }*/
            else
            {
                DialogResult result = MessageBox.Show("Do you want to confirm the appointment booking?", "Appointment Confirm", MessageBoxButtons.OKCancel);
                DateTime selectedDate = monthCalendar1.SelectionRange.Start;
                DateTime now = DateTime.Today;
                if (result == DialogResult.OK)
                {


                    try
                    {
                        // Use parameterized query with appropriate data types
                        appointment_tblTableAdapter1.InsertQuery(
                            Convert.ToInt32(dataGridView3.CurrentRow.Cells[0].Value),
                            Convert.ToInt32(gvBAB.CurrentRow.Cells[0].Value),
                            selectedDate.ToString("yyyy-MM-dd"),
                            decimal.Parse(priceTB.Text, System.Globalization.NumberStyles.Currency),
                            a, "pending", "pending"


                        );
                        GlobalVariables.time = atimeCB.Text;

                        taAvailable.FillByAvailableTime(dsAppointment1.AvailableTime, monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd"));
                        MessageBox.Show("Appointment has been Confirmed");
                        fillList();
                        Generate();
                        /**********************************************************************************************************/

                        int Appointment_id = 0;
                        if (textBox5.Text.Length == 0)
                        {
                            Appointment_id = 1;
                        }
                        else if (textBox5.Text.Length > 0)
                        {
                            Appointment_id = Convert.ToInt32(textBox5.Text);
                            Appointment_id += 1;
                        }

                        List<int> service_id = new List<int>();
                        for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
                        {
                            service_id.Add(Convert.ToInt32(dataGridView2.Rows[i].Cells[0].Value));
                        }

                        for (int i = 0; i <= service_id.Count - 1; i++)
                        {
                            taService_Appointment.Insert1(Appointment_id, service_id[i]);
                        }

                        service_id.Clear();

                        /*********************************************************************************************************/
                        acnameTB.Clear();
                        acustcellNumberTB.Clear();
                        aemailAddressTB.Clear();
                        physicalAddressTB.Clear();
                        atimeCB.SelectedIndex = -1;
                        bookAppointmentBTB.Clear();
                        priceTB.Clear();
                        StudentNoTB.Clear();
                        textBox5.Clear();
                        atimeCB.Text = "";
                        dsNew.ServiceTwo.Clear();

                        /*if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
                        {
                            tabControl1.SelectedIndex += 1;
                        }*/


                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error booking appointment: {ex.Message}");
                    }

                }
                try
                {
                    // Use proper date format string for queries
                    previousAppointmentTableAdapter1.FillByDate(dsAppointment.PreviousAppointment, now.ToString("yyyy-MM-dd"));
                    availableTimeTableAdapter1.FillByAvailableTime(dsAppointment.AvailableTime, monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd"));
                    //MessageBox.Show("This here gave no errors");
                }
                catch (Exception ex)
                {
                    //MessageBox.Show($"Error loading data: {ex.Message}");
                }

            }
        }

        private decimal getTotal()
        {
            decimal tot = 0;
            for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
            {
                tot += Convert.ToDecimal(dataGridView2.Rows[i].Cells[2].Value);
            }
            return tot;

        }
        /*
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataRow dr;
                dr = dsNew.ServiceTwo.NewRow();
                for (int i = 0; i < dr.ItemArray.Length; i++)
                {
                    dr[i] = dataGridView1.CurrentRow.Cells[i].Value;
                }
                dsNew.ServiceTwo.Rows.Add(dr);

                if (dataGridView3.CurrentRow.Cells[6].Value.ToString() != "N/A")
                {
                    decimal total = getTotal();
                    decimal discountedTot = total * 0.85m;
                    priceTB.Text = discountedTot.ToString("C2");
                    GlobalVariables.tPrice = discountedTot.ToString("C2");
                }
                else
                {
                    priceTB.Text = getTotal().ToString("C2");
                    GlobalVariables.tPrice = getTotal().ToString("C2");

                }
            }
            catch (Exception ex)
            {
                // Show a message box indicating that the user clicked more than once
                MessageBox.Show("Multiple clicks detected. Please click only once.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }*/


        private void button2_Click(object sender, EventArgs e)
        {
            acnameTB.Clear();
            acustcellNumberTB.Clear();
            aemailAddressTB.Clear();
            physicalAddressTB.Clear();
            atimeCB.SelectedIndex = -1;
            bookAppointmentBTB.Clear();
            priceTB.Clear();
            StudentNoTB.Clear();

            if (dataGridView2.Rows.Count > 0)
            {
                dsNew.ServiceTwo.Clear();
            }

        }

        private void atimeCB_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

            DateTime startDate = monthCalendar1.SelectionRange.Start;


            // Fill the table adapter using the selected date range
            //previousAppointmentTableAdapter1.FillByDate(dsAppointment.PreviousAppointment, startDate.ToString());
            //availableTimeTableAdapter1.FillByAvailableTime(dsAppointment.AvailableTime, startDate.ToString());

            // DateTime startDate = monthCalendar1.SelectionRange.Start;
            //previousAppointmentTableAdapter1.FillByDate(dsAppointment.PreviousAppointment, monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd"));
            DateTime selectedDate = monthCalendar1.SelectionRange.Start;
            //taAvailable.FillByAvailableTime(dsAppointment1.AvailableTime, monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd"));
            int id = 1;

            if (gvBAB.CurrentRow.Cells[1].Value.ToString() == bookAppointmentBTB.Text)
            {
                id = Convert.ToInt32(gvBAB.CurrentRow.Cells[0].Value.ToString());
            }
            taAvailable.FillByLetho(dsAppointment1.AvailableTime, monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd"), id);
            // Get the selected start date from the month calendar
        }


        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime startDate = monthCalendar1.SelectionRange.Start;
            // previousAppointmentTableAdapter1.FillByDate(dsAppointment.PreviousAppointment, startDate.ToString());
            DateTime selectedDate = monthCalendar1.SelectionRange.Start;
            taAvailable.FillByAvailableTime(dsAppointment1.AvailableTime, "2024-06-11");
        }

        private void atimeCB_TextChanged(object sender, EventArgs e)
        {
            //taTimes1.FillByTimeSlots(dsAppointment1.Times, atimeCB.Text);
            //  id = gvTimes.Rows[0].Cells[0].Value.ToString();
        }
        private void button6_Click_1(object sender, EventArgs e)
        {
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox8.Clear();
            textBox7.Clear();
            textBox6.Clear();
            textBox9.Clear();

        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = "N/A";
            }
            try
            {
                taCustomer.InsertCustomer(Convert.ToInt32(textBox3.Text), textBox6.Text, textBox8.Text, textBox7.Text, textBox4.Text, textBox2.Text);
                taCustomer.Fill(this.dsG71.Customer_tbl);
                MessageBox.Show("New customer added successfully");
            }
            catch
            {
                MessageBox.Show("Enter valid details", "Invalid details", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }


            /*if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
            {
                tabControl1.SelectedIndex += 1;
            }*/


            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox8.Clear();
            textBox7.Clear();
            textBox6.Clear();
            textBox9.Clear();

        }

        private void GenerateBtn_Click(object sender, EventArgs e)
        {
            txtRRB.Clear();
            txtRRB.Text += "*******************************************************\n";
            txtRRB.Text += "*                 StyleCuts BarberShop                *\n";
            txtRRB.Text += "*******************************************************\n";
            txtRRB.Text += "Date: " + DateTime.Now + "\n\n";
            txtRRB.Text += "Customer Name: " + GlobalVariables.cname + "\n\n";
            txtRRB.Text += "Barber: " + GlobalVariables.barber + "\n\n";
            txtRRB.Text += "Appointment Date: " + monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd") + "\n\n";
            txtRRB.Text += "Time Slot: " + GlobalVariables.time + "\n\n";
            txtRRB.Text += "Service Name: ";
            for (int i = 0; i < services.Count; i++)
            {
                if (i == 0)
                {
                    txtRRB.Text += services[i] + "  R" + prices[i] + "\n\n";
                }
                else
                {
                    txtRRB.Text += "                      " + services[i] + "  R" + prices[i] + "\n\n";
                }

            }
            if (dataGridView3.CurrentRow.Cells[6].Value.ToString() != "N/A")
            {
                txtRRB.Text += "Student Number: " + GlobalVariables.cStudendNo + "\n\n";
                txtRRB.Text += "Student Discount Rate: " + "15%" + "\n\n";
                txtRRB.Text += "Total Price: " + getTotal().ToString("C2") + "\n\n";
                txtRRB.Text += "Discounted Total: " + GlobalVariables.tPrice + "\n\n";

            }
            else
            {
                txtRRB.Text += "Total Price: " + GlobalVariables.tPrice + "\n\n";
            }


            txtRRB.Text += "*******************************************************\n";
            txtRRB.Text += "Thank You for choosing SyleCuts Barber Shop\n";
            txtRRB.Text += "*******************************************************\n";
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(txtRRB.Text, new Font("Microsoft Sans Serif", 18, FontStyle.Bold), Brushes.Black, new Point(10, 10));
        }

        private void PrintBtn_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtRRB.Clear();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show("Double click to select a customer");
        }

        private void tabControl1_Selected(object sender, TabControlEventArgs e)
        {
            //MessageBox.Show("Double click to select a customer");
        }

        private void bookAppointmentBTB_TextChanged(object sender, EventArgs e)
        {
            int id = 1;

            if (gvBAB.CurrentRow.Cells[1].Value.ToString() == bookAppointmentBTB.Text)
            {
                id = Convert.ToInt32(gvBAB.CurrentRow.Cells[0].Value.ToString());
            }
            taAvailable.FillByLetho(dsAppointment1.AvailableTime, monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd"), id);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            dsNew.ServiceTwo.Clear();
            priceTB.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {

            decimal value = Convert.ToDecimal(dataGridView2.CurrentRow.Cells[2].Value);
            decimal price = Convert.ToDecimal(priceTB.Text.Substring(1));

            if (dataGridView3.CurrentRow.Cells[6].Value.ToString() != "N/A")
            {
                value -= value * 0.15m;

            }
            dataGridView2.Rows.Remove(dataGridView2.CurrentRow);
            price -= value;
            priceTB.Text = price.ToString("C2");
            GlobalVariables.tPrice = price.ToString("C2");

        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            /* if ((string)comboBox1.Text == "Mnguni")
             {
                 textBox3.Text = "2";
             }
             if ((string)comboBox1.SelectedValue == "Mohomed")
             {
                 textBox3.Text = "1";
             }
             if ((string)comboBox1.SelectedValue == "Ncube")
             {
                 textBox3.Text = "3";
             }
             if ((string)comboBox1.SelectedValue == "Zikhali")
             {
                 textBox3.Text = "9";
             }*/
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            /*if ((string)comboBox1.Text == "Mnguni")
            {
                textBox3.Text = "2";
            }
            if ((string)comboBox1.Text == "Mohomed")
            {
                textBox3.Text = "1";
            }
            if ((string)comboBox1.Text == "Ncube")
            {
                textBox3.Text = "3";
            }
            if ((string)comboBox1.Text == "Zikhali")
            {
                textBox3.Text = "9";
            }*/
        }

        private void acnameTB_TextChanged(object sender, EventArgs e)
        {
            taAppointment_tbl.Fill(dsG71.Appointment_tbl);
            appointmenttblBS.MoveLast();
        }

        private void txtRRB_TextChanged(object sender, EventArgs e)
        {

        }

        private void setAvailableBtn_Click(object sender, EventArgs e)
        {

            if (Convert.ToBoolean(gvBAB.CurrentRow.Cells[5].Value) == true)
            {
                gvBAB.CurrentRow.Cells[5].Value = false;
            }
            else
            {
                gvBAB.CurrentRow.Cells[5].Value = true;
            }
        }

        private void dataGridView4_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox9.Text = dataGridView4.CurrentRow.Cells[1].Value.ToString();
            textBox3.Text = dataGridView4.CurrentRow.Cells[0].Value.ToString();
        }

        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //label3.Text = DateTime.Now.ToString();
                acnameTB.Text = dataGridView3.CurrentRow.Cells[2].Value.ToString();
                acustcellNumberTB.Text = dataGridView3.CurrentRow.Cells[3].Value.ToString();
                aemailAddressTB.Text = dataGridView3.CurrentRow.Cells[4].Value.ToString();
                physicalAddressTB.Text = dataGridView3.CurrentRow.Cells[5].Value.ToString();
                StudentNoTB.Text = dataGridView3.CurrentRow.Cells[6].Value.ToString();

                GlobalVariables.cname = dataGridView3.CurrentRow.Cells[2].Value.ToString();
                GlobalVariables.cCellNo = dataGridView3.CurrentRow.Cells[3].Value.ToString();
                GlobalVariables.cEmailAddress = dataGridView3.CurrentRow.Cells[4].Value.ToString();
                GlobalVariables.cPhycalAddress = dataGridView3.CurrentRow.Cells[5].Value.ToString();
                GlobalVariables.cStudendNo = dataGridView3.CurrentRow.Cells[6].Value.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Multiple clicks detected. Please click only once.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataRow dr;
                dr = dsNew.ServiceTwo.NewRow();
                for (int i = 0; i < dr.ItemArray.Length; i++)
                {
                    dr[i] = dataGridView1.CurrentRow.Cells[i].Value;
                }
                dsNew.ServiceTwo.Rows.Add(dr);

                if (dataGridView3.CurrentRow.Cells[6].Value.ToString() != "N/A")
                {
                    decimal total = getTotal();
                    decimal discountedTot = total * 0.85m;
                    priceTB.Text = discountedTot.ToString("C2");
                    GlobalVariables.tPrice = discountedTot.ToString("C2");
                }
                else
                {
                    priceTB.Text = getTotal().ToString("C2");
                    GlobalVariables.tPrice = getTotal().ToString("C2");

                }
            }
            catch (Exception ex)
            {
                // Show a message box indicating that the user clicked more than once
                MessageBox.Show("Multiple clicks detected. Please click only once.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void gvBAB_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                bookAppointmentBTB.Text = gvBAB.CurrentRow.Cells[1].Value.ToString();
                GlobalVariables.barber = gvBAB.CurrentRow.Cells[1].Value.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Multiple clicks detected. Please click only once.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

        }
        private void Generate()
        {
            txtRRB.Clear();
            txtRRB.Text += "*******************************************************\n";
            txtRRB.Text += "*                 StyleCuts BarberShop                *\n";
            txtRRB.Text += "*******************************************************\n";
            txtRRB.Text += "Date: " + DateTime.Now + "\n\n";
            txtRRB.Text += "Customer Name: " + GlobalVariables.cname + "\n\n";
            txtRRB.Text += "Barber: " + GlobalVariables.barber + "\n\n";
            txtRRB.Text += "Appointment Date: " + monthCalendar1.SelectionRange.Start.ToString("yyyy-MM-dd") + "\n\n";
            txtRRB.Text += "Time Slot: " + GlobalVariables.time + "\n\n";
            txtRRB.Text += "Service Name: ";
            for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
            {
                if (i == 0)
                {
                    txtRRB.Text += Convert.ToString(dataGridView2.Rows[i].Cells[1].Value) + "  R" + Convert.ToString(dataGridView2.Rows[i].Cells[2].Value) + "\n\n";
                }
                else
                {
                    txtRRB.Text += "                      " + Convert.ToString(dataGridView2.Rows[i].Cells[1].Value) + "  R" + Convert.ToString(dataGridView2.Rows[i].Cells[2].Value) + "\n\n";
                }

            }
            if (dataGridView3.CurrentRow.Cells[6].Value.ToString() != "N/A")
            {
                txtRRB.Text += "Student Number: " + GlobalVariables.cStudendNo + "\n\n";
                txtRRB.Text += "Student Discount Rate: " + "15%" + "\n\n";
                txtRRB.Text += "Total Price: " + getTotal().ToString("C2") + "\n\n";
                txtRRB.Text += "Discounted Total: " + GlobalVariables.tPrice + "\n\n";

            }
            else
            {
                txtRRB.Text += "Total Price: " + GlobalVariables.tPrice + "\n\n";
            }


            txtRRB.Text += "*******************************************************\n";
            txtRRB.Text += "Thank You for choosing SyleCuts Barber Shop\n";
            txtRRB.Text += "*******************************************************\n";

        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
            {
                tabControl1.SelectedIndex += 1;
            }

        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
            {
                tabControl1.SelectedIndex += 1;
            }

        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
            {
                tabControl1.SelectedIndex += 1;
            }

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex > 0)
            {
                tabControl1.SelectedIndex -= 1;
            }

        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex > 0)
            {
                tabControl1.SelectedIndex -= 1;
            }

        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex > 0)
            {
                tabControl1.SelectedIndex -= 1;
            }

        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex > 0)
            {
                tabControl1.SelectedIndex -= 1;
            }

        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex > 0)
            {
                tabControl1.SelectedIndex -= 1;
            }

        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
            {
                tabControl1.SelectedIndex += 1;
            }

        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
            {
                tabControl1.SelectedIndex += 1;
            }

        }
        private void fillList()
        {

            for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
            {
                // Service_Id.Add(Convert.ToInt32(dataGridView2.Rows[i].Cells[3].Value));
                services.Add(Convert.ToString(dataGridView2.Rows[i].Cells[1].Value));
                prices.Add(Convert.ToString(dataGridView2.Rows[i].Cells[2].Value));
            }



            // for (int i = 0; i <= service_id.Count - 1; i++)
            //{
            //  taService_Appointment.Insert1(Appointment_id, service_id[i]);
            // }
        }

        private void priceTB_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Move the focus to the next control
                textBox8.Focus();
            }
        }

        private void textBox8_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Move the focus to the next control
                textBox7.Focus();
            }
        }

        private void textBox7_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Move the focus to the next control
                textBox4.Focus();
            }
        }

        private void textBox4_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Move the focus to the next control
                textBox2.Focus();
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Move the focus to the next control
                textBox9.Focus();
            }
        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }
    }
}
