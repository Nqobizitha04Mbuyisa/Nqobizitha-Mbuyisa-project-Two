﻿
namespace StyleCutsBarberShopSystem
{
    partial class AddServiceUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.serviceClearBtn = new System.Windows.Forms.Button();
            this.serviceConfirmBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.servicePriceTB = new System.Windows.Forms.TextBox();
            this.serviceNameTB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.gv2 = new System.Windows.Forms.DataGridView();
            this.itemidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itempriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inventorytblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsG71 = new StyleCutsBarberShopSystem.dsG7();
            this.gv1 = new System.Windows.Forms.DataGridView();
            this.serviceidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicenameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicepriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.serviceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.serviceBS = new System.Windows.Forms.BindingSource(this.components);
            this.taService1 = new StyleCutsBarberShopSystem.dsG7TableAdapters.ServiceTableAdapter();
            this.inventory_tblTableAdapter = new StyleCutsBarberShopSystem.dsG7TableAdapters.Inventory_tblTableAdapter();
            this.taService_Inventory = new StyleCutsBarberShopSystem.dsG7TableAdapters.Service_InventoryTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventorytblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceBS)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 450);
            this.tabControl1.TabIndex = 6;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 424);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Add Service";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(this.serviceClearBtn);
            this.groupBox1.Controls.Add(this.serviceConfirmBtn);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.servicePriceTB);
            this.groupBox1.Controls.Add(this.serviceNameTB);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(130, 125);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(532, 175);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Service Details";
            // 
            // serviceClearBtn
            // 
            this.serviceClearBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.serviceClearBtn.BackColor = System.Drawing.Color.Navy;
            this.serviceClearBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.serviceClearBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.serviceClearBtn.ForeColor = System.Drawing.Color.White;
            this.serviceClearBtn.Location = new System.Drawing.Point(235, 133);
            this.serviceClearBtn.Name = "serviceClearBtn";
            this.serviceClearBtn.Size = new System.Drawing.Size(75, 36);
            this.serviceClearBtn.TabIndex = 14;
            this.serviceClearBtn.Text = "Clear";
            this.serviceClearBtn.UseVisualStyleBackColor = false;
            this.serviceClearBtn.Click += new System.EventHandler(this.serviceClearBtn_Click_1);
            // 
            // serviceConfirmBtn
            // 
            this.serviceConfirmBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.serviceConfirmBtn.BackColor = System.Drawing.Color.Navy;
            this.serviceConfirmBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.serviceConfirmBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.serviceConfirmBtn.ForeColor = System.Drawing.Color.White;
            this.serviceConfirmBtn.Location = new System.Drawing.Point(376, 133);
            this.serviceConfirmBtn.Name = "serviceConfirmBtn";
            this.serviceConfirmBtn.Size = new System.Drawing.Size(75, 36);
            this.serviceConfirmBtn.TabIndex = 15;
            this.serviceConfirmBtn.Text = "Confirm";
            this.serviceConfirmBtn.UseVisualStyleBackColor = false;
            this.serviceConfirmBtn.Click += new System.EventHandler(this.serviceConfirmBtn_Click_1);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(69, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 20);
            this.label3.TabIndex = 17;
            this.label3.Text = "Price";
            // 
            // servicePriceTB
            // 
            this.servicePriceTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.servicePriceTB.Location = new System.Drawing.Point(235, 89);
            this.servicePriceTB.Name = "servicePriceTB";
            this.servicePriceTB.Size = new System.Drawing.Size(216, 26);
            this.servicePriceTB.TabIndex = 1;
            // 
            // serviceNameTB
            // 
            this.serviceNameTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.serviceNameTB.Location = new System.Drawing.Point(235, 46);
            this.serviceNameTB.Name = "serviceNameTB";
            this.serviceNameTB.Size = new System.Drawing.Size(216, 26);
            this.serviceNameTB.TabIndex = 10;
            this.serviceNameTB.KeyDown += new System.Windows.Forms.KeyEventHandler(this.serviceNameTB_KeyDown);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(69, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.textBox1);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.gv2);
            this.tabPage2.Controls.Add(this.gv1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 424);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Select products, the service uses";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.Color.Navy;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(459, 365);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(260, 36);
            this.button1.TabIndex = 16;
            this.button1.Text = "Confirm";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(142, 365);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(93, 29);
            this.textBox1.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(48, 365);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 20);
            this.label2.TabIndex = 11;
            this.label2.Text = "Quantity";
            // 
            // gv2
            // 
            this.gv2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gv2.AutoGenerateColumns = false;
            this.gv2.BackgroundColor = System.Drawing.Color.White;
            this.gv2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gv2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.itemidDataGridViewTextBoxColumn,
            this.itemnameDataGridViewTextBoxColumn,
            this.itempriceDataGridViewTextBoxColumn});
            this.gv2.DataSource = this.inventorytblBindingSource;
            this.gv2.Location = new System.Drawing.Point(50, 195);
            this.gv2.Name = "gv2";
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.gv2.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gv2.Size = new System.Drawing.Size(669, 150);
            this.gv2.TabIndex = 1;
            // 
            // itemidDataGridViewTextBoxColumn
            // 
            this.itemidDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.itemidDataGridViewTextBoxColumn.DataPropertyName = "item_id";
            this.itemidDataGridViewTextBoxColumn.HeaderText = "item_id";
            this.itemidDataGridViewTextBoxColumn.Name = "itemidDataGridViewTextBoxColumn";
            this.itemidDataGridViewTextBoxColumn.ReadOnly = true;
            this.itemidDataGridViewTextBoxColumn.Width = 65;
            // 
            // itemnameDataGridViewTextBoxColumn
            // 
            this.itemnameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.itemnameDataGridViewTextBoxColumn.DataPropertyName = "item_name";
            this.itemnameDataGridViewTextBoxColumn.HeaderText = "item_name";
            this.itemnameDataGridViewTextBoxColumn.Name = "itemnameDataGridViewTextBoxColumn";
            // 
            // itempriceDataGridViewTextBoxColumn
            // 
            this.itempriceDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.itempriceDataGridViewTextBoxColumn.DataPropertyName = "item_price";
            this.itempriceDataGridViewTextBoxColumn.HeaderText = "item_price";
            this.itempriceDataGridViewTextBoxColumn.Name = "itempriceDataGridViewTextBoxColumn";
            this.itempriceDataGridViewTextBoxColumn.Width = 80;
            // 
            // inventorytblBindingSource
            // 
            this.inventorytblBindingSource.DataMember = "Inventory_tbl";
            this.inventorytblBindingSource.DataSource = this.dsG71;
            // 
            // dsG71
            // 
            this.dsG71.DataSetName = "dsG7";
            this.dsG71.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gv1
            // 
            this.gv1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gv1.AutoGenerateColumns = false;
            this.gv1.BackgroundColor = System.Drawing.Color.White;
            this.gv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gv1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serviceidDataGridViewTextBoxColumn,
            this.servicenameDataGridViewTextBoxColumn,
            this.servicepriceDataGridViewTextBoxColumn});
            this.gv1.DataSource = this.serviceBindingSource;
            this.gv1.Location = new System.Drawing.Point(50, 20);
            this.gv1.Name = "gv1";
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.gv1.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.gv1.Size = new System.Drawing.Size(669, 150);
            this.gv1.TabIndex = 0;
            // 
            // serviceidDataGridViewTextBoxColumn
            // 
            this.serviceidDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.serviceidDataGridViewTextBoxColumn.DataPropertyName = "service_id";
            this.serviceidDataGridViewTextBoxColumn.HeaderText = "service_id";
            this.serviceidDataGridViewTextBoxColumn.Name = "serviceidDataGridViewTextBoxColumn";
            this.serviceidDataGridViewTextBoxColumn.ReadOnly = true;
            this.serviceidDataGridViewTextBoxColumn.Width = 80;
            // 
            // servicenameDataGridViewTextBoxColumn
            // 
            this.servicenameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.servicenameDataGridViewTextBoxColumn.DataPropertyName = "service_name";
            this.servicenameDataGridViewTextBoxColumn.HeaderText = "service_name";
            this.servicenameDataGridViewTextBoxColumn.Name = "servicenameDataGridViewTextBoxColumn";
            // 
            // servicepriceDataGridViewTextBoxColumn
            // 
            this.servicepriceDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.servicepriceDataGridViewTextBoxColumn.DataPropertyName = "service_price";
            this.servicepriceDataGridViewTextBoxColumn.HeaderText = "service_price";
            this.servicepriceDataGridViewTextBoxColumn.Name = "servicepriceDataGridViewTextBoxColumn";
            this.servicepriceDataGridViewTextBoxColumn.Width = 95;
            // 
            // serviceBindingSource
            // 
            this.serviceBindingSource.DataMember = "Service";
            this.serviceBindingSource.DataSource = this.dsG71;
            // 
            // serviceBS
            // 
            this.serviceBS.DataMember = "Service";
            this.serviceBS.DataSource = this.dsG71;
            // 
            // taService1
            // 
            this.taService1.ClearBeforeFill = true;
            // 
            // inventory_tblTableAdapter
            // 
            this.inventory_tblTableAdapter.ClearBeforeFill = true;
            // 
            // taService_Inventory
            // 
            this.taService_Inventory.ClearBeforeFill = true;
            // 
            // AddServiceUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddServiceUI";
            this.Text = "AddServiceUI";
            this.Load += new System.EventHandler(this.AddServiceUI_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gv2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventorytblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gv1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.serviceBS)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private dsG7 dsG71;
        private dsG7TableAdapters.ServiceTableAdapter taService1;
        private System.Windows.Forms.BindingSource serviceBS;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button serviceClearBtn;
        private System.Windows.Forms.Button serviceConfirmBtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox servicePriceTB;
        private System.Windows.Forms.TextBox serviceNameTB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView gv2;
        private System.Windows.Forms.DataGridView gv1;
        private System.Windows.Forms.BindingSource serviceBindingSource;
        private System.Windows.Forms.BindingSource inventorytblBindingSource;
        private dsG7TableAdapters.Inventory_tblTableAdapter inventory_tblTableAdapter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itempriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn serviceidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicenameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicepriceDataGridViewTextBoxColumn;
        private dsG7TableAdapters.Service_InventoryTableAdapter taService_Inventory;
    }
}