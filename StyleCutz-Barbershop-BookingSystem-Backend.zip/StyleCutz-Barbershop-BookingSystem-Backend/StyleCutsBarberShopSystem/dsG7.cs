﻿namespace StyleCutsBarberShopSystem
{


    partial class dsG7
    {
        partial class Employee_tblDataTable
        {
        }

        partial class _A_C_E_S_TableDataTable
        {
        }
    }
}

namespace StyleCutsBarberShopSystem.dsG7TableAdapters
{
    partial class Employee_tblTableAdapter
    {
    }

    public partial class Appointment_tblTableAdapter {
    }
}
