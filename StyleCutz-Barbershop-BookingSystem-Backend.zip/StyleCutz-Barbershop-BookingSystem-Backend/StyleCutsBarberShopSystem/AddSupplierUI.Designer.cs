﻿
namespace StyleCutsBarberShopSystem
{
    partial class AddSupplierUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.supplierAddressTB = new System.Windows.Forms.TextBox();
            this.supplierClearTB = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.supplierConfirmTB = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.supplierEmailTB = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.supplierNameTB = new System.Windows.Forms.TextBox();
            this.supplierCellNoTB = new System.Windows.Forms.TextBox();
            this.suppliertblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsG7 = new StyleCutsBarberShopSystem.dsG7();
            this.taSupplier = new StyleCutsBarberShopSystem.dsG7TableAdapters.Supplier_tblTableAdapter();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.suppliertblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG7)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(this.supplierAddressTB);
            this.groupBox1.Controls.Add(this.supplierClearTB);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.supplierConfirmTB);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.supplierEmailTB);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.supplierNameTB);
            this.groupBox1.Controls.Add(this.supplierCellNoTB);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(132, 97);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(532, 234);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Supplier Details";
            // 
            // supplierAddressTB
            // 
            this.supplierAddressTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.supplierAddressTB.Location = new System.Drawing.Point(254, 141);
            this.supplierAddressTB.Multiline = true;
            this.supplierAddressTB.Name = "supplierAddressTB";
            this.supplierAddressTB.Size = new System.Drawing.Size(216, 20);
            this.supplierAddressTB.TabIndex = 17;
            // 
            // supplierClearTB
            // 
            this.supplierClearTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.supplierClearTB.BackColor = System.Drawing.Color.Navy;
            this.supplierClearTB.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.supplierClearTB.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.supplierClearTB.ForeColor = System.Drawing.Color.White;
            this.supplierClearTB.Location = new System.Drawing.Point(254, 177);
            this.supplierClearTB.Name = "supplierClearTB";
            this.supplierClearTB.Size = new System.Drawing.Size(75, 34);
            this.supplierClearTB.TabIndex = 14;
            this.supplierClearTB.Text = "Clear";
            this.supplierClearTB.UseVisualStyleBackColor = false;
            this.supplierClearTB.Click += new System.EventHandler(this.supplierClearTB_Click);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(63, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 20);
            this.label2.TabIndex = 16;
            this.label2.Text = "Physical Address";
            // 
            // supplierConfirmTB
            // 
            this.supplierConfirmTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.supplierConfirmTB.BackColor = System.Drawing.Color.Navy;
            this.supplierConfirmTB.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.supplierConfirmTB.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.supplierConfirmTB.ForeColor = System.Drawing.Color.White;
            this.supplierConfirmTB.Location = new System.Drawing.Point(395, 177);
            this.supplierConfirmTB.Name = "supplierConfirmTB";
            this.supplierConfirmTB.Size = new System.Drawing.Size(75, 34);
            this.supplierConfirmTB.TabIndex = 15;
            this.supplierConfirmTB.Text = "Confirm";
            this.supplierConfirmTB.UseVisualStyleBackColor = false;
            this.supplierConfirmTB.Click += new System.EventHandler(this.supplierConfirmTB_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(63, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(63, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(147, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Cellphone Number";
            // 
            // supplierEmailTB
            // 
            this.supplierEmailTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.supplierEmailTB.Location = new System.Drawing.Point(254, 111);
            this.supplierEmailTB.Name = "supplierEmailTB";
            this.supplierEmailTB.Size = new System.Drawing.Size(216, 26);
            this.supplierEmailTB.TabIndex = 11;
            this.supplierEmailTB.KeyDown += new System.Windows.Forms.KeyEventHandler(this.supplierEmailTB_KeyDown);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(63, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Email Address";
            // 
            // supplierNameTB
            // 
            this.supplierNameTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.supplierNameTB.Location = new System.Drawing.Point(254, 51);
            this.supplierNameTB.Name = "supplierNameTB";
            this.supplierNameTB.Size = new System.Drawing.Size(216, 26);
            this.supplierNameTB.TabIndex = 1;
            this.supplierNameTB.KeyDown += new System.Windows.Forms.KeyEventHandler(this.supplierNameTB_KeyDown);
            // 
            // supplierCellNoTB
            // 
            this.supplierCellNoTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.supplierCellNoTB.Location = new System.Drawing.Point(254, 81);
            this.supplierCellNoTB.Name = "supplierCellNoTB";
            this.supplierCellNoTB.Size = new System.Drawing.Size(216, 26);
            this.supplierCellNoTB.TabIndex = 10;
            this.supplierCellNoTB.KeyDown += new System.Windows.Forms.KeyEventHandler(this.supplierCellNoTB_KeyDown);
            // 
            // suppliertblBindingSource
            // 
            this.suppliertblBindingSource.DataMember = "Supplier_tbl";
            this.suppliertblBindingSource.DataSource = this.dsG7;
            // 
            // dsG7
            // 
            this.dsG7.DataSetName = "dsG7";
            this.dsG7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // taSupplier
            // 
            this.taSupplier.ClearBeforeFill = true;
            // 
            // AddSupplierUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddSupplierUI";
            this.Text = "AddSupplierUI";
            this.Load += new System.EventHandler(this.AddSupplierUI_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.suppliertblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox supplierAddressTB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button supplierConfirmTB;
        private System.Windows.Forms.Button supplierClearTB;
        private System.Windows.Forms.TextBox supplierEmailTB;
        private System.Windows.Forms.TextBox supplierCellNoTB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox supplierNameTB;
        private System.Windows.Forms.Label label1;
        private dsG7 dsG7;
        private System.Windows.Forms.BindingSource suppliertblBindingSource;
        private dsG7TableAdapters.Supplier_tblTableAdapter taSupplier;
    }
}