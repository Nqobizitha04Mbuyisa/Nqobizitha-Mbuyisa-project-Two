﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StyleCutsBarberShopSystem
{
    public partial class ViewProductUI : Form
    {
        DialogResult v;
        
        public ViewProductUI()
        {
            InitializeComponent();
        }

        private void ViewProductUI_Load(object sender, EventArgs e)
        {

            // TODO: This line of code loads data into the 'dsViewProduct.DataTable2' table. You can move, or remove it, as needed.
            this.dataTable2TableAdapter.Fill(this.dsViewProduct.DataTable2);
            // TODO: This line of code loads data into the 'dsViewProduct.Supplier_tbl' table. You can move, or remove it, as needed.
            this.supplier_tblTableAdapter.Fill(this.dsViewProduct.Supplier_tbl);
            // TODO: This line of code loads data into the 'dsViewProduct.Supplier_tbl' table. You can move, or remove it, as needed.
            this.supplier_tblTableAdapter.Fill(this.dsViewProduct.Supplier_tbl);
            taViewProduct1.Fill(dsViewProduct.Inventory_tbl);
            /*
            for(int i = 0; i < gvProducts.Rows.Count - 1; i++)
            {
                if (Convert.ToInt16(gvProducts.Rows[i].Cells[2].Value) <= 20)
                {
                   DialogResult c= MessageBox.Show("Urgent: " + gvProducts.Rows[i].Cells[3].Value + " is critically low! Only "+ gvProducts.Rows[i].Cells[2].Value + " units remaining. Immediate restocking is recommended!!", "LOW STOCK ALERT!!",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                    //inventoryMenuOpen = false;
                  //  doIt();
                   
                     
                      
                     


                }
            }*/
             
        }
        private void gvProductsSearchTB_TextChanged(object sender, EventArgs e)
        {
            taViewProduct1.FillByItemName(dsViewProduct.Inventory_tbl, gvProductsSearchTB.Text);
        }

        private void gvProductsSearchBtn_Click(object sender, EventArgs e)
        {
            taViewProduct1.FillByItemName(dsViewProduct.Inventory_tbl, gvProductsSearchTB.Text);
        }

        private void vProductFirstBtn_Click(object sender, EventArgs e)
        {
            taViewProductBS.MoveFirst();
        }
        public void doIt()
        {
            
            
                HomeScreenUI a = new HomeScreenUI();
                UpdateStockUI b = new UpdateStockUI();

                this.Close();
                a.LoadFormIntoPanel(b);
                //this.Close();

            
        }

        private void vProductPrevousBtn_Click(object sender, EventArgs e)
        {
            taViewProductBS.MovePrevious();
        }

        private void vProductNextBtn_Click(object sender, EventArgs e)
        {
            taViewProductBS.MoveNext();
        }

        private void vProductLastBtn_Click(object sender, EventArgs e)
        {
            taViewProductBS.MoveLast();
        }

        private void vProductSubmitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void vProductUpdateBtn_Click(object sender, EventArgs e)
        {
            
            DialogResult confirmation;
            confirmation = MessageBox.Show("Are you sure you want to update?", "Confirm", MessageBoxButtons.YesNo);
            if (confirmation == DialogResult.Yes)
            {
                taViewProductBS.EndEdit();
                taViewProduct1.Update(dsViewProduct);
                MessageBox.Show("Update successful");

            }
            else if(confirmation == DialogResult.No)
            {
                MessageBox.Show("Update cancelled");
                taViewProduct1.Fill(dsViewProduct.Inventory_tbl);
            }
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
           

            DialogResult confirmation;
            confirmation = MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo);
            if (confirmation == DialogResult.Yes)
            {
                taViewProduct1.UpdateStatus("unavailable", Convert.ToInt32(gvProducts.CurrentRow.Cells[0].Value));
                this.dataTable2TableAdapter.Fill(this.dsViewProduct.DataTable2);
                MessageBox.Show("Deletion successful");

            }
            else if (confirmation == DialogResult.No)
            {
                MessageBox.Show("Deletion cancelled");  
            }

        }

        private void gvProducts_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
            {
                tabControl1.SelectedIndex += 1;
            }
        }
    }
}
