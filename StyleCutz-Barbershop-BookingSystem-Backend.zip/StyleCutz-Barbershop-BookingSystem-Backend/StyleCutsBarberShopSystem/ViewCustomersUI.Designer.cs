﻿
namespace StyleCutsBarberShopSystem
{
    partial class ViewCustomersUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.gvCustomer = new System.Windows.Forms.DataGridView();
            this.customeridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customercellNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customeremailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customeraddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentnumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerBS = new System.Windows.Forms.BindingSource(this.components);
            this.dsG7 = new StyleCutsBarberShopSystem.dsG7();
            this.gvCustomersSearchTB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.Options = new System.Windows.Forms.GroupBox();
            this.vCustomerUpdateBtn = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.vCustomerFirstBtn = new System.Windows.Forms.Button();
            this.vCustomerNextBtn = new System.Windows.Forms.Button();
            this.vCustomerPrevoiusBtn = new System.Windows.Forms.Button();
            this.vCustomerLastBtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.vCustomerAddressTB = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.vCustomerEmailTB = new System.Windows.Forms.TextBox();
            this.vCustomerCellTB = new System.Windows.Forms.TextBox();
            this.vCustomerNameTB = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.taCustomer = new StyleCutsBarberShopSystem.dsG7TableAdapters.Customer_tblTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvCustomer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG7)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.Options.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 450);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.gvCustomer);
            this.tabPage1.Controls.Add(this.gvCustomersSearchTB);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 424);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "View Customer Details";
            // 
            // gvCustomer
            // 
            this.gvCustomer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gvCustomer.AutoGenerateColumns = false;
            this.gvCustomer.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gvCustomer.BackgroundColor = System.Drawing.Color.White;
            this.gvCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvCustomer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.customeridDataGridViewTextBoxColumn,
            this.customernameDataGridViewTextBoxColumn,
            this.customercellNoDataGridViewTextBoxColumn,
            this.customeremailDataGridViewTextBoxColumn,
            this.customeraddressDataGridViewTextBoxColumn,
            this.studentnumberDataGridViewTextBoxColumn});
            this.gvCustomer.DataSource = this.customerBS;
            this.gvCustomer.Location = new System.Drawing.Point(6, 71);
            this.gvCustomer.Margin = new System.Windows.Forms.Padding(2);
            this.gvCustomer.Name = "gvCustomer";
            this.gvCustomer.ReadOnly = true;
            this.gvCustomer.RowHeadersWidth = 51;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.gvCustomer.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gvCustomer.RowTemplate.Height = 24;
            this.gvCustomer.Size = new System.Drawing.Size(770, 272);
            this.gvCustomer.TabIndex = 45;
            this.gvCustomer.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvCustomer_CellClick);
            // 
            // customeridDataGridViewTextBoxColumn
            // 
            this.customeridDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.customeridDataGridViewTextBoxColumn.DataPropertyName = "customer_id";
            this.customeridDataGridViewTextBoxColumn.HeaderText = "customer_id";
            this.customeridDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.customeridDataGridViewTextBoxColumn.Name = "customeridDataGridViewTextBoxColumn";
            this.customeridDataGridViewTextBoxColumn.ReadOnly = true;
            this.customeridDataGridViewTextBoxColumn.Width = 89;
            // 
            // customernameDataGridViewTextBoxColumn
            // 
            this.customernameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.customernameDataGridViewTextBoxColumn.DataPropertyName = "customer_name";
            this.customernameDataGridViewTextBoxColumn.HeaderText = "customer_name";
            this.customernameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.customernameDataGridViewTextBoxColumn.Name = "customernameDataGridViewTextBoxColumn";
            this.customernameDataGridViewTextBoxColumn.ReadOnly = true;
            this.customernameDataGridViewTextBoxColumn.Width = 107;
            // 
            // customercellNoDataGridViewTextBoxColumn
            // 
            this.customercellNoDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.customercellNoDataGridViewTextBoxColumn.DataPropertyName = "customer_cellNo";
            this.customercellNoDataGridViewTextBoxColumn.HeaderText = "customer_cellNo";
            this.customercellNoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.customercellNoDataGridViewTextBoxColumn.Name = "customercellNoDataGridViewTextBoxColumn";
            this.customercellNoDataGridViewTextBoxColumn.ReadOnly = true;
            this.customercellNoDataGridViewTextBoxColumn.Width = 111;
            // 
            // customeremailDataGridViewTextBoxColumn
            // 
            this.customeremailDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.customeremailDataGridViewTextBoxColumn.DataPropertyName = "customer_email";
            this.customeremailDataGridViewTextBoxColumn.HeaderText = "customer_email";
            this.customeremailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.customeremailDataGridViewTextBoxColumn.Name = "customeremailDataGridViewTextBoxColumn";
            this.customeremailDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // customeraddressDataGridViewTextBoxColumn
            // 
            this.customeraddressDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.customeraddressDataGridViewTextBoxColumn.DataPropertyName = "customer_address";
            this.customeraddressDataGridViewTextBoxColumn.HeaderText = "customer_address";
            this.customeraddressDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.customeraddressDataGridViewTextBoxColumn.Name = "customeraddressDataGridViewTextBoxColumn";
            this.customeraddressDataGridViewTextBoxColumn.ReadOnly = true;
            this.customeraddressDataGridViewTextBoxColumn.Width = 118;
            // 
            // studentnumberDataGridViewTextBoxColumn
            // 
            this.studentnumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.studentnumberDataGridViewTextBoxColumn.DataPropertyName = "student_number";
            this.studentnumberDataGridViewTextBoxColumn.HeaderText = "student_number";
            this.studentnumberDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.studentnumberDataGridViewTextBoxColumn.Name = "studentnumberDataGridViewTextBoxColumn";
            this.studentnumberDataGridViewTextBoxColumn.ReadOnly = true;
            this.studentnumberDataGridViewTextBoxColumn.Width = 108;
            // 
            // customerBS
            // 
            this.customerBS.DataMember = "Customer_tbl";
            this.customerBS.DataSource = this.dsG7;
            // 
            // dsG7
            // 
            this.dsG7.DataSetName = "dsG7";
            this.dsG7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gvCustomersSearchTB
            // 
            this.gvCustomersSearchTB.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gvCustomersSearchTB.ForeColor = System.Drawing.Color.Black;
            this.gvCustomersSearchTB.Location = new System.Drawing.Point(325, 28);
            this.gvCustomersSearchTB.Name = "gvCustomersSearchTB";
            this.gvCustomersSearchTB.Size = new System.Drawing.Size(178, 20);
            this.gvCustomersSearchTB.TabIndex = 43;
            this.gvCustomersSearchTB.TextChanged += new System.EventHandler(this.gvCustomersSearchTB_TextChanged);
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(188, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(131, 20);
            this.label6.TabIndex = 42;
            this.label6.Text = "Customer Name:";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.Options);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 424);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Modify Customer Details";
            // 
            // Options
            // 
            this.Options.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Options.Controls.Add(this.vCustomerUpdateBtn);
            this.Options.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Options.ForeColor = System.Drawing.Color.Black;
            this.Options.Location = new System.Drawing.Point(195, 319);
            this.Options.Name = "Options";
            this.Options.Size = new System.Drawing.Size(423, 69);
            this.Options.TabIndex = 40;
            this.Options.TabStop = false;
            this.Options.Text = "Options";
            // 
            // vCustomerUpdateBtn
            // 
            this.vCustomerUpdateBtn.BackColor = System.Drawing.Color.Navy;
            this.vCustomerUpdateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vCustomerUpdateBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vCustomerUpdateBtn.ForeColor = System.Drawing.Color.White;
            this.vCustomerUpdateBtn.Location = new System.Drawing.Point(10, 22);
            this.vCustomerUpdateBtn.Name = "vCustomerUpdateBtn";
            this.vCustomerUpdateBtn.Size = new System.Drawing.Size(400, 37);
            this.vCustomerUpdateBtn.TabIndex = 15;
            this.vCustomerUpdateBtn.Text = "Update";
            this.vCustomerUpdateBtn.UseVisualStyleBackColor = false;
            this.vCustomerUpdateBtn.Click += new System.EventHandler(this.vCustomerUpdateBtn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(this.vCustomerFirstBtn);
            this.groupBox2.Controls.Add(this.vCustomerNextBtn);
            this.groupBox2.Controls.Add(this.vCustomerPrevoiusBtn);
            this.groupBox2.Controls.Add(this.vCustomerLastBtn);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Black;
            this.groupBox2.Location = new System.Drawing.Point(195, 219);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(423, 94);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Navigation";
            // 
            // vCustomerFirstBtn
            // 
            this.vCustomerFirstBtn.BackColor = System.Drawing.Color.Navy;
            this.vCustomerFirstBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vCustomerFirstBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vCustomerFirstBtn.ForeColor = System.Drawing.Color.White;
            this.vCustomerFirstBtn.Location = new System.Drawing.Point(10, 36);
            this.vCustomerFirstBtn.Name = "vCustomerFirstBtn";
            this.vCustomerFirstBtn.Size = new System.Drawing.Size(87, 37);
            this.vCustomerFirstBtn.TabIndex = 13;
            this.vCustomerFirstBtn.Text = "First";
            this.vCustomerFirstBtn.UseVisualStyleBackColor = false;
            this.vCustomerFirstBtn.Click += new System.EventHandler(this.vCustomerFirstBtn_Click);
            // 
            // vCustomerNextBtn
            // 
            this.vCustomerNextBtn.BackColor = System.Drawing.Color.Navy;
            this.vCustomerNextBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vCustomerNextBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vCustomerNextBtn.ForeColor = System.Drawing.Color.White;
            this.vCustomerNextBtn.Location = new System.Drawing.Point(220, 36);
            this.vCustomerNextBtn.Name = "vCustomerNextBtn";
            this.vCustomerNextBtn.Size = new System.Drawing.Size(87, 37);
            this.vCustomerNextBtn.TabIndex = 12;
            this.vCustomerNextBtn.Text = "Next";
            this.vCustomerNextBtn.UseVisualStyleBackColor = false;
            this.vCustomerNextBtn.Click += new System.EventHandler(this.vCustomerNextBtn_Click);
            // 
            // vCustomerPrevoiusBtn
            // 
            this.vCustomerPrevoiusBtn.BackColor = System.Drawing.Color.Navy;
            this.vCustomerPrevoiusBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vCustomerPrevoiusBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vCustomerPrevoiusBtn.ForeColor = System.Drawing.Color.White;
            this.vCustomerPrevoiusBtn.Location = new System.Drawing.Point(117, 36);
            this.vCustomerPrevoiusBtn.Name = "vCustomerPrevoiusBtn";
            this.vCustomerPrevoiusBtn.Size = new System.Drawing.Size(87, 37);
            this.vCustomerPrevoiusBtn.TabIndex = 11;
            this.vCustomerPrevoiusBtn.Text = "Previous";
            this.vCustomerPrevoiusBtn.UseVisualStyleBackColor = false;
            this.vCustomerPrevoiusBtn.Click += new System.EventHandler(this.vCustomerPrevoiusBtn_Click);
            // 
            // vCustomerLastBtn
            // 
            this.vCustomerLastBtn.BackColor = System.Drawing.Color.Navy;
            this.vCustomerLastBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vCustomerLastBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vCustomerLastBtn.ForeColor = System.Drawing.Color.White;
            this.vCustomerLastBtn.Location = new System.Drawing.Point(323, 36);
            this.vCustomerLastBtn.Name = "vCustomerLastBtn";
            this.vCustomerLastBtn.Size = new System.Drawing.Size(87, 37);
            this.vCustomerLastBtn.TabIndex = 10;
            this.vCustomerLastBtn.Text = "Last";
            this.vCustomerLastBtn.UseVisualStyleBackColor = false;
            this.vCustomerLastBtn.Click += new System.EventHandler(this.vCustomerLastBtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.vCustomerAddressTB);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.vCustomerEmailTB);
            this.groupBox1.Controls.Add(this.vCustomerCellTB);
            this.groupBox1.Controls.Add(this.vCustomerNameTB);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(195, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(423, 184);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Customer Details";
            // 
            // textBox1
            // 
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBS, "student_number", true));
            this.textBox1.Location = new System.Drawing.Point(164, 145);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(178, 26);
            this.textBox1.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 147);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "Student No:";
            // 
            // vCustomerAddressTB
            // 
            this.vCustomerAddressTB.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBS, "customer_address", true));
            this.vCustomerAddressTB.Location = new System.Drawing.Point(164, 110);
            this.vCustomerAddressTB.Name = "vCustomerAddressTB";
            this.vCustomerAddressTB.Size = new System.Drawing.Size(178, 26);
            this.vCustomerAddressTB.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(43, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 20);
            this.label5.TabIndex = 9;
            this.label5.Text = "Address:";
            // 
            // vCustomerEmailTB
            // 
            this.vCustomerEmailTB.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBS, "customer_email", true));
            this.vCustomerEmailTB.Location = new System.Drawing.Point(164, 79);
            this.vCustomerEmailTB.Name = "vCustomerEmailTB";
            this.vCustomerEmailTB.Size = new System.Drawing.Size(178, 26);
            this.vCustomerEmailTB.TabIndex = 8;
            // 
            // vCustomerCellTB
            // 
            this.vCustomerCellTB.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBS, "customer_cellNo", true));
            this.vCustomerCellTB.Location = new System.Drawing.Point(164, 50);
            this.vCustomerCellTB.Name = "vCustomerCellTB";
            this.vCustomerCellTB.Size = new System.Drawing.Size(178, 26);
            this.vCustomerCellTB.TabIndex = 7;
            // 
            // vCustomerNameTB
            // 
            this.vCustomerNameTB.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBS, "customer_name", true));
            this.vCustomerNameTB.Location = new System.Drawing.Point(164, 20);
            this.vCustomerNameTB.Name = "vCustomerNameTB";
            this.vCustomerNameTB.Size = new System.Drawing.Size(178, 26);
            this.vCustomerNameTB.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(43, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Email Address:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(43, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Cellphone:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(43, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Full Name:";
            // 
            // taCustomer
            // 
            this.taCustomer.ClearBeforeFill = true;
            // 
            // ViewCustomersUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ViewCustomersUI";
            this.Text = "ViewCustomersUI";
            this.Load += new System.EventHandler(this.ViewCustomersUI_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvCustomer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG7)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.Options.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox Options;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button vCustomerFirstBtn;
        private System.Windows.Forms.Button vCustomerNextBtn;
        private System.Windows.Forms.Button vCustomerPrevoiusBtn;
        private System.Windows.Forms.Button vCustomerLastBtn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox vCustomerAddressTB;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox vCustomerEmailTB;
        private System.Windows.Forms.TextBox vCustomerCellTB;
        private System.Windows.Forms.TextBox vCustomerNameTB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox gvCustomersSearchTB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView gvCustomer;
        private dsG7 dsG7;
        private System.Windows.Forms.BindingSource customerBS;
        private dsG7TableAdapters.Customer_tblTableAdapter taCustomer;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Button vCustomerUpdateBtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customeridDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customercellNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customeremailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customeraddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentnumberDataGridViewTextBoxColumn;
    }
}