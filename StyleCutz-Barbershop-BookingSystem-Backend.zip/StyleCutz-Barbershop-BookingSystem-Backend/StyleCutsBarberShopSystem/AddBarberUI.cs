﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StyleCutsBarberShopSystem
{
    public partial class AddBarberUI : Form
    {
        private readonly List<string> validPositions = new List<string>
    {
        "Manager", "Barber", "Admin"
    };
        public AddBarberUI()
        {
            InitializeComponent();
        }


        private bool IsValidInput()
        {
            if (string.IsNullOrWhiteSpace(barberNameTB.Text) || !IsValidName(barberNameTB.Text))
            {
                MessageBox.Show("Please enter a valid name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                barberNameTB.Focus();
                return false;
            }

            // Validate Number
            if (string.IsNullOrWhiteSpace(barberCellNoTB.Text) || !IsValidCellNumber(barberCellNoTB.Text))
            {
                MessageBox.Show("Please enter a valid number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                barberCellNoTB.Focus();
                return false;
            }

            // Validate Email
            if (string.IsNullOrWhiteSpace(barberEmailAddressTB.Text) || !IsValidEmail(barberEmailAddressTB.Text))
            {
                MessageBox.Show("Please enter a valid email address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                barberEmailAddressTB.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(barberGenderTB.Text)) 
            { MessageBox.Show("Please enter a gender.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error); 
                barberGenderTB.Focus();
                return false;
            }
            if (string.IsNullOrWhiteSpace(PositionTB.Text) || !IsValidPosition(PositionTB.Text)) 
            { MessageBox.Show("Please enter a position.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                PositionTB.Focus();
                return false; 
            }

            return true;
        }
        private bool IsValidName(string name)
        {
            // Simple validation: check if the name contains only letters and spaces
            return name.All(c => char.IsLetter(c) || char.IsWhiteSpace(c));
        }

        private bool IsValidCellNumber(string cellNumber)
        {
            // Validate that the cell number contains only digits and is exactly 10 digits long
            return cellNumber.All(char.IsDigit) && cellNumber.Length == 10; // Adjust length as needed
        }

        private bool IsValidEmail(string email)
        {
            // Simple validation using regex for email format
            return System.Text.RegularExpressions.Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$");
        }

        private bool IsValidPosition(string position)
        {
            // Check if the position is in the list of valid positions
            return validPositions.Contains(position.Trim());
        }
    

        private void button2_Click(object sender, EventArgs e)
        {
            if (!IsValidInput())
            {
                return; 
            }
            if (barberNameTB.Text != "" && barberCellNoTB.Text != "" && barberEmailAddressTB.Text != "" && barberGenderTB.Text != "" && PositionTB.Text != "")
            {
                try
                {
                    taEmployee.InsertQuery(barberNameTB.Text, barberCellNoTB.Text, barberEmailAddressTB.Text, barberGenderTB.Text, null, PositionTB.Text);
                    MessageBox.Show("Barber added successfully");
                    barberNameTB.Clear(); barberCellNoTB.Clear(); barberEmailAddressTB.Clear(); barberGenderTB.Clear(); PositionTB.Clear();
                }
                catch
                {
                    MessageBox.Show("Enter valid details", "Invalid details", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Please, Enter employee details");
            }

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddBarberUI_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dsG7.Employee_tbl' table. You can move, or remove it, as needed.
            this.taEmployee.Fill(this.dsG7.Employee_tbl);


        }

        private void barberClearBtn_Click(object sender, EventArgs e)
        {
            barberNameTB.Clear(); barberCellNoTB.Clear(); barberEmailAddressTB.Clear(); barberGenderTB.Clear(); PositionTB.Clear();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void barberNameTB_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Move the focus to the next control
                barberCellNoTB.Focus();

            }
        }

        private void barberCellNoTB_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Move the focus to the next control
                barberEmailAddressTB.Focus();
            }
        }

        private void barberEmailAddressTB_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Move the focus to the next control
                barberGenderTB.Focus();
            }
        }

        private void barberGenderTB_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Move the focus to the next control
                PositionTB.Focus();
            }

            }
    }
}
