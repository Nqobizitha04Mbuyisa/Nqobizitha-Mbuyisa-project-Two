﻿
namespace StyleCutsBarberShopSystem
{
    partial class AddBarberUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.PositionTB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.barberGenderTB = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.baberConfirmBtn = new System.Windows.Forms.Button();
            this.barberClearBtn = new System.Windows.Forms.Button();
            this.barberEmailAddressTB = new System.Windows.Forms.TextBox();
            this.barberCellNoTB = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.barberNameTB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.employeeBS = new System.Windows.Forms.BindingSource(this.components);
            this.dsG7 = new StyleCutsBarberShopSystem.dsG7();
            this.taEmployee = new StyleCutsBarberShopSystem.dsG7TableAdapters.Employee_tblTableAdapter();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG7)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(this.PositionTB);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.barberGenderTB);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.baberConfirmBtn);
            this.groupBox1.Controls.Add(this.barberClearBtn);
            this.groupBox1.Controls.Add(this.barberEmailAddressTB);
            this.groupBox1.Controls.Add(this.barberCellNoTB);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.barberNameTB);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(131, 78);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(532, 293);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Employee Details";
            // 
            // PositionTB
            // 
            this.PositionTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.PositionTB.Location = new System.Drawing.Point(271, 187);
            this.PositionTB.Name = "PositionTB";
            this.PositionTB.Size = new System.Drawing.Size(216, 26);
            this.PositionTB.TabIndex = 19;
            this.PositionTB.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(49, 187);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 20);
            this.label2.TabIndex = 18;
            this.label2.Text = "Position";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // barberGenderTB
            // 
            this.barberGenderTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.barberGenderTB.Location = new System.Drawing.Point(271, 143);
            this.barberGenderTB.Name = "barberGenderTB";
            this.barberGenderTB.Size = new System.Drawing.Size(216, 26);
            this.barberGenderTB.TabIndex = 17;
            this.barberGenderTB.KeyDown += new System.Windows.Forms.KeyEventHandler(this.barberGenderTB_KeyDown);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(49, 143);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 20);
            this.label5.TabIndex = 16;
            this.label5.Text = "Gender";
            // 
            // baberConfirmBtn
            // 
            this.baberConfirmBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.baberConfirmBtn.BackColor = System.Drawing.Color.Navy;
            this.baberConfirmBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.baberConfirmBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.baberConfirmBtn.ForeColor = System.Drawing.Color.White;
            this.baberConfirmBtn.Location = new System.Drawing.Point(412, 234);
            this.baberConfirmBtn.Name = "baberConfirmBtn";
            this.baberConfirmBtn.Size = new System.Drawing.Size(75, 35);
            this.baberConfirmBtn.TabIndex = 15;
            this.baberConfirmBtn.Text = "Confirm";
            this.baberConfirmBtn.UseVisualStyleBackColor = false;
            this.baberConfirmBtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // barberClearBtn
            // 
            this.barberClearBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.barberClearBtn.BackColor = System.Drawing.Color.Navy;
            this.barberClearBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.barberClearBtn.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.barberClearBtn.ForeColor = System.Drawing.Color.White;
            this.barberClearBtn.Location = new System.Drawing.Point(271, 234);
            this.barberClearBtn.Name = "barberClearBtn";
            this.barberClearBtn.Size = new System.Drawing.Size(75, 35);
            this.barberClearBtn.TabIndex = 14;
            this.barberClearBtn.Text = "Clear";
            this.barberClearBtn.UseVisualStyleBackColor = false;
            this.barberClearBtn.Click += new System.EventHandler(this.barberClearBtn_Click);
            // 
            // barberEmailAddressTB
            // 
            this.barberEmailAddressTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.barberEmailAddressTB.Location = new System.Drawing.Point(271, 106);
            this.barberEmailAddressTB.Name = "barberEmailAddressTB";
            this.barberEmailAddressTB.Size = new System.Drawing.Size(216, 26);
            this.barberEmailAddressTB.TabIndex = 11;
            this.barberEmailAddressTB.KeyDown += new System.Windows.Forms.KeyEventHandler(this.barberEmailAddressTB_KeyDown);
            // 
            // barberCellNoTB
            // 
            this.barberCellNoTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.barberCellNoTB.Location = new System.Drawing.Point(271, 70);
            this.barberCellNoTB.Name = "barberCellNoTB";
            this.barberCellNoTB.Size = new System.Drawing.Size(216, 26);
            this.barberCellNoTB.TabIndex = 10;
            this.barberCellNoTB.KeyDown += new System.Windows.Forms.KeyEventHandler(this.barberCellNoTB_KeyDown);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(49, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Email Address";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(49, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(147, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Cellphone Number";
            // 
            // barberNameTB
            // 
            this.barberNameTB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.barberNameTB.Location = new System.Drawing.Point(271, 37);
            this.barberNameTB.Name = "barberNameTB";
            this.barberNameTB.Size = new System.Drawing.Size(216, 26);
            this.barberNameTB.TabIndex = 1;
            this.barberNameTB.KeyDown += new System.Windows.Forms.KeyEventHandler(this.barberNameTB_KeyDown);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(49, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // employeeBS
            // 
            this.employeeBS.DataMember = "Employee_tbl";
            this.employeeBS.DataSource = this.dsG7;
            // 
            // dsG7
            // 
            this.dsG7.DataSetName = "dsG7";
            this.dsG7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // taEmployee
            // 
            this.taEmployee.ClearBeforeFill = true;
            // 
            // AddBarberUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddBarberUI";
            this.Text = "AddBarberUI";
            this.Load += new System.EventHandler(this.AddBarberUI_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsG7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button barberClearBtn;
        private System.Windows.Forms.TextBox barberEmailAddressTB;
        private System.Windows.Forms.TextBox barberCellNoTB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox barberNameTB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox barberGenderTB;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button baberConfirmBtn;
        private dsG7 dsG7;
        private System.Windows.Forms.BindingSource employeeBS;
        private dsG7TableAdapters.Employee_tblTableAdapter taEmployee;
        private System.Windows.Forms.TextBox PositionTB;
        private System.Windows.Forms.Label label2;
    }
}