﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StyleCutsBarberShopSystem
{
    public partial class ViewCustomersUI : Form
    {
        public ViewCustomersUI()
        {
            InitializeComponent();
           
        }
        
        private void ViewCustomersUI_Load(object sender, EventArgs e)
        {
            try
            {
                dsG7.EnforceConstraints = false;
               
                // TODO: This line of code loads data into the 'dsG7.Customer_tbl' table. You can move, or remove it, as needed.
                this.taCustomer.Fill(this.dsG7.Customer_tbl);
                //InitializeCheckboxStates();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading appointments: {ex.Message}");
            }


        }
        /*private void InitializeCheckboxStates()
        {
            // Loop through DataGridView rows to initialize checkbox states
            for (int i = 0; i < gvCustomer.Rows.Count; i++)
            {
                // Assuming column index 7 is your checkbox column
                gvCustomer.Rows[i].Cells[6].Value = true; // Initialize checkbox state as needed
            }
        }*/

        private void gvCustomersSearchTB_TextChanged(object sender, EventArgs e)
        {
            taCustomer.FillByCustomerName(dsG7.Customer_tbl, gvCustomersSearchTB.Text);
        }

        private void vCustomerFirstBtn_Click(object sender, EventArgs e)
        {
            customerBS.MoveFirst();
        }

        private void vCustomerNextBtn_Click(object sender, EventArgs e)
        {
            customerBS.MoveNext();
        }

        private void vCustomerPrevoiusBtn_Click(object sender, EventArgs e)
        {
            customerBS.MovePrevious();
        }

        private void vCustomerLastBtn_Click(object sender, EventArgs e)
        {
            customerBS.MoveLast();
        }

        private void vCustomerUpdateBtn_Click(object sender, EventArgs e)
        {
            
            DialogResult confirmation;
            confirmation = MessageBox.Show("Are you sure you want to update?", "Confirm", MessageBoxButtons.YesNo);
            if (confirmation == DialogResult.Yes)
            {
                customerBS.EndEdit();
                taCustomer.Update(dsG7);
                MessageBox.Show("Update successful");

            }
            else
            {
                MessageBox.Show("Update cancelled");
                this.taCustomer.Fill(this.dsG7.Customer_tbl);
            }

        }

        private void vCustomerSubmitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void gvCustomer_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
            {
                tabControl1.SelectedIndex += 1;
            }
        }
    }
}
