﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StyleCutsBarberShopSystem
{
    public partial class ViewSupplierUI : Form
    {
        public ViewSupplierUI()
        {
            InitializeComponent();
        }

        private void ViewSupplierUI_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dsG7.Supplier_tbl' table. You can move, or remove it, as needed.
            this.taSupplier.Fill(this.dsG7.Supplier_tbl);

        }

        private void gvSuppliersSearchTB_TextChanged(object sender, EventArgs e)
        {
            taSupplier.FillBySupplierName(dsG7.Supplier_tbl, gvSuppliersSearchTB.Text);
        }

        private void vSupplierFistBtn_Click(object sender, EventArgs e)
        {
            supplierBS.MoveFirst();
        }

        private void vSupplierNextBtn_Click(object sender, EventArgs e)
        {
            supplierBS.MoveNext();
        }

        private void vSupplierPreviousBtn_Click(object sender, EventArgs e)
        {
            supplierBS.MovePrevious();
        }

        private void vSupplierLastBtn_Click(object sender, EventArgs e)
        {
            supplierBS.MoveLast();
        }

        private void vSupplierUpdateBtn_Click(object sender, EventArgs e)
        {
            
            DialogResult confirmation;
            confirmation = MessageBox.Show("Are you sure you want to update?", "Confirm", MessageBoxButtons.YesNo);
            if (confirmation == DialogResult.Yes)
            {
                supplierBS.EndEdit();
                taSupplier.Update(dsG7);
                MessageBox.Show("Update successful");

            }
            else
            {
                MessageBox.Show("Update cancelled");
                this.taSupplier.Fill(this.dsG7.Supplier_tbl);
            }
        }

        private void vSupplierSubmitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {

        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            DBConnect connect = new DBConnect();
            DataTable DT = connect.GetProductTbl();
            DialogResult confirmation;
            int size = DT.Rows.Count;
            List<int> prodId = new List<int>();
            confirmation = MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo);
            if (confirmation == DialogResult.Yes)
            {
                taSupplier.UpdateStatus("inactive", Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value));

                 for(int i = 0; i < size; i++)
                {
                    if(Convert.ToInt32(DT.Rows[i]["supplier_id"])== Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value))
                    {
                        //prodId.Add
                        taInventory.UpdateProdID(12, Convert.ToInt32(DT.Rows[i]["item_id"]));


                    }
                }


                this.taSupplier.Fill(this.dsG7.Supplier_tbl);
                MessageBox.Show("Deletion successful");

            }
            else
            {
                MessageBox.Show("Deletion cancelled");
                //this.taSupplier.Fill(this.dsG7.Supplier_tbl);
            }


        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
            {
                tabControl1.SelectedIndex += 1;
            }
        }
    }
}
