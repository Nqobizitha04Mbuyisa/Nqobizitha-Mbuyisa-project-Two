﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StyleCutsBarberShopSystem
{
    public partial class ViewReportUI : Form
    {
        public ViewReportUI()
        {
            InitializeComponent();
        }

        private void ViewReportUI_Load(object sender, EventArgs e)
        {
            AppTA.Fill(DS1.Appointment_tbl);
            ServiceTA.Fill(DS1.Service);
            employeeTA.Fill(DS1.Employee_tbl);
            customerTA.Fill(DS1.Customer_tbl);
            service_AppTA.Fill(DS1.Service_Appointment);
            inventoryTA.Fill(DS1.Inventory_tbl);

            serviceInventoryTA.Fill(DS1.Service_Inventory);
            timesTA.Fill(DS1.Times);
            crystalReport11.SetDataSource(DS1);
            crystalReport81.SetDataSource(DS1);
            crystalReport22.SetDataSource(DS1);
            crystalReport51.SetDataSource(DS1);
            crystalReport91.SetDataSource(DS1);
            crystalReport101.SetDataSource(DS1);
            crystalReport111.SetDataSource(DS1);
            crystalReport121.SetDataSource(DS1);

        }

        private void getRepBtn_Click(object sender, EventArgs e)
        {
            
           

          



        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (maskedTextBox1.Text == "" && comboBox1.Text == "")
            {
                MessageBox.Show("Enter Year and select Quarter", "Empty Fields", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (comboBox2.Enabled == true && comboBox3.Enabled == false)//Employee + Hair Cuts
                {
                    crystalReport11.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox1.Text, "yyyy", null));
                    crystalReport11.SetParameterValue("QuarterSelection", comboBox1.Text);
                    crystalReport11.SetParameterValue("Employee", comboBox2.Text);
                    crystalReport11.SetParameterValue("Student", " ");
                    crystalReportViewer1.ReportSource = crystalReport11;
                    crystalReportViewer1.Refresh();
                }
                else if (comboBox3.Enabled == true && comboBox2.Enabled == false)//Student + Hair Cuts
                {

                    crystalReport11.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox1.Text, "yyyy", null));
                    crystalReport11.SetParameterValue("QuarterSelection", comboBox1.Text);
                    crystalReport11.SetParameterValue("Employee", " ");
                    crystalReport11.SetParameterValue("Student", comboBox3.Text);
                    crystalReportViewer1.ReportSource = crystalReport11;
                    crystalReportViewer1.Refresh();

                }
                //Students + Employee + Hair Cuts
                else if (comboBox2.Enabled == true && comboBox3.Enabled == true)
                {
                    crystalReport11.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox1.Text, "yyyy", null));
                    crystalReport11.SetParameterValue("QuarterSelection", comboBox1.Text);
                    crystalReport11.SetParameterValue("Employee", comboBox2.Text);
                    crystalReport11.SetParameterValue("Student", comboBox3.Text);
                    crystalReportViewer1.ReportSource = crystalReport11;
                    crystalReportViewer1.Refresh();
                }

                else if (comboBox2.Enabled == false && comboBox3.Enabled == false)//Hair Cuts
                {
                    crystalReport11.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox1.Text, "yyyy", null));
                    crystalReport11.SetParameterValue("QuarterSelection", comboBox1.Text);
                    crystalReport11.SetParameterValue("Employee", " ");
                    crystalReport11.SetParameterValue("Student", " ");
                    crystalReportViewer1.ReportSource = crystalReport11;
                    crystalReportViewer1.Refresh();
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox2.Enabled == true && comboBox3.Enabled == false)//Employee + Hair Cuts
            {

                crystalReport22.SetParameterValue("QuarterSelection", comboBox1.Text);
                crystalReport22.SetParameterValue("Employee", comboBox2.Text);
                crystalReport22.SetParameterValue("Student", " ");
                crystalReportViewer1.ReportSource = crystalReport22;
                crystalReportViewer1.Refresh();
            }
            else if (comboBox3.Enabled == true && comboBox2.Enabled == false)//Student + Hair Cuts
            {


                crystalReport22.SetParameterValue("QuarterSelection", comboBox1.Text);
                crystalReport22.SetParameterValue("Employee", " ");
                crystalReport22.SetParameterValue("Student", comboBox3.Text);
                crystalReportViewer1.ReportSource = crystalReport22;
                crystalReportViewer1.Refresh();

            }
            //Students + Employee + Hair Cuts
            else if (comboBox2.Enabled == true && comboBox3.Enabled == true)
            {

                crystalReport22.SetParameterValue("QuarterSelection", comboBox1.Text);
                crystalReport22.SetParameterValue("Employee", comboBox2.Text);
                crystalReport22.SetParameterValue("Student", comboBox3.Text);
                crystalReportViewer1.ReportSource = crystalReport22;
                crystalReportViewer1.Refresh();
            }

            else if (comboBox2.Enabled == false && comboBox3.Enabled == false)//Hair Cuts
            {

                crystalReport22.SetParameterValue("QuarterSelection", comboBox1.Text);
                crystalReport22.SetParameterValue("Employee", " ");
                crystalReport22.SetParameterValue("Student", " ");
                crystalReportViewer1.ReportSource = crystalReport22;
                crystalReportViewer1.Refresh();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                comboBox2.Enabled = true;

            }
            else
            {
                comboBox2.Enabled = false;

            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                comboBox3.Enabled = true;
            }
            else
            {
                comboBox3.Enabled = false;
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (maskedTextBox1.Text == "" && comboBox1.Text == "")
            {
                MessageBox.Show("Enter Year ", "Empty Fields", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {


                if (comboBox2.Enabled == true && comboBox3.Enabled == false)//Employee + Hair Cuts
                {

                    crystalReport51.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox1.Text, "yyyy", null));
                    crystalReport51.SetParameterValue("Employee", comboBox2.Text);
                    crystalReport51.SetParameterValue("Student", " ");
                    crystalReportViewer1.ReportSource = crystalReport51;
                    crystalReportViewer1.Refresh();
                }
                else if (comboBox3.Enabled == true && comboBox2.Enabled == false)//Student + Hair Cuts
                {


                    crystalReport51.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox1.Text, "yyyy", null));
                    crystalReport51.SetParameterValue("Employee", " ");
                    crystalReport51.SetParameterValue("Student", comboBox3.Text);
                    crystalReportViewer1.ReportSource = crystalReport51;
                    crystalReportViewer1.Refresh();

                }
                //Students + Employee + Hair Cuts
                else if (comboBox2.Enabled == true && comboBox3.Enabled == true)
                {

                    crystalReport51.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox1.Text, "yyyy", null));
                    crystalReport51.SetParameterValue("Employee", comboBox2.Text);
                    crystalReport51.SetParameterValue("Student", comboBox3.Text);
                    crystalReportViewer1.ReportSource = crystalReport51;
                    crystalReportViewer1.Refresh();
                }

                else if (comboBox2.Enabled == false && comboBox3.Enabled == false)//Hair Cuts
                {
                    crystalReport51.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox1.Text, "yyyy", null));
                    crystalReport51.SetParameterValue("Employee", " ");
                    crystalReport51.SetParameterValue("Student", " ");
                    crystalReportViewer1.ReportSource = crystalReport51;
                    crystalReportViewer1.Refresh();
                }
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                comboBox5.Enabled = true;
            }
            else
            {
                comboBox5.Enabled = false;
            }

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                comboBox4.Enabled = true;
            }
            else
            {
                comboBox4.Enabled = false;
            }
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox7.Checked)
            {
                comboBox8.Enabled = true;

            }
            else
            {
                comboBox8.Enabled = false;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (comboBox8.Enabled == true)
            {
                crystalReport81.SetParameterValue("QuarterSelection", " ");

                crystalReport81.SetParameterValue("Status", comboBox8.Text);
                crystalReportViewer2.ReportSource = crystalReport81;
                crystalReportViewer2.Refresh();
            }
            else if (comboBox8.Enabled == false)
            {
                crystalReport81.SetParameterValue("QuarterSelection", " ");

                crystalReport81.SetParameterValue("Status", " ");
                crystalReport81.SetParameterValue("Student", " ");
                crystalReportViewer2.ReportSource = crystalReport81;
                crystalReportViewer2.Refresh();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (maskedTextBox2.Text == "")
            {
                MessageBox.Show("Enter Year ", "Empty Fields", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                crystalReport91.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox2.Text, "yyyy", null));
                crystalReportViewer2.ReportSource = crystalReport91;
                crystalReportViewer2.Refresh();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (maskedTextBox2.Text == "")
            {
                MessageBox.Show("Enter Year", "Empty Fields", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                /*  if (comboBox2.Enabled == true && comboBox3.Enabled == false)//Employee + Hair Cuts
                {

                    crystalReport22.SetParameterValue("QuarterSelection", comboBox1.Text);
                    crystalReport22.SetParameterValue("Employee", comboBox2.Text);
                    crystalReport22.SetParameterValue("Student", " ");
                    crystalReportViewer1.ReportSource = crystalReport22;
                    crystalReportViewer1.Refresh();
                }
                */

                if (comboBox5.Enabled == true && comboBox4.Enabled == false && comboBox6.Enabled == false)//BP
                {
                    crystalReport101.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox2.Text, "yyyy", null));
                    crystalReport101.SetParameterValue("QuarterSelection", " ");
                    crystalReport101.SetParameterValue("Employee", comboBox5.Text);
                    crystalReport101.SetParameterValue("Student", " ");
                    crystalReportViewer2.ReportSource = crystalReport101;
                    crystalReportViewer2.Refresh();
                }
                else if (comboBox5.Enabled == false && comboBox4.Enabled == true && comboBox6.Enabled == false)//S/N P
                {
                    crystalReport101.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox2.Text, "yyyy", null));
                    crystalReport101.SetParameterValue("QuarterSelection", " ");
                    crystalReport101.SetParameterValue("Employee", " ");
                    crystalReport101.SetParameterValue("Student", comboBox4.Text);
                    crystalReportViewer2.ReportSource = crystalReport101;
                    crystalReportViewer2.Refresh();
                }
                else if (comboBox5.Enabled == false && comboBox4.Enabled == false && comboBox6.Enabled == true)//QP
                {
                    crystalReport101.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox2.Text, "yyyy", null));
                    crystalReport101.SetParameterValue("QuarterSelection", comboBox6.Text);
                    crystalReport101.SetParameterValue("Employee", " ");
                    crystalReport101.SetParameterValue("Student", " ");
                    crystalReportViewer2.ReportSource = crystalReport101;
                    crystalReportViewer2.Refresh();
                }
                else if (comboBox5.Enabled == true && comboBox4.Enabled == true && comboBox6.Enabled == false)//B S/N
                {
                    crystalReport101.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox2.Text, "yyyy", null));
                    crystalReport101.SetParameterValue("QuarterSelection", " ");
                    crystalReport101.SetParameterValue("Employee", comboBox5.Text);
                    crystalReport101.SetParameterValue("Student", comboBox4.Text);
                    crystalReportViewer2.ReportSource = crystalReport101;
                    crystalReportViewer2.Refresh();
                }
                else if (comboBox5.Enabled == true && comboBox4.Enabled == false && comboBox6.Enabled == true)//BQ
                {
                    crystalReport101.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox2.Text, "yyyy", null));
                    crystalReport101.SetParameterValue("QuarterSelection", comboBox6.Text);
                    crystalReport101.SetParameterValue("Employee", comboBox5.Text);
                    crystalReport101.SetParameterValue("Student", " ");
                    crystalReportViewer2.ReportSource = crystalReport101;
                    crystalReportViewer2.Refresh();
                }
                else if (comboBox5.Enabled == false && comboBox4.Enabled == true && comboBox6.Enabled == true)//S/N Q
                {
                    crystalReport101.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox2.Text, "yyyy", null));
                    crystalReport101.SetParameterValue("QuarterSelection", comboBox6.Text);
                    crystalReport101.SetParameterValue("Employee", " ");
                    crystalReport101.SetParameterValue("Student", comboBox4.Text);
                    crystalReportViewer2.ReportSource = crystalReport101;
                    crystalReportViewer2.Refresh();
                }
                else if (comboBox5.Enabled == true && comboBox4.Enabled == true && comboBox6.Enabled == true)//B S/N Q
                {
                    crystalReport101.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox2.Text, "yyyy", null));
                    crystalReport101.SetParameterValue("QuarterSelection", comboBox6.Text);
                    crystalReport101.SetParameterValue("Employee", comboBox5.Text);
                    crystalReport101.SetParameterValue("Student", comboBox4.Text);
                    crystalReportViewer2.ReportSource = crystalReport101;
                    crystalReportViewer2.Refresh();
                }
                else if (comboBox5.Enabled == false && comboBox4.Enabled == false && comboBox6.Enabled == false)//P
                {
                    //For the year only
                    crystalReport101.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox2.Text, "yyyy", null));
                    crystalReport101.SetParameterValue("QuarterSelection", " ");
                    crystalReport101.SetParameterValue("Employee", " ");
                    crystalReport101.SetParameterValue("Student", " ");
                    crystalReportViewer2.ReportSource = crystalReport101;
                    crystalReportViewer2.Refresh();
                }
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
            {
                comboBox6.Enabled = true;

            }
            else
            {
                comboBox6.Enabled = false;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            crystalReportViewer2.ReportSource = crystalReport111;
            crystalReportViewer2.Refresh();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (maskedTextBox2.Text == "")
            {
                MessageBox.Show("Enter Year ", "Empty Fields", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            else if (comboBox6.Enabled == true)
            {
                crystalReport121.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox2.Text, "yyyy", null));
                crystalReport121.SetParameterValue("QuarterSelection", comboBox6.Text);
                crystalReportViewer2.ReportSource = crystalReport121;
                crystalReportViewer2.Refresh();
            }
            else if (comboBox6.Enabled == false)
            {
                crystalReport121.SetParameterValue("Year", DateTime.ParseExact(maskedTextBox2.Text, "yyyy", null));
                crystalReport121.SetParameterValue("QuarterSelection", " ");
                crystalReportViewer2.ReportSource = crystalReport121;
                crystalReportViewer2.Refresh();

            }

            else if (maskedTextBox2.Text.Equals(""))
            {
                crystalReportViewer2.ReportSource = crystalReport121;
                crystalReportViewer2.Refresh();
            }
        }
    }
}
