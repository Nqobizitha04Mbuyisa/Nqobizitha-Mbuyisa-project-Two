﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StyleCutsBarberShopSystem
{
    public static class GlobalVariables
    {
        public static string username;
        public static string cname;
        public static string cCellNo;
        public static string cEmailAddress;
        public static string cPhycalAddress;
        public static string cStudendNo;
        public static string barber;
        public static string tPrice;
        public static string textBox3;
        public static string time;
    }
}
