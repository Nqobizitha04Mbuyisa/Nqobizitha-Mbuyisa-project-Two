﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StyleCutsBarberShopSystem
{
    public partial class AddServiceUI : Form
    {

        public AddServiceUI()
        {
            InitializeComponent();

            //taService1.Fill(dsG71.Service);
        }
        private void AddServiceUI_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dsG71.Inventory_tbl' table. You can move, or remove it, as needed.
            this.inventory_tblTableAdapter.Fill(this.dsG71.Inventory_tbl);


        }

        private void serviceConfirmBtn_Click_1(object sender, EventArgs e)
        {
            if (serviceNameTB.Text != "" || servicePriceTB.Text != "")
            {
                DialogResult result = MessageBox.Show("Are sure you want to add " + serviceNameTB.Text, "Confirm Service", MessageBoxButtons.OKCancel);
                if (result == DialogResult.OK)
                {
                    try
                    {
                        taService1.InsertService(serviceNameTB.Text, Convert.ToDecimal(servicePriceTB.Text), null);
                        MessageBox.Show("Service added successfully,Select the inventory item the added service uses");
                        taService1.FillByLast(dsG71.Service);
                        if (tabControl1.SelectedIndex < tabControl1.TabCount - 1)
                        {
                            tabControl1.SelectedIndex += 1;
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Enter valid details", "Invalid details", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    serviceNameTB.Clear();
                    servicePriceTB.Clear();
                }
            }
            else
            {
                MessageBox.Show("Please, Enter the service details");
            }


        }

        private void serviceClearBtn_Click_1(object sender, EventArgs e)
        {
            serviceNameTB.Clear();
            servicePriceTB.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure want to confirm ", "Service Confirmation", MessageBoxButtons.OKCancel);
            if (result == DialogResult.OK)
            {
                try
                {
                    taService_Inventory.InsertQuery(Convert.ToInt32(gv1.CurrentRow.Cells[0].Value),
                 Convert.ToInt32(gv2.CurrentRow.Cells[0].Value), Convert.ToInt32(textBox1.Text));
                }
                catch
                {
                    MessageBox.Show("Enter valid details", "Invalid details", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                textBox1.Clear();
            }

        }

        private void serviceNameTB_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Suppress the "Ding" sound on key press
                e.SuppressKeyPress = true;

                // Move the focus to the next control
                servicePriceTB.Focus();
            }
        }
    }
}
