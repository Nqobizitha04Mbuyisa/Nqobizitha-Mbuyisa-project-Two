﻿using System.Web.UI;

namespace StyleCutzBarberShopWebApp.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}